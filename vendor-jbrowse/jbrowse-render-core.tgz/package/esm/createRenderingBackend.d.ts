import type { GpuHal, PassDescriptor } from './hal/types.ts';
export interface RenderingBackendOptions<TRenderingBackend> {
    passes: PassDescriptor[];
    uniformByteSize: number;
    createGpuBackend: (hal: GpuHal) => TRenderingBackend;
    createCanvas2DBackend: (canvas: HTMLCanvasElement) => TRenderingBackend;
}
export declare function createRenderingBackend<TRenderingBackend>(canvas: HTMLCanvasElement, { passes, uniformByteSize, createGpuBackend, createCanvas2DBackend, }: RenderingBackendOptions<TRenderingBackend>): Promise<TRenderingBackend>;
export declare function createCanvas2DBackend<TRenderingBackend>(canvas: HTMLCanvasElement, createCanvas2DRenderingBackend: (canvas: HTMLCanvasElement) => TRenderingBackend): Promise<TRenderingBackend>;
