import type { ConfigSlotDefinition } from './configurationSlot.ts';
import type { AnyConfigurationModel, AnyConfigurationSchemaType, ConfigurationSchemaForModel, ConfigurationSlotName, ConfigurationSlotValue } from './types.ts';
import type { Feature } from '../util/index.ts';
import type { JexlInstance } from '../util/jexlStrings.ts';
import type { IMSTMap } from '@jbrowse/mobx-state-tree';
export declare function readConfObject<CONFMODEL extends AnyConfigurationModel, SLOT extends ConfigurationSlotName<ConfigurationSchemaForModel<CONFMODEL>> | string[] = ConfigurationSlotName<ConfigurationSchemaForModel<CONFMODEL>>>(confObject: CONFMODEL, slotPath?: SLOT, args?: Record<string, unknown>): SLOT extends string ? ConfigurationSlotValue<ConfigurationSchemaForModel<CONFMODEL>, SLOT> : any;
export declare function readConfObject(confObject: IMSTMap<AnyConfigurationSchemaType>, slotPath?: string | string[], args?: Record<string, unknown>): any;
export declare function getConfSnapshot(confObject: AnyConfigurationModel): Record<string, unknown>;
export declare function getConf<CONFMODEL extends AnyConfigurationModel, SLOT extends ConfigurationSlotName<ConfigurationSchemaForModel<CONFMODEL>> | string[] = ConfigurationSlotName<ConfigurationSchemaForModel<CONFMODEL>>>(model: {
    configuration: CONFMODEL;
}, slotPath?: SLOT, args?: Record<string, unknown>): SLOT extends string ? ConfigurationSlotValue<ConfigurationSchemaForModel<CONFMODEL>, SLOT> : any;
export declare function getTypeNamesFromExplicitlyTypedUnion(maybeUnionType: unknown): string[];
export declare function isBareConfigurationSchemaType(thing: unknown): thing is AnyConfigurationSchemaType;
export declare function isConfigurationSchemaType(thing: unknown): thing is AnyConfigurationSchemaType;
export declare function isConstantEntry(def: unknown): def is string | number;
export declare function isSlotDefinitionEntry(def: unknown): def is ConfigSlotDefinition;
export declare function isConfigurationModel(thing: unknown): thing is AnyConfigurationModel;
export declare function readConfigValue<T>(config: Record<string, unknown>, key: string | string[], feature: Feature, jexl?: JexlInstance): T;
