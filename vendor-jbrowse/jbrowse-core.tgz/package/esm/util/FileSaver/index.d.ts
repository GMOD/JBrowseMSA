export declare function saveAs(blob: Blob | string, name?: string): void;
