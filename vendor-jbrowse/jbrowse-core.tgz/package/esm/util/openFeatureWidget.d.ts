import type { SimpleFeatureSerialized } from './simpleFeature.ts';
import type { Widget } from './types/index.ts';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
export interface FeatureWidgetTypeRef {
    type: string;
    id: string;
}
export declare function openFeatureWidget(node: IAnyStateTreeNode, featureData: SimpleFeatureSerialized, opts?: {
    widget?: FeatureWidgetTypeRef;
    extra?: Record<string, unknown>;
}): Widget | undefined;
