import type { SubmitDialogProps } from './SubmitDialog.tsx';
declare const ConfirmDialog: (props: SubmitDialogProps) => import("react").JSX.Element;
export default ConfirmDialog;
