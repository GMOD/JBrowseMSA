export default abstract class PluggableElementBase {
    name: string;
    maybeDisplayName?: string;
    constructor(args?: {
        name?: string;
        displayName?: string;
    });
    get displayName(): string;
}
