/**
 * Identity-diffed upload slots for a **global** (non per-region) display — the
 * counterpart to {@link createRegionUploadSync}, which does the same job for a
 * per-region data map.
 *
 * `RenderLifecycleMixin` gives a display exactly one upload autorun, so every
 * observable any upload reads re-fires *all* of them. That is fine when a
 * display's uploads share one source (LD derives both its matrix and its color
 * ramp from `rpcData`), but a display whose slots have independent inputs pays
 * the cross product: HiC's palette is a config slot and its contact matrix comes
 * from the RPC, so without this a palette flip re-pushed the whole matrix and a
 * new fetch rebuilt the ramp texture.
 *
 * Each slot is keyed by name and skipped while its input is reference-identical
 * to what was last uploaded through it. A backend swap (context-loss recovery
 * hands back a fresh one with empty GPU buffers) drops every memo, so the next
 * run re-uploads all slots.
 *
 * Hold one instance per backend lifecycle — create it in `startRenderingBackend`
 * *outside* the `attachRenderingBackend` call, since the mixin captures the
 * callbacks from the first call only and the closure must outlive them:
 *
 * ```ts
 * startRenderingBackend(backend: HicRenderingBackend) {
 *   const syncUpload = createGlobalUploadSync<HicRenderingBackend>()
 *   self.attachRenderingBackend(backend, {
 *     upload: b => {
 *       syncUpload(b, 'data', self.rpcData, (bb, data) => {
 *         if (data) { bb.uploadData(data) }
 *       })
 *       syncUpload(b, 'colorRamp', self.colorScheme, (bb, scheme) => {
 *         bb.uploadColorRamp(generateColorRamp(scheme))
 *       })
 *     },
 *     render: …,
 *   })
 * }
 * ```
 *
 * Read every slot's input unconditionally, exactly as above — a read placed
 * behind an `if` drops out of the autorun's dependency set on the runs that skip
 * it, the same hazard `installGlobalFetchAutorun` documents for its trigger
 * list. Let the `upload` callback handle the empty case instead.
 *
 * @see globalUploadSync.test.ts
 */
export declare function createGlobalUploadSync<B>(): <T>(backend: B, key: string, value: T, upload: (backend: B, value: T) => void) => void;
