export declare function isRangeClear(intervals: number[], left: number, right: number): boolean;
export declare function findInsertionPoint(intervals: number[], left: number): number;
export declare function insertInterval(intervals: number[], idx: number, left: number, right: number): void;
