import type React from 'react';
interface ScrollTopModel {
    scrollTop: number;
    setScrollTop: (top: number) => void;
}
export declare function useScrollTopSync(containerRef: React.RefObject<HTMLElement | null>, model: ScrollTopModel): void;
export {};
