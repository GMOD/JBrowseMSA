import type { LinkProps } from '@mui/material';
export default function ExternalLink(props: LinkProps): import("react").JSX.Element;
