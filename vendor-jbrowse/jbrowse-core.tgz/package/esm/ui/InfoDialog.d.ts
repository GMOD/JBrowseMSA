import type { Props as DialogComponentProps } from './Dialog.tsx';
declare const InfoDialog: (props: Omit<DialogComponentProps, 'onClose'> & {
    onClose: () => void;
    closeText?: string;
    actions?: React.ReactNode;
}) => import("react").JSX.Element;
export default InfoDialog;
