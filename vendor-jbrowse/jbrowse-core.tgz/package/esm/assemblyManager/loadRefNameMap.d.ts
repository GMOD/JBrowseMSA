import type { BaseOptions } from '../data_adapters/BaseAdapter/index.ts';
import type { Assembly } from './assembly.ts';
import type { RefNameAliases } from './refNameMaps.ts';
export type RefNameMapAssembly = Pick<Assembly, 'name' | 'load' | 'error' | 'regions' | 'refNameAliases' | 'rpcManager' | 'configuration' | 'getCanonicalRefName'>;
export declare function loadRefNameMap(assembly: RefNameMapAssembly, adapterConfig: unknown, options: BaseOptions): Promise<RefNameAliases>;
