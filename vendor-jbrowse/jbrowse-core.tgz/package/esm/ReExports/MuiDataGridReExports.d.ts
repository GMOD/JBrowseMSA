import { type LazyExoticComponent } from 'react';
export declare const DataGridEntries: Record<string, LazyExoticComponent<any>>;
