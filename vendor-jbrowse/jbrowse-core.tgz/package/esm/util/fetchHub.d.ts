export interface HubConfig {
    assemblies?: Record<string, unknown>[];
    aggregateTextSearchAdapters?: Record<string, unknown>[];
    tracks?: Record<string, unknown>[];
    [key: string]: unknown;
}
export declare function hubUrl(hub: string): string;
/**
 * Fetch a hosted assembly config from jbrowse.org by UCSC database name (`hg38`,
 * `mm10`, ...) or GenArk accession (`GCA_...`/`GCF_...`). Returns the full config
 * — a self-contained assembly plus a catalog of CORS-enabled hosted tracks. Pass
 * the name straight to `createLinearGenomeView({ assembly: 'hg38' })` for the
 * common case; call this directly only to cherry-pick tracks from the catalog.
 */
export declare function fetchHub(hub: string): Promise<HubConfig>;
