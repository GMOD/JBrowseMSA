export default function useMeasure(): readonly [import("react").RefObject<HTMLDivElement | null>, {
    width?: number;
    height?: number;
}];
