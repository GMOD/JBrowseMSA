export default function BaseTooltip({ clientPoint: clientPointCoords, children, placement, }: {
    placement?: 'top' | 'top-start' | 'top-end' | 'right' | 'right-start' | 'right-end' | 'bottom' | 'bottom-start' | 'bottom-end' | 'left' | 'left-start' | 'left-end';
    clientPoint?: {
        x: number;
        y: number;
    };
    children: React.ReactNode;
}): import("react").JSX.Element;
