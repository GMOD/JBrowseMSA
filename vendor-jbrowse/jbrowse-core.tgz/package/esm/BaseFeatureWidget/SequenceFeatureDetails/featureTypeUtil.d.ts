import type { SequenceDisplayMode } from './model.ts';
import type { SimpleFeatureSerialized } from '../../util/index.ts';
export declare function featureHasCDS(feature: SimpleFeatureSerialized): boolean;
export declare function featureHasExon(feature: SimpleFeatureSerialized): boolean;
export declare function featureHasExonOrCDS(feature: SimpleFeatureSerialized): boolean;
export declare function getDefaultMode(feature: SimpleFeatureSerialized): SequenceDisplayMode;
export declare function showGenomicCoordsOption(mode: SequenceDisplayMode): boolean;
