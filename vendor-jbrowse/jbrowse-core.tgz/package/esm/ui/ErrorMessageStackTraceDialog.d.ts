export default function ErrorMessageStackTraceDialog({ error, onClose, extra, }: {
    onClose: () => void;
    error: unknown;
    extra?: unknown;
}): import("react").JSX.Element;
