import type { ReactNode } from 'react';
export type Accept = Record<string, string[]>;
export interface FileRejection {
    file: File;
    errors: {
        code: string;
        message: string;
    }[];
}
/**
 * Shared dashed-border file dropzone (drag-and-drop plus click-to-browse) used
 * by the bulk add-track, multi-wiggle, assembly, and session-import forms. The
 * `onDrop` signature reports accepted files and, when `accept`/`maxSize` are
 * set, rejected files with their validation errors. Pass `message` to replace
 * the default prompt and `children` for extra content (e.g. a Browse button).
 */
export default function FileDropZone({ onDrop, accept, maxSize, multiple, message, children, className, }: {
    onDrop: (accepted: File[], rejected: FileRejection[]) => void;
    accept?: Accept;
    maxSize?: number;
    multiple?: boolean;
    message?: ReactNode;
    children?: ReactNode;
    className?: string;
}): import("react").JSX.Element;
