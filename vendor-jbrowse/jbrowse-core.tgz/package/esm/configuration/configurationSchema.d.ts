import type { ConfigSlotDefinition } from './configurationSlot.ts';
import type { AnyConfigurationSchemaType, GetInheritedIdentifier } from './types.ts';
import type { IAnyType, IType, ReferenceIdentifier, SnapshotIn, SnapshotOut } from '@jbrowse/mobx-state-tree';
export type { AnyConfigurationModel, AnyConfigurationSchemaType, } from './types.ts';
export interface ConfigurationSchemaDefinition {
    [n: string]: ConfigSlotDefinition | ConfigurationSchemaDefinition | string | number | IAnyType;
}
export interface ConfigurationSchemaOptions<BASE_SCHEMA extends AnyConfigurationSchemaType | undefined, EXPLICIT_IDENTIFIER extends string | undefined> {
    explicitlyTyped?: boolean;
    explicitIdentifier?: EXPLICIT_IDENTIFIER;
    implicitIdentifier?: string | boolean;
    baseConfiguration?: BASE_SCHEMA;
    actions?: (self: unknown) => any;
    views?: (self: unknown) => any;
    extend?: (self: unknown) => any;
    preProcessSnapshot?: (snapshot: Record<string, unknown>) => Record<string, unknown>;
}
declare function makeConfigurationSchemaModel<DEFINITION extends ConfigurationSchemaDefinition, OPTIONS extends ConfigurationSchemaOptions<any, any>>(modelName: string, schemaDefinition: DEFINITION, options: OPTIONS): import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IModelType<Record<string, any>, {
    setSubschema(slotName: string, data: Record<string, unknown>): any;
    setSlot(slotName: string, value: unknown): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>, [undefined]>;
export interface ConfigurationSchemaType<DEFINITION extends ConfigurationSchemaDefinition, OPTIONS extends ConfigurationSchemaOptions<any, any>> extends ReturnType<typeof makeConfigurationSchemaModel<DEFINITION, OPTIONS>> {
    type: string;
}
export declare function ConfigurationSchema<const DEFINITION extends ConfigurationSchemaDefinition, BASE_SCHEMA extends AnyConfigurationSchemaType | undefined = undefined, EXPLICIT_IDENTIFIER extends string | undefined = undefined>(modelName: string, inputSchemaDefinition: DEFINITION, inputOptions?: ConfigurationSchemaOptions<BASE_SCHEMA, EXPLICIT_IDENTIFIER>): ConfigurationSchemaType<DEFINITION, ConfigurationSchemaOptions<BASE_SCHEMA, EXPLICIT_IDENTIFIER>>;
/**
 * Reference to a track configuration. Snapshot output is the trackId string.
 *
 * Two load-bearing complications, both for views that hold ephemeral track
 * configs without registering them in `session.tracks`:
 *
 * 1. **`get` falls back from `getTrackById` to MST `resolveIdentifier`.**
 *    Required by `LinearSyntenyView.viewTrackConfigs` (LinearReadVsRef);
 *    `ReadVsRef.test.tsx` is the canary.
 *
 * 2. **`types.union(trackRef, schemaType)` accepts string id OR full snapshot.**
 *    Required by `CircularView.addTrackConf` / `SvInspectorView`, which push
 *    synthesized configs as full MST instances. `SVInspector.test.tsx` is the
 *    canary.
 *
 * Simplifying either requires first migrating view-local configs into the
 * session.
 *
 * NOTE: don't add `as SCHEMATYPE` to the return value. It narrows SnapshotIn
 * to just the object branch, forcing callers to wrap string ids in
 * `@ts-expect-error`. The inferred union SnapshotIn is `string | SnapshotIn<schema>`.
 */
export declare function TrackConfigurationReference(schemaType: IAnyType): import("@jbrowse/mobx-state-tree").ITypeUnion<any, any, any>;
/**
 * Reference to a display configuration. Looked up inside the containing track
 * config's `displays` array. Snapshot output is the displayId string.
 *
 * Resolution order:
 *   1. by displayId
 *   2. by `parent.type` — handles old sessions where the saved displayId
 *      no longer matches but a display of the same type exists on the track
 *
 * Step 2 is the safety net because `baseTrackConfig.preProcessSnapshot`
 * already injects a stub display for every registered displayType on the
 * track, so a same-type lookup always succeeds at runtime for properly
 * loaded tracks. An older third step auto-created a *detached* config when
 * neither matched — that produced an orphaned MST node whose edits silently
 * didn't persist. Removed in favor of a clear throw, since
 * preProcessSnapshot's injection makes the path effectively dead.
 *
 * Union-with-schemaType branch is for the same reason as `TrackConfigurationReference`:
 * `CircularView.addTrackConf` passes inline display configs as MST instances.
 */
export declare function DisplayConfigurationReference(schemaType: IAnyType): import("@jbrowse/mobx-state-tree").ITypeUnion<any, any, any>;
type IsAny<T> = 0 extends 1 & T ? true : false;
type ConfigReferenceInstance<SCHEMA extends AnyConfigurationSchemaType> = (SCHEMA extends ConfigurationSchemaType<infer D, any> ? IsAny<D> extends true ? any : SCHEMA['Type'] : SCHEMA['Type']) & {
    [K in GetInheritedIdentifier<SCHEMA>]: string;
};
/**
 * Static type of the value `ConfigurationReference` produces, and therefore of a
 * track/display state model's `configuration` prop. Its **instance** type is a
 * clean, single-branded schema instance (see `ConfigReferenceInstance`), so
 * `ConfigurationSchemaForModel` — and thus `getConf(self, slot)` /
 * `readConfObject(self.configuration, slot)` — recovers the concrete schema and
 * its precise slot value types instead of `any`. The snapshot types stay
 * `id-string | schema-snapshot`, matching the runtime union (`idOrSnapshotUnion`):
 * a saved config serializes to its id string, and both an id string and a full
 * inline snapshot are accepted as input — so views that push string ids or
 * synthesized configs (`CircularView`, `SvInspectorView`) keep type-checking.
 *
 * Built by `Omit`-ing `Type` off `IType` and re-adding it, rather than reusing
 * the runtime `ITypeUnion`: `IType`'s own `Type` is `STNValue<T, this>`, which
 * re-brands `T` with `IStateTreeNode<this>`. Layering that over an already-branded
 * `SCHEMA['Type']` (which carries `IStateTreeNode<SCHEMA>`) double-brands the
 * node, and the two competing `IStateTreeNode<…>` brands defeat the single
 * `infer SCHEMA` in `ConfigurationSchemaForModel` (leaving it `any`). Re-adding a
 * plain `Type` keeps the single brand. See the "Config read type narrowing"
 * section of `packages/core/src/configuration/CLAUDE.md`.
 */
export type IConfigurationReference<SCHEMA extends AnyConfigurationSchemaType> = Omit<IType<ReferenceIdentifier | SnapshotIn<SCHEMA>, ReferenceIdentifier | SnapshotOut<SCHEMA>, ConfigReferenceInstance<SCHEMA>>, 'Type'> & {
    readonly Type: ConfigReferenceInstance<SCHEMA>;
};
/**
 * Dispatch by the schema's identifier: `trackId` → track-ref (resolves through
 * `session.getTrackById`), `displayId` → display-ref (resolves through the
 * parent track's displays array), anything else → plain reference.
 *
 * Display schemas must declare `explicitIdentifier: 'displayId'` (directly or
 * via `baseConfiguration: baseLinearDisplayConfigSchema`, which merges its
 * options through `preprocessConfigurationSchemaArguments`).
 *
 * The return is annotated `IConfigurationReference<SCHEMATYPE>` (see its doc)
 * so `self.configuration` carries the concrete schema. The three runtime
 * branches produce MST reference/union types over `schemaType` that are
 * assignable to that annotation, so `return ref` needs no cast — and must not
 * get one: a prior `as SCHEMATYPE` was dropped because it narrowed `SnapshotIn`
 * to just the object branch and forced callers pushing string ids to
 * `@ts-expect-error` (see `TrackConfigurationReference`'s note).
 */
export declare function ConfigurationReference<SCHEMATYPE extends AnyConfigurationSchemaType>(schemaType: SCHEMATYPE): IConfigurationReference<SCHEMATYPE>;
