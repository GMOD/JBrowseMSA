import type { BaseProps } from '../types.tsx';
export default function Position(props: BaseProps): import("react").JSX.Element;
