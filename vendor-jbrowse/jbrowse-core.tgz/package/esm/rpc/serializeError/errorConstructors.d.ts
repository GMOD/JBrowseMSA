type AnyErrorConstructor = new (...args: any[]) => Error;
export declare const errorConstructors: Map<string, AnyErrorConstructor>;
export declare const errorFactories: Map<string, () => Error>;
export {};
