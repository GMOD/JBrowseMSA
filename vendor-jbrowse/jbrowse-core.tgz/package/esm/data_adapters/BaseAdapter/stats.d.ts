import type { RectifiedQuantitativeStats } from '../../util/stats.ts';
export declare function aggregateQuantitativeStats(stats: RectifiedQuantitativeStats[]): RectifiedQuantitativeStats;
export { blankStats } from '../../util/stats.ts';
