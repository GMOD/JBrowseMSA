/**
 * A wall-clock gate for a callback invoked once per item in a long synchronous
 * loop: `due(intervalMs)` returns true at most once per `intervalMs`, without
 * calling `Date.now()` on every invocation.
 *
 * `Date.now()` costs ~40ns, invisible until the loop is a 666k-read pileup —
 * there it measured ~28ms per gated callsite, and the alignments worker has two
 * of them (the progress emit in `createProgressReporter` and the stop-token
 * check in `checkStopTokenThrottled`). Both previously read the clock per call, on the
 * documented reasoning that it was negligible next to the per-item work; at
 * this item count it measurably isn't.
 *
 * The stride between clock reads is **learned from the observed call rate**,
 * never fixed. A fixed stride is what regressed this before: a phase with few
 * but heavy items (a multi-sample VCF region — a few hundred sites, thousands
 * of samples each) never reached the count, so its progress bar froze at 0% and
 * its cancellation never fired. A learned stride makes exactly those loops
 * measure a low rate and hold a stride of 1, gating on time alone as before,
 * while a millions-of-calls loop thins itself out.
 *
 * `intervalMs` is per call rather than fixed at construction: it was added for
 * `checkStopTokenThrottled`, whose (since-deleted) sync-XHR probe backed off
 * linearly over a long loop. Both current callers pass a constant.
 */
export declare function createTimeGate(): (intervalMs: number) => boolean;
export type TimeGate = ReturnType<typeof createTimeGate>;
