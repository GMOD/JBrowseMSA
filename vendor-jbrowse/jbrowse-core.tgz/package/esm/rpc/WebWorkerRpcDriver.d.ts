import WorkerPoolRpcDriver from './WorkerPoolRpcDriver.ts';
import type { RpcDriverConstructorArgs } from './BaseRpcDriver.ts';
import type { PluginDefinition } from '../PluginLoader.ts';
import type { StatusCallback } from '../util/progress.ts';
interface WebWorkerRpcDriverConstructorArgs extends RpcDriverConstructorArgs {
    makeWorkerInstance: () => Worker;
}
interface Options {
    statusCallback?: StatusCallback;
    rpcDriverClassName: string;
}
declare class WebWorkerHandle {
    worker: Worker;
    private client;
    constructor(worker: Worker);
    destroy(): void;
    call(funcName: string, args: Record<string, unknown>, opts: Options): Promise<unknown>;
}
export default class WebWorkerRpcDriver extends WorkerPoolRpcDriver {
    workerBootConfiguration: {
        plugins: PluginDefinition[];
        windowHref: string;
    };
    name: string;
    makeWorkerInstance: () => Worker;
    constructor(args: WebWorkerRpcDriverConstructorArgs, workerBootConfiguration: {
        plugins: PluginDefinition[];
        windowHref: string;
    });
    makeWorker(): Promise<WebWorkerHandle>;
}
export {};
