import type { JexlInstance } from '../util/jexlStrings.ts';
/**
 * Editor for a list of jexl feature filters (one per line). Shared by the
 * feature-track and multi-sample-variant displays — callers pass the current
 * filter list and receive the trimmed, non-blank lines on submit (empty-list
 * handling is the caller's policy, since clearing means different things to a
 * config-backed slot vs a plain field).
 */
declare const JexlFilterDialog: ({ filters, setFilters, handleClose, jexl, }: {
    filters?: string[];
    setFilters: (arg: string[]) => void;
    handleClose: () => void;
    jexl: JexlInstance;
}) => import("react").JSX.Element;
export default JexlFilterDialog;
