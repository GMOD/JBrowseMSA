declare const category10: string[];
declare const set1: string[];
export declare const paletteColors: {
    category10: string[];
    dark2: string[];
    ggplot2Colors3: string[];
    ggplot2Colors4: string[];
    ggplot2Colors5: string[];
    ggplot2Colors6: string[];
    set1: string[];
    set2: string[];
    tableau10: string[];
};
export { category10, set1 };
