import type { Cx } from './types.ts';
export declare function mergeClasses<T extends string, U extends string>(classesFromUseStyles: Record<T, string>, classesOverrides: Partial<Record<U, string>> | undefined, cx: Cx): Record<T, string> & Partial<Record<Exclude<U, T>, string>>;
