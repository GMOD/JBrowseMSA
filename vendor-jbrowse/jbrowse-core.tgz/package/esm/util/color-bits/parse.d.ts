import type { Color } from './core.ts';
export declare function parse(color: string): Color;
export declare function parseHex(color: string): Color;
export declare function parseColor(color: string): Color;
