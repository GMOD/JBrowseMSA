import type { NotificationLevel, SnackAction } from '../util/types/index.ts';
export interface SnackbarMessage {
    message: string;
    level?: NotificationLevel;
    actions?: SnackAction[];
}
export interface ErrorDialogState {
    error: unknown;
    extra?: unknown;
}
export default function SnackbarModel(): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    snackbarMessages: import("mobx").IObservableArray<SnackbarMessage>;
    errorDialog: ErrorDialogState | undefined;
} & {
    readonly snackbarMessageSet: Map<string, SnackbarMessage>;
} & {
    notify(message: string, level?: NotificationLevel, action?: SnackAction | SnackAction[]): void;
    notifyError(errorMessage: string, error?: unknown, extra?: unknown, action?: SnackAction): void;
    setErrorDialog(state: ErrorDialogState | undefined): void;
    pushSnackbarMessage(message: string, level?: NotificationLevel, actions?: SnackAction[]): void;
    popSnackbarMessage(): SnackbarMessage | undefined;
    removeSnackbarMessage(message: string): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
