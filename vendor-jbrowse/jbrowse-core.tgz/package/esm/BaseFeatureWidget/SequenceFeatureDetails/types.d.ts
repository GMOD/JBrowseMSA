import type { SimpleFeatureSerialized } from '../../util/index.ts';
import type { SeqState } from '../util.tsx';
import type { SequenceDisplayMode, SequenceFeatureDetailsModel, SequenceHoverTarget } from './model.ts';
import type { RefObject } from 'react';
export interface SequencePanelProps {
    sequence: SeqState;
    feature: SimpleFeatureSerialized;
    model: SequenceFeatureDetailsModel;
    mode: SequenceDisplayMode;
    revcomp?: boolean;
    assemblyGeneticCodeId?: number;
    assemblyName?: string;
    hoverTarget?: SequenceHoverTarget;
    ref?: RefObject<HTMLDivElement | null>;
}
