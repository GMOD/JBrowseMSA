import { BlockSet } from './blockTypes.ts';
import type { Base1DViewModel } from './calculateStaticBlocks.ts';
export default function calculateDynamicBlocks(model: Base1DViewModel, padding?: boolean, elision?: boolean): BlockSet;
