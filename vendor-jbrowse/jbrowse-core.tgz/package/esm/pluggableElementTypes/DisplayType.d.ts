import PluggableElementBase from './PluggableElementBase.ts';
import type { AnyConfigurationSchemaType } from '../configuration/index.ts';
import type { AnyReactComponentType } from '../util/index.ts';
import type { IAnyModelType } from '@jbrowse/mobx-state-tree';
export default class DisplayType extends PluggableElementBase {
    stateModel: IAnyModelType;
    configSchema: AnyConfigurationSchemaType;
    ReactComponent: AnyReactComponentType;
    trackType: string;
    subDisplay?: {
        type: string;
        [key: string]: unknown;
    };
    viewType: string;
    helpText?: string;
    aliases?: string[];
    constructor(stuff: {
        name: string;
        stateModel: IAnyModelType;
        trackType: string;
        viewType: string;
        displayName?: string;
        subDisplay?: {
            type: string;
            [key: string]: unknown;
        };
        configSchema: AnyConfigurationSchemaType;
        ReactComponent: AnyReactComponentType;
        helpText?: string;
        aliases?: string[];
    });
}
