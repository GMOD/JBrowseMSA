import type PluginManager from '../PluginManager.ts';
import type { AbstractDisplayModel, AbstractSessionModel, AbstractTrackModel, AbstractViewModel, TypeTestedByPredicate } from './types/index.ts';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
export declare function findParentThat(node: IAnyStateTreeNode, predicate: (thing: IAnyStateTreeNode) => boolean): import("@jbrowse/mobx-state-tree").IStateTreeNode<IAnyStateTreeNode> | (object & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IAnyComplexType>);
export declare function findParentThatIs<T extends (a: IAnyStateTreeNode) => boolean>(node: IAnyStateTreeNode, predicate: T): TypeTestedByPredicate<T>;
export declare function getSession(node: IAnyStateTreeNode): AbstractSessionModel;
export declare function getContainingView(node: IAnyStateTreeNode): AbstractViewModel;
export declare function getContainingTrack(node: IAnyStateTreeNode): AbstractTrackModel;
export declare function getContainingDisplay(node: IAnyStateTreeNode): AbstractDisplayModel;
export declare function getEnv(obj: IAnyStateTreeNode): {
    pluginManager: PluginManager;
};
export declare function hashCode(str: string): number;
export declare function objectHash(obj: object): string;
