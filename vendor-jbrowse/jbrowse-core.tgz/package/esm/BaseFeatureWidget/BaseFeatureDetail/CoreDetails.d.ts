import type { BaseProps } from '../types.tsx';
export default function CoreDetails(props: BaseProps): import("react").JSX.Element;
