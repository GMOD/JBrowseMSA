import type { CxArg } from './tools/classnames.ts';
import type { CSSObject as CSSObject_base, Interpolation } from '@emotion/react';
export type CSSInterpolation = Interpolation<undefined>;
export interface CSSObject extends CSSObject_base {
    /** https://emotion.sh/docs/labels */
    label?: string;
}
export interface Css {
    (template: TemplateStringsArray, ...args: CSSInterpolation[]): string;
    (...args: CSSInterpolation[]): string;
}
export type Cx = (...classNames: CxArg[]) => string;
export type { CxArg } from './tools/classnames.ts';
