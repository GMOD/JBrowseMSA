/**
 * Track-config override deltas.
 *
 * A non-admin's track-menu / Settings edits are stored as a *delta* against the
 * admin-owned base config (jbrowse.tracks entry), not as a full copy. The delta
 * records only the slots the user changed; everything else resolves from the
 * live base, so a later admin change to an untouched field (e.g. a corrected
 * adapter URL) still flows through instead of being masked by a pinned full
 * snapshot.
 *
 * Two operations, inverse of each other on the realistic edit path:
 *   - `diffTrackConfig(base, edited)` — the minimal delta
 *   - `mergeTrackConfig(base, delta)` — reconstruct the effective config
 *
 * Deliberate limitation (no tombstones): a delta records adds/changes only, not
 * deletions. If a user *resets* a slot the admin had customized (base has it,
 * edited omits it), the delta can't express "drop below the admin value", so the
 * field keeps following the base. This keeps the merge trivial and the shared
 * JSON free of deletion sentinels; the case (reset a slot the admin explicitly
 * set) is rare, and following the admin value is a defensible outcome.
 *
 * `displays` is merged by `displayId` so an edit to one display doesn't pin the
 * others. Nested config objects (e.g. `adapter`) recurse. Any other array (value
 * arrays like `jexlFilters`, `assemblyNames`) is replaced wholesale when changed.
 *
 * Subtlety worth not "optimizing": when the base has NO `displays` array but the
 * edited snapshot does (common — a track config that omits displays gets a stub
 * per compatible display type injected by `baseTrackConfig.preProcessSnapshot`
 * when it hydrates), the whole edited array lands in the delta, including
 * seemingly content-free `{type, displayId}` stubs. Do not strip those stubs to
 * shrink the delta: the array order defines the default display (`displays[0]`),
 * and re-injection on the next hydrate would append them in a different order,
 * silently changing which display opens by default.
 */
type Json = string | number | boolean | null | undefined | Json[] | {
    [key: string]: Json;
};
/**
 * Minimal delta of `edited` against `base`. Both are plain config snapshots
 * (post-stripDefault). Records adds/changes only; see the module note on the
 * no-tombstone limitation. Always retains `trackId` so the delta is
 * self-identifying.
 */
export declare function diffTrackConfig(base: Record<string, unknown>, edited: Record<string, unknown>): Record<string, unknown>;
/**
 * Reconstruct the effective config by layering `delta` over the live `base`.
 * Inverse of `diffTrackConfig` on the add/change path (see module note).
 */
export declare function mergeTrackConfig(base: Record<string, unknown>, delta: Record<string, unknown>): Record<string, unknown>;
/** A single overridden slot: the dotted `path`, its base `from` and edited `to`. */
export interface TrackConfigChange {
    path: string[];
    from: Json;
    to: Json;
}
/**
 * Flatten a stored track-config `delta` (see {@link diffTrackConfig}) into a
 * list of changed slots paired with their `base` values, so the UI can show a
 * user exactly which settings they've overridden and what the default was.
 * Displays are addressed by type/displayId; identity keys are omitted.
 */
export declare function flattenTrackConfigDelta(base: Record<string, unknown>, delta: Record<string, unknown>): TrackConfigChange[];
export {};
