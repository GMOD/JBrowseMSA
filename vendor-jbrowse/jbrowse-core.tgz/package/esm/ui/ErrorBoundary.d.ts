import { Component } from 'react';
import type { ErrorInfo } from 'react';
interface Props {
    children: React.ReactNode;
    FallbackComponent: React.FC<{
        error: unknown;
        componentStack?: string;
    }>;
}
interface State {
    error: unknown;
    componentStack?: string;
}
declare class ErrorBoundary extends Component<Props, State> {
    constructor(props: Props);
    componentDidCatch(error: Error, errorInfo: ErrorInfo): void;
    render(): string | number | bigint | boolean | import("react").JSX.Element | Iterable<import("react").ReactNode> | Promise<string | number | bigint | boolean | Iterable<import("react").ReactNode> | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | import("react").ReactPortal | null | undefined> | null | undefined;
}
export { ErrorBoundary };
