type Callback = () => void;
export default class PhasedScheduler<PhaseName extends string> {
    phaseCallbacks: Map<PhaseName, Callback[]>;
    phaseOrder: PhaseName[];
    constructor(...phaseOrder: PhaseName[]);
    add(phase: PhaseName, callback: Callback): void;
    run(): void;
}
export {};
