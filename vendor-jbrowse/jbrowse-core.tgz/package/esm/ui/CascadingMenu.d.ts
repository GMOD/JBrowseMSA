import type { MenuItemsGetter } from './MenuTypes.ts';
import type { PopoverOrigin } from '@mui/material';
export type { MenuItemsGetter } from './MenuTypes.ts';
declare const CascadingMenu: ({ onMenuItemClick, closeAfterItemClick, menuItems, open, onClose, anchorEl, anchorOrigin, transformOrigin, anchorReference, anchorPosition, slotProps, style, }: {
    onMenuItemClick: (callback: () => void) => void;
    closeAfterItemClick?: boolean;
    menuItems: MenuItemsGetter;
    open: boolean;
    onClose: () => void;
    anchorEl?: Element | null;
    anchorOrigin?: PopoverOrigin;
    transformOrigin?: PopoverOrigin;
    anchorReference?: 'anchorEl' | 'anchorPosition' | 'none';
    anchorPosition?: {
        top: number;
        left: number;
    };
    slotProps?: {
        transition?: {
            onExit?: () => void;
        };
    };
    style?: React.CSSProperties;
}) => import("react").JSX.Element;
export default CascadingMenu;
