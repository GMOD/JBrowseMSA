/**
 * Abstract feature object
 */
export interface Feature {
    /**
     * Get a piece of data about the feature.  All features must have
     * 'start' and 'end', but everything else is optional.
     */
    get(name: 'refName'): string;
    get(name: 'name' | 'type' | 'id' | 'source'): string | undefined;
    get(name: 'start' | 'end'): number;
    get(name: 'phase'): 0 | 1 | 2 | undefined;
    get(name: 'strand'): -1 | 0 | 1 | undefined;
    get(name: 'score'): number | undefined;
    get(name: 'subfeatures'): Feature[] | undefined;
    get(name: string): unknown;
    /**
     * Get the unique ID of this feature.
     */
    id(): string;
    /**
     * Get this feature's parent feature, or undefined if none.
     */
    parent?: () => Feature | undefined;
    /**
     * Get an array of child features, or undefined if none.
     */
    children?: () => Feature[] | undefined;
    /**
     * Convert to JSON
     */
    toJSON(): SimpleFeatureSerialized;
}
declare const featureTarget: unique symbol;
interface MaybeProxiedFeature {
    [featureTarget]?: Feature;
}
export declare function isFeature(thing: unknown): thing is Feature;
/**
 * Recover the underlying feature from a jexlFeatureProxy, or return a raw
 * feature untouched. Needed by callers that want the feature's methods
 * (`id()`, `parent()`) rather than the data value the proxy resolves a
 * property to.
 */
export declare function unwrapFeature(feature: Feature & MaybeProxiedFeature): Feature;
/**
 * Wrap a feature so jexl callbacks can read attributes as plain properties
 * (`feature.score`) instead of `get(feature,'score')`. Since jexl has no
 * member-call syntax, attributes resolve to values: any property (including
 * `id`, i.e. a data field such as a GFF3 `ID=`) is forwarded to
 * `feature.get(name)` where a SimpleFeature keeps its data. Exceptions:
 * `parent` resolves to the parent feature (re-wrapped so `feature.parent.type`
 * works), `uniqueId` to the feature's identity (`id()`) so it reads the same
 * whether or not the feature happens to keep a uniqueId in its data, and
 * `get`/`toJSON` stay callable methods so the legacy
 * `get(feature,'x')`/`getTag(feature,'x')` forms and serialization still work.
 * The `parent`/`id` jexl functions unwrap the proxy (see jexl.ts).
 */
export declare function jexlFeatureProxy(feature: Feature & MaybeProxiedFeature): Feature;
/**
 * Build the variable bindings a jexl callback evaluates against, wrapping any
 * `Feature`-valued entry in `jexlFeatureProxy` (so `x.attr` reads directly while
 * `get(x,'attr')` still works) and passing everything else through untouched.
 *
 * The single context-construction path shared by config-slot evaluation
 * (`evaluateJexl`) and the filter chain (`SerializableFilterChain`), so which
 * variables a callback can reference — and how a feature is exposed — never
 * depends on which call site invoked it.
 */
export declare function buildJexlContext(args: Record<string, unknown>): Record<string, unknown>;
export interface SimpleFeatureArgs {
    /** key-value data, must include 'start' and 'end' */
    data: Record<string, unknown>;
    /** optional parent feature */
    parent?: Feature;
    /**
     * unique identifier, stringified. the serialized form
     * (SimpleFeatureSerialized) carries it as `uniqueId` instead
     */
    id: string | number;
}
export interface SimpleFeatureSerializedNoId {
    [key: string]: unknown;
    parentId?: string;
    start: number;
    end: number;
    refName: string;
    type?: string;
    strand?: number;
    name?: string;
    id?: string | number;
    uniqueId?: string;
    __jbrowsefmt?: Record<string, unknown>;
    mate?: {
        refName: string;
        start: number;
        end: number;
        [key: string]: unknown;
    };
    subfeatures?: SimpleFeatureSerializedNoId[];
}
export interface SimpleFeatureSerialized extends SimpleFeatureSerializedNoId {
    uniqueId: string;
}
/**
 * Simple implementation of a feature object.
 */
export default class SimpleFeature implements Feature {
    private data;
    private subfeatures?;
    private parentHandle?;
    private uniqueId;
    /**
     * @param args - SimpleFeature args
     *
     * Note: args.data.subfeatures can be an array of these same args,
     * which will be inflated to more instances of this class.
     */
    constructor(args: SimpleFeatureArgs | SimpleFeatureSerialized);
    private inflateSubfeatures;
    /**
     * Get a piece of data about the feature.  All features must have
     * 'start' and 'end', but everything else is optional.
     */
    get(name: 'refName'): string;
    get(name: 'name' | 'type' | 'id' | 'source'): string | undefined;
    get(name: 'start' | 'end'): number;
    get(name: 'phase'): 0 | 1 | 2 | undefined;
    get(name: 'strand'): -1 | 0 | 1 | undefined;
    get(name: 'score'): number | undefined;
    get(name: 'subfeatures'): Feature[] | undefined;
    get(name: string): unknown;
    /**
     * Get an array listing which data keys are present in this feature.
     */
    tags(): string[];
    /**
     * Get the unique ID of this feature.
     */
    id(): string;
    /**
     * Get this feature's parent feature, or undefined if none.
     */
    parent(): Feature | undefined;
    /**
     * Get an array of child features, or undefined if none.
     */
    children(): Feature[] | undefined;
    toJSON(): SimpleFeatureSerialized;
    static fromJSON(json: SimpleFeatureSerialized): SimpleFeature;
}
export {};
