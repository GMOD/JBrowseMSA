import type { CSSProperties } from 'react';
export default function DataGridFlexContainer({ children, style, }: {
    children: React.ReactNode;
    style?: CSSProperties;
}): import("react").JSX.Element;
