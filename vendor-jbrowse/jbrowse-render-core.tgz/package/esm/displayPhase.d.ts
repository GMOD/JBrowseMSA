export type DisplayPhase = 'renderError' | 'tooLarge' | 'error' | 'loading' | 'ready';
export interface DisplayPhaseInputs {
    renderError: unknown;
    regionTooLarge: boolean;
    error: unknown;
}
export declare function computeDisplayPhase({ renderError, regionTooLarge, error }: DisplayPhaseInputs, loading: () => boolean): DisplayPhase;
