import { SimpleFeature } from '../../util/index.ts';
import { BaseAdapter } from '../BaseAdapter/index.ts';
import type { BaseOptions } from '../BaseAdapter/types.ts';
export default class CytobandAdapter extends BaseAdapter {
    getData(opts?: BaseOptions): Promise<SimpleFeature[]>;
}
