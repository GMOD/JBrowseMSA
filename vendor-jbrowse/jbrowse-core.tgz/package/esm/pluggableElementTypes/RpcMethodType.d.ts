import PluggableElementBase from './PluggableElementBase.ts';
import type PluginManager from '../PluginManager.ts';
import type { RpcExecuteReturn } from '../rpc/RpcRegistry.ts';
import type { Region } from '../util/index.ts';
import type { StatusCallback } from '../util/progress.ts';
import type { StopToken } from '../util/stopToken.ts';
import type { UriLocation } from '../util/types/index.ts';
export type RpcMethodConstructor = new (pm: PluginManager) => RpcMethodType;
export interface RenameRegionsArgs {
    assemblyName?: string;
    regions?: Region[];
    stopToken?: StopToken;
    adapterConfig: Record<string, unknown>;
    sessionId: string;
    statusCallback?: StatusCallback;
}
export interface RenameRegionArgs {
    region: Region;
    adapterConfig: Record<string, unknown>;
    sessionId: string;
}
export declare function convertFileHandleLocations(obj: unknown, blobMap: Record<string, File>): void;
/**
 * Base for an RPC method. Parameterize with the method's own registry name —
 * `class CoreGetRegions extends RpcMethodType<'CoreGetRegions'>` — and `execute`
 * is then checked against that entry's declared `return` (bare or wrapped in
 * rpcResult), so the registry stays an assertion about the worker rather than a
 * hand-maintained guess. Left unparameterized, `execute` resolves to `unknown`
 * as before; that's the escape hatch for a method whose worker-side shape
 * intentionally differs from what the client sees because `deserializeReturn`
 * transforms it (CoreGetFeatures, BreakpointGetFeatures).
 */
export default abstract class RpcMethodType<MethodName extends string = string> extends PluggableElementBase {
    pluginManager: PluginManager;
    constructor(pluginManager: PluginManager);
    serializeArguments(args: object, rpcDriverClassName: string): Promise<Record<string, unknown>>;
    protected renameRegions<T extends RenameRegionsArgs>(args: T): Promise<T>;
    /**
     * The root model to resolve internet accounts against, but only while it is
     * still attached to its tree. An RPC's promise can settle after the session it
     * belongs to is gone — jbrowse-web loading a new session, or a headless
     * renderer (jbrowse-img) destroying its model once the SVG is out — and
     * reading `internetAccounts` off a destroyed node logs an MST dead-node
     * warning for work whose result is already discarded. A torn-down root has no
     * accounts to consult, so it reads as "none" rather than as an error.
     */
    private get authRootModel();
    serializeNewAuthArguments(loc: UriLocation, _rpcDriverClassName: string): Promise<UriLocation>;
    deserializeArguments<T>(args: T & {
        blobMap?: Record<string, File>;
    }, _rpcDriverClassName: string): Promise<T>;
    abstract execute(serializedArgs: unknown, rpcDriverClassName: string): Promise<RpcExecuteReturn<MethodName>>;
    deserializeReturn(serializedReturn: unknown, _args: unknown, _rpcDriverClassName: string): Promise<unknown>;
    private augmentLocationObjects;
}
