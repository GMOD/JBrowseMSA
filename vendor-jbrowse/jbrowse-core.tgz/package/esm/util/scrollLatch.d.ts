export declare function createScrollLatch(timeoutMs?: number): {
    scroll(e: WheelEvent, cur: number, delta: number, max: number, min?: number): number | null;
    reset(): void;
};
