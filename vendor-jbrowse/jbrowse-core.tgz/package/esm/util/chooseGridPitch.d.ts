export declare function chooseGridPitch(scale: number, minMajorPitchPx: number, minMinorPitchPx: number): {
    majorPitch: number;
    minorPitch: number;
};
