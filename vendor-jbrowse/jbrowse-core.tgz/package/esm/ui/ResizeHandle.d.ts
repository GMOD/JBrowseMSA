declare function ResizeHandle({ onDrag, onDragStart, onDragEnd, vertical, bar, className: originalClassName, onMouseDown, ...props }: {
    onDrag: (distance: number) => void;
    onDragStart?: () => void;
    onDragEnd?: () => void;
    vertical?: boolean;
    bar?: boolean;
} & Omit<React.ComponentPropsWithoutRef<'div'>, 'onDrag' | 'onDragStart' | 'onDragEnd'>): import("react").JSX.Element;
export default ResizeHandle;
