export interface SvgRasterCanvasOpts {
    createCanvas?: (width: number, height: number) => HTMLCanvasElement;
}
export declare function createSvgRasterCanvas(width: number, height: number, opts: SvgRasterCanvasOpts | undefined): {
    canvas: HTMLCanvasElement;
    ctx: CanvasRenderingContext2D;
};
