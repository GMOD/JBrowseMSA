declare global {
    interface FileSystemFileHandle {
        queryPermission(options: {
            mode: 'read' | 'readwrite';
        }): Promise<PermissionState>;
        requestPermission(options: {
            mode: 'read' | 'readwrite';
        }): Promise<PermissionState>;
    }
}
export declare function isFileSystemAccessSupported(): boolean;
export declare function storeFileHandle(handle: FileSystemFileHandle): Promise<string>;
export declare function getFileHandle(handleId: string): Promise<FileSystemFileHandle | undefined>;
export declare function removeFileHandle(handleId: string): Promise<void>;
export declare function verifyPermission(handle: FileSystemFileHandle, requestPermission?: boolean): Promise<boolean>;
export declare function cleanupStaleHandles(maxAgeMs: number): Promise<void>;
