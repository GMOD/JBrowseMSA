export declare function isDetachedBuffer(buffer: ArrayBufferLike): boolean;
export declare function collectTransferables(result: Record<string, unknown>): Transferable[];
