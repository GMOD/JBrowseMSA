import type { MenuProps } from '@mui/material';
declare function HoverMenu(props: MenuProps): import("react").JSX.Element;
export default HoverMenu;
