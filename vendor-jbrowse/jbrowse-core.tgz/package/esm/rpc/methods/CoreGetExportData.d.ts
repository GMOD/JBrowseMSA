import RpcMethodTypeWithRenameRegions from '../../pluggableElementTypes/RpcMethodTypeWithRenameRegions.ts';
import type { Region } from '../../util/index.ts';
export default class CoreGetExportData extends RpcMethodTypeWithRenameRegions {
    name: string;
    execute(args: {
        sessionId: string;
        regions: Region[];
        adapterConfig: Record<string, unknown>;
        formatType: string;
        opts?: Record<string, unknown>;
    }, rpcDriver: string): Promise<string>;
}
