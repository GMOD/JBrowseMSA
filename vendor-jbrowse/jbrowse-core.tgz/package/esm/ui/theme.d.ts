import type { PaletteColor, PaletteColorOptions, Theme, ThemeOptions } from '@mui/material/styles';
type MaybePaletteColor = PaletteColor | undefined;
type Frames = [
    null,
    MaybePaletteColor,
    MaybePaletteColor,
    MaybePaletteColor,
    MaybePaletteColor,
    MaybePaletteColor,
    MaybePaletteColor
];
declare module '@mui/material/styles' {
    interface Palette {
        tertiary: PaletteColor;
        quaternary: PaletteColor;
        highlight: PaletteColor;
        textHighlight: PaletteColor;
        stopCodon: string;
        startCodon: string;
        codonNonsynonymous: string;
        codonSynonymous: string;
        codonStop: string;
        coverage: string;
        insertion: string;
        softclip: string;
        skip: string;
        hardclip: string;
        deletion: string;
        modificationFwd: string;
        modificationRev: string;
        mutedSnpBase: string;
        missingData: string;
        gridlineMinor: string;
        gridlineMajor: string;
        featureHover: string;
        featureSelected: string;
        featureDescription: string;
        bases: {
            A: PaletteColor;
            C: PaletteColor;
            G: PaletteColor;
            T: PaletteColor;
            N: PaletteColor;
        };
        frames: Frames;
        framesCDS: Frames;
        alignmentFill: {
            pairLR: string;
            pairRL: string;
            pairLL: string;
            pairRR: string;
        };
    }
    interface PaletteOptions {
        tertiary?: PaletteColorOptions;
        quaternary?: PaletteColorOptions;
        highlight?: PaletteColorOptions;
        textHighlight?: PaletteColorOptions;
        stopCodon?: string;
        startCodon?: string;
        codonNonsynonymous?: string;
        codonSynonymous?: string;
        codonStop?: string;
        coverage?: string;
        hardclip?: string;
        softclip?: string;
        insertion?: string;
        skip?: string;
        deletion?: string;
        modificationFwd?: string;
        modificationRev?: string;
        mutedSnpBase?: string;
        missingData?: string;
        gridlineMinor?: string;
        gridlineMajor?: string;
        featureHover?: string;
        featureSelected?: string;
        featureDescription?: string;
        bases?: {
            A?: PaletteColorOptions;
            C?: PaletteColorOptions;
            G?: PaletteColorOptions;
            T?: PaletteColorOptions;
            N?: PaletteColorOptions;
        };
        framesCDS?: Frames;
        frames?: Frames;
        alignmentFill?: {
            pairLR?: string;
            pairRL?: string;
            pairLL?: string;
            pairRR?: string;
        };
    }
}
export declare const colorFwdStrandNotProper = "#ECC8C8";
export declare const colorRevStrandNotProper = "#BEBED8";
export declare const colorFwdStrand = "#EC8B8B";
export declare const colorRevStrand = "#8F8FD8";
export declare const colorFwdMissingMate = "#D11919";
export declare const colorRevMissingMate = "#1919D1";
export declare const colorFwdDiffChr = "#000";
export declare const colorRevDiffChr = "#969696";
export declare const colorPairLR = "#d3d3d3";
export declare const colorPairLRDark = "#8a8a8a";
export declare const colorPairRL = "#0099bb";
export declare const colorPairLL = "#4d9a4d";
export declare const colorPairRR = "#5555bb";
export declare const colorNostrand = "#c8c8c8";
export declare const colorInterchrom = "#6e4b3a";
export declare const colorLongInsert = "#ff0000";
export declare const colorShortInsert = "#ffc0cb";
export declare const colorShortInsertArc = "#ff3a8c";
export declare const colorUnmappedMate = "#b05a20";
export declare const colorUnknown = "#808080";
export declare const colorLongreadRevFwd = "#6688ee";
export declare const colorLongreadInv = "#7755bb";
export declare const colorSupplementary = "#f0b878";
export declare const tagColorPalette: string[];
export declare const methylated5mC = "#ff0000";
export declare const unmethylated5mC = "#0000ff";
export declare const methylated5hmC = "#ffc0cb";
export declare const unmethylated5hmC = "#800080";
export declare const defaultThemes: {
    default: {
        palette: {
            stopCodon: string;
            startCodon: string;
            codonNonsynonymous: string;
            codonSynonymous: string;
            codonStop: string;
            coverage: "#bdbdbd";
            insertion: string;
            deletion: string;
            softclip: string;
            hardclip: string;
            skip: string;
            modificationFwd: string;
            modificationRev: string;
            mutedSnpBase: string;
            missingData: string;
            gridlineMinor: string;
            gridlineMajor: string;
            featureHover: string;
            featureSelected: string;
            featureDescription: string;
            primary: PaletteColor;
            secondary: PaletteColor;
            tertiary: PaletteColor;
            quaternary: PaletteColor;
            highlight: PaletteColor;
            textHighlight: PaletteColor;
            bases: {
                A: PaletteColor;
                C: PaletteColor;
                G: PaletteColor;
                T: PaletteColor;
                N: PaletteColor;
            };
            frames: Frames;
            framesCDS: Frames;
            alignmentFill: {
                pairLR: string;
                pairRL: string;
                pairLL: string;
                pairRR: string;
            };
            mode: undefined;
        };
        name: string;
    };
    lightStock: {
        palette: {
            stopCodon: string;
            startCodon: string;
            codonNonsynonymous: string;
            codonSynonymous: string;
            codonStop: string;
            coverage: "#bdbdbd";
            insertion: string;
            deletion: string;
            softclip: string;
            hardclip: string;
            skip: string;
            modificationFwd: string;
            modificationRev: string;
            mutedSnpBase: string;
            missingData: string;
            gridlineMinor: string;
            gridlineMajor: string;
            featureHover: string;
            featureSelected: string;
            featureDescription: string;
            primary: PaletteColor;
            secondary: PaletteColor;
            tertiary: PaletteColor;
            quaternary: PaletteColor;
            highlight: PaletteColor;
            textHighlight: PaletteColor;
            bases: {
                A: PaletteColor;
                C: PaletteColor;
                G: PaletteColor;
                T: PaletteColor;
                N: PaletteColor;
            };
            frames: Frames;
            framesCDS: Frames;
            alignmentFill: {
                pairLR: string;
                pairRL: string;
                pairLL: string;
                pairRR: string;
            };
            mode: undefined;
        };
        name: string;
    };
    lightMinimal: {
        name: string;
        palette: {
            stopCodon: string;
            startCodon: string;
            codonNonsynonymous: string;
            codonSynonymous: string;
            codonStop: string;
            coverage: "#bdbdbd";
            insertion: string;
            deletion: string;
            softclip: string;
            hardclip: string;
            skip: string;
            modificationFwd: string;
            modificationRev: string;
            mutedSnpBase: string;
            missingData: string;
            gridlineMinor: string;
            gridlineMajor: string;
            featureHover: string;
            featureSelected: string;
            featureDescription: string;
            quaternary: PaletteColor;
            highlight: PaletteColor;
            textHighlight: PaletteColor;
            bases: {
                A: PaletteColor;
                C: PaletteColor;
                G: PaletteColor;
                T: PaletteColor;
                N: PaletteColor;
            };
            frames: Frames;
            framesCDS: Frames;
            alignmentFill: {
                pairLR: string;
                pairRL: string;
                pairLL: string;
                pairRR: string;
            };
            primary: {
                main: "#212121";
            };
            secondary: {
                main: "#424242";
            };
            tertiary: {
                main: "#212121";
            };
        };
    };
    darkMinimal: {
        name: string;
        palette: {
            stopCodon: string;
            startCodon: string;
            codonNonsynonymous: string;
            codonSynonymous: string;
            codonStop: string;
            insertion: string;
            softclip: string;
            hardclip: string;
            skip: string;
            modificationFwd: string;
            modificationRev: string;
            mutedSnpBase: string;
            missingData: string;
            quaternary: PaletteColor;
            highlight: PaletteColor;
            textHighlight: PaletteColor;
            bases: {
                A: PaletteColor;
                C: PaletteColor;
                G: PaletteColor;
                T: PaletteColor;
                N: PaletteColor;
            };
            frames: Frames;
            framesCDS: Frames;
            coverage: "#616161";
            gridlineMinor: string;
            gridlineMajor: string;
            featureHover: string;
            featureSelected: string;
            featureDescription: "#64b5f6";
            deletion: string;
            mode: 'dark';
            alignmentFill: {
                pairRL: string;
                pairLL: string;
                pairRR: string;
                pairLR: string;
            };
            primary: {
                main: "#616161";
            };
            secondary: {
                main: "#424242";
            };
            tertiary: {
                main: "#212121";
            };
        };
    };
    darkStock: {
        name: string;
        palette: {
            stopCodon: string;
            startCodon: string;
            codonNonsynonymous: string;
            codonSynonymous: string;
            codonStop: string;
            insertion: string;
            softclip: string;
            hardclip: string;
            skip: string;
            modificationFwd: string;
            modificationRev: string;
            mutedSnpBase: string;
            missingData: string;
            primary: PaletteColor;
            secondary: PaletteColor;
            tertiary: PaletteColor;
            quaternary: PaletteColor;
            highlight: PaletteColor;
            textHighlight: PaletteColor;
            bases: {
                A: PaletteColor;
                C: PaletteColor;
                G: PaletteColor;
                T: PaletteColor;
                N: PaletteColor;
            };
            frames: Frames;
            framesCDS: Frames;
            coverage: "#616161";
            gridlineMinor: string;
            gridlineMajor: string;
            featureHover: string;
            featureSelected: string;
            featureDescription: "#64b5f6";
            deletion: string;
            mode: 'dark';
            alignmentFill: {
                pairRL: string;
                pairLL: string;
                pairRR: string;
                pairLR: string;
            };
        };
        components: {
            MuiAppBar: {
                defaultProps: {
                    enableColorOnDark: true;
                };
            };
        };
    };
};
export declare function createJBrowseBaseTheme(theme?: ThemeOptions): ThemeOptions;
export type ThemeMap = Record<string, ThemeOptions & {
    name?: string;
}>;
export interface SerializableThemeArgs {
    configTheme?: ThemeOptions;
    themeName?: string;
    extraThemes?: ThemeMap;
}
export declare function createJBrowseThemeFromArgs(args?: SerializableThemeArgs): Theme;
export declare function createJBrowseTheme(configTheme?: ThemeOptions, themes?: ThemeMap, themeName?: string): Theme;
export type JBrowseTheme = Theme;
export {};
