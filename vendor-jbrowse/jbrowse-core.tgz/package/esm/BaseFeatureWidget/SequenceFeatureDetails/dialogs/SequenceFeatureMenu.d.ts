import type { RefObject } from 'react';
import type { MenuItem } from '../../../ui/index.ts';
import type { SequenceDisplayMode, SequenceFeatureDetailsModel } from '../model.ts';
interface Props {
    model: SequenceFeatureDetailsModel;
    ref: RefObject<HTMLDivElement | null>;
    mode: SequenceDisplayMode;
    extraItems?: MenuItem[];
}
declare const SequenceFeatureMenu: ({ model, ref, mode, extraItems, }: Props) => import("react").JSX.Element;
export default SequenceFeatureMenu;
