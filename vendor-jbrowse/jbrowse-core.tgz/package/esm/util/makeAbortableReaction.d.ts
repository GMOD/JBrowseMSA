import type { StopToken } from './stopToken.ts';
import type { IReactionOptions, IReactionPublic } from 'mobx';
export declare function makeAbortableReaction<T, U, V>(self: T, dataFunction: (arg: T) => U | undefined, asyncReactionFunction: (arg: U | undefined, stopToken: StopToken, model: T, handle: IReactionPublic) => Promise<V>, reactionOptions: IReactionOptions<U | undefined, boolean>, startedFunction: (stopToken: StopToken) => void, successFunction: (arg: V) => void, errorFunction: (err: unknown) => void): void;
