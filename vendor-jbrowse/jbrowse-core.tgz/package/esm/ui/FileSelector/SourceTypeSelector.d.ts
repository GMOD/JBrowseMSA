import type { BaseInternetAccountModel } from '../../pluggableElementTypes/index.ts';
export default function SourceTypeSelector({ value, shownAccountIds, hiddenAccountIds, accountMap, onChange, onHiddenAccountSelect, }: {
    value: string;
    shownAccountIds: string[];
    hiddenAccountIds: string[];
    accountMap: Record<string, BaseInternetAccountModel>;
    onChange: (event: React.MouseEvent, newValue: string | null) => void;
    onHiddenAccountSelect: (id: string) => void;
}): import("react").JSX.Element;
