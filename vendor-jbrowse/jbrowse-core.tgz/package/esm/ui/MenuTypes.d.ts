export interface MenuDivider {
    priority?: number;
    type: 'divider';
}
export interface MenuSubHeader {
    type: 'subHeader';
    priority?: number;
    label: string;
}
export type MenuItemClickHandler = (...args: any[]) => void;
export interface BaseMenuItem {
    id?: string;
    label: React.ReactNode;
    priority?: number;
    subLabel?: string;
    icon?: React.ElementType;
    disabled?: boolean;
    helpText?: string;
    disabledHelpText?: string;
}
export interface NormalMenuItem extends BaseMenuItem {
    type?: 'normal';
    onClick: MenuItemClickHandler;
}
export interface CheckboxMenuItem extends BaseMenuItem {
    type: 'checkbox';
    checked: boolean;
    onClick: MenuItemClickHandler;
}
export interface RadioMenuItem extends BaseMenuItem {
    type: 'radio';
    checked: boolean;
    onClick: MenuItemClickHandler;
}
export interface SubMenuItem extends BaseMenuItem {
    type?: 'subMenu';
    subMenu: MenuItem[];
}
export type MenuItem = MenuDivider | MenuSubHeader | NormalMenuItem | CheckboxMenuItem | RadioMenuItem | SubMenuItem;
export type MenuItemsGetter = MenuItem[] | (() => MenuItem[]);
