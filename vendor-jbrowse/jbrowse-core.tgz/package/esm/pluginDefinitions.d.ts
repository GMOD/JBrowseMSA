/**
 * What a plugin definition is, and everything that can be answered by looking
 * at one — its url, its name, whether two describe the same plugin.
 *
 * Kept apart from PluginLoader, which pulls in ReExports (effectively all of
 * core) to be able to run a plugin. Inspecting a definition must not cost that:
 * the plugin store resolves definitions and would otherwise import core's
 * config layer back into itself.
 */
export interface UMDLocPluginDefinition {
    umdLoc: {
        uri: string;
        baseUri?: string;
    };
    name: string;
    integrity?: string;
}
export interface UMDUrlPluginDefinition {
    umdUrl: string;
    name: string;
    integrity?: string;
}
export interface LegacyUMDPluginDefinition {
    url: string;
    name: string;
    integrity?: string;
}
export type UMDPluginDefinition = UMDLocPluginDefinition | UMDUrlPluginDefinition;
export interface ESMLocPluginDefinition {
    esmLoc: {
        uri: string;
        baseUri?: string;
    };
    name?: string;
}
export interface ESMUrlPluginDefinition {
    esmUrl: string;
    name?: string;
}
export type ESMPluginDefinition = ESMLocPluginDefinition | ESMUrlPluginDefinition;
export interface CJSPluginDefinition {
    cjsUrl: string;
    name?: string;
}
export type PluginDefinition = UMDUrlPluginDefinition | UMDLocPluginDefinition | LegacyUMDPluginDefinition | ESMLocPluginDefinition | ESMUrlPluginDefinition | CJSPluginDefinition;
export declare function isUMDPluginDefinition(def: PluginDefinition): def is UMDPluginDefinition | LegacyUMDPluginDefinition;
export declare function isESMPluginDefinition(def: PluginDefinition): def is ESMPluginDefinition;
export declare function isCJSPluginDefinition(def: PluginDefinition): def is CJSPluginDefinition;
export declare const vendoredPluginNames: Set<string>;
/**
 * `alsoVendored` is for a plugin one product bundles and another does not, which
 * the shared set above cannot express: Desktop vendors Blat (so a hub config
 * naming it must be dropped, or its menu items are appended twice — once by the
 * core copy, once by the downloaded one), while Web does not and has to load
 * exactly that entry to have BLAT at all.
 */
export declare function dropVendoredPlugins(defs: PluginDefinition[], alsoVendored?: Iterable<string>): PluginDefinition[];
export declare function pluginDescriptionString(d: PluginDefinition): string;
/**
 * The url a definition loads from, or undefined when it names no loader at all.
 * Comparisons between definitions go through this rather than `pluginUrl`, whose
 * 'unknown url' placeholder is display text: two unloadable definitions are not
 * the same plugin just because neither has a url.
 */
export declare function maybePluginUrl(d: PluginDefinition): string | undefined;
export declare function pluginUrl(d: PluginDefinition): string;
export declare function pluginName(definition: PluginDefinition): string | undefined;
export declare function pluginDefinitionMetadata(definition: PluginDefinition): {
    name: string | undefined;
    url: string;
};
export declare function pluginLabel(definition: PluginDefinition): string;
/**
 * Whether two definitions describe the same plugin. They can without being
 * identical — a UMD name+url in a config, an esmUrl in the global list — so
 * either a shared name or a shared url is enough. Both are optional (an ESM
 * definition carries no name, an unloadable one no url), and a missing field
 * never matches: two definitions are not the same plugin just because neither
 * names one.
 *
 * This is the single answer to "is this plugin already installed" — dedupe
 * across plugin sources, the plugin store's installed-check — so those cannot
 * drift apart and disagree about what is a duplicate.
 */
export declare function samePlugin(a: PluginDefinition, b: PluginDefinition): boolean;
/**
 * Drops later definitions that name a plugin an earlier one already did, so the
 * first source listed wins: a config's own (version-pinned) entry takes
 * precedence over the same plugin from the user's global list.
 */
export declare function dedupePlugins(plugins: PluginDefinition[]): PluginDefinition[];
