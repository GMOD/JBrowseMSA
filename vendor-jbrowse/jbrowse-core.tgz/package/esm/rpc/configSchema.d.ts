/**
 * #config RpcOptions
 * #category root
 */
declare const _default: import("../configuration/configurationSchema.ts").ConfigurationSchemaType<{
    /**
     * #slot
     * which RPC backend to use by default. Empty means "use the host
     * application's default" (web/desktop default to the web worker driver,
     * embedded/headless to the main thread). A per-track or per-call
     * `rpcDriverName` still overrides this.
     */
    readonly defaultDriver: {
        readonly type: "string";
        readonly description: "the RPC driver to use for tracks and tasks that are not configured to use a specific RPC backend";
        readonly defaultValue: "";
        readonly advanced: true;
    };
    /**
     * #slot
     * number of web workers to spawn for the web worker RPC driver. 0 lets
     * JBrowse pick based on hardware concurrency.
     */
    readonly workerCount: {
        readonly type: "number";
        readonly description: "The number of workers to use. If 0 (the default) JBrowse will decide how many workers to use.";
        readonly defaultValue: 0;
        readonly advanced: true;
    };
}, import("../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
export default _default;
