import type { ComponentType } from 'react';
export declare const Entries: Record<string, ComponentType<any>>;
