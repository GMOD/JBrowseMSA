import type PluginManager from './PluginManager.ts';
import type { AnyConfigurationSchemaType } from './configuration/index.ts';
import type { IAnyType } from '@jbrowse/mobx-state-tree';
export default abstract class Plugin {
    abstract name: string;
    url?: string;
    version?: string;
    install(_pluginManager: PluginManager): void;
    configure(_pluginManager: PluginManager): void;
    uninstall(_pluginManager: PluginManager): void;
    configurationSchema?: AnyConfigurationSchemaType;
    configurationSchemaUnnamespaced?: AnyConfigurationSchemaType;
    rootConfigurationSchema?: (arg: PluginManager) => Record<string, AnyConfigurationSchemaType | IAnyType>;
}
export type PluginConstructor = new (...args: unknown[]) => Plugin;
