import type { RenderingBackendCallbacks } from './RenderLifecycleMixin.ts';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
import type { ObservableMap } from 'mobx';
interface LifecycleHost extends IAnyStateTreeNode {
    attachRenderingBackend: <B>(b: B, cbs: RenderingBackendCallbacks<B>) => void;
    renderNow: () => void;
    currentRenderingBackend: unknown;
}
interface UploadableRenderingBackend<Encoded> {
    uploadRegion(displayedRegionIndex: number, encoded: Encoded): void;
    pruneRegions(active: Iterable<number>): void;
}
export type PerRegionRender<B, Encoded> = (backend: B, encoded: ReadonlyMap<number, Encoded>) => boolean;
export declare function installPerRegionLifecycle<Data, Encoded, B extends UploadableRenderingBackend<Encoded>>(self: LifecycleHost, rpcDataMap: ObservableMap<number, Data>, backend: B, encode: (data: Data) => Encoded | undefined, render: PerRegionRender<B, Encoded>): void;
export {};
