import type { ClickableMenuItem } from './MenuTypes.ts';
export declare function MenuItemTrailing({ item, hasCheckboxOrRadioWithHelp, hasEndAdornment, sharedActionColumn, }: {
    item: ClickableMenuItem;
    hasCheckboxOrRadioWithHelp: boolean;
    hasEndAdornment: boolean;
    sharedActionColumn: boolean;
}): import("react").JSX.Element;
