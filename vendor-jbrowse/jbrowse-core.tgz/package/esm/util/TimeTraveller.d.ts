declare const TimeTraveller: import("@jbrowse/mobx-state-tree").IModelType<{
    undoIdx: import("@jbrowse/mobx-state-tree").IType<number | undefined, number, number>;
    targetPath: import("@jbrowse/mobx-state-tree").IType<string | undefined, string, string>;
}, {
    history: unknown[];
    notTrackingUndo: boolean;
} & {
    readonly canUndo: boolean;
    readonly canRedo: boolean;
} & {
    stopTrackingUndo(): void;
    resumeTrackingUndo(): void;
    addUndoState(snapshot: unknown): void;
    beforeDestroy(): void;
    initialize(): void;
    undo(): void;
    redo(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export default TimeTraveller;
