import type { JexlInstance } from '../util/jexlStrings.ts';
import type { IAnyType } from '@jbrowse/mobx-state-tree';
export interface ConfigSlotDefinition {
    /** human-readable description of the slot's meaning */
    description?: string;
    /** custom base MST model for the slot's value */
    model?: IAnyType;
    /** name of the type of slot, e.g. "string", "number", "stringArray" */
    type: string;
    /** default value of the slot */
    defaultValue: unknown;
    /** parameter names of the function callback */
    contextVariable?: string[];
    /**
     * hide this slot behind a "Show advanced settings" toggle in the config
     * editor, so common slots aren't crowded out by rarely-changed ones
     */
    advanced?: boolean;
    /**
     * a user can promote this slot's current value to a session-wide default for
     * all tracks of the same display type (track menu pin). An *unset* slot
     * follows (inherits) that promoted default; any concrete value customizes the
     * track. Read it with `resolveConf`; see `promotableResolve.ts`.
     *
     * Requires a `maybe*` slot type (whose `undefined` is the inherit sentinel)
     * plus `promotedBase` for what inheriting resolves to.
     */
    promotable?: boolean;
    /**
     * Required for a `promotable` slot: the concrete value its unset state
     * resolves to when a track inherits and nothing is promoted.
     *
     * This is the CSS model — being unset is the `inherit` keyword and
     * `promotedBase` is `initial` (the value at the bottom of the cascade).
     * Spending only `undefined` on the sentinel is what leaves every *real* value —
     * `promotedBase` included — customizable over an opposite session default, so a
     * track can hold `displayMode: 'normal'` under a promoted `'compact'`.
     */
    promotedBase?: unknown;
    /**
     * For a `promotable` slot: an extra semantic check a stored value must pass,
     * on top of the built-in type-shape check, before the cascade
     * (`promotableResolve.ts`'s `isUsableValue`) treats it as usable. Applies to
     * both cascade tiers — a session-wide promoted default and a track's own saved
     * value. Needed when a slot's shape alone can't catch a semantically-invalid
     * value — e.g. alignments `colorBy`'s `.type` must name a currently-registered
     * color scheme, not just be *some* string — so a stale scheme name (renamed or
     * removed since the value was saved) degrades to "not usable" (falls back to
     * the base) instead of reaching a lookup that assumes every `.type` is
     * registered. Omit when the type-shape check alone is enough to trust the value.
     *
     * Runs at **schema build** too, over the slot's own `promotedBase` — the base
     * is what every failing tier degrades to, so it has to clear the same bar.
     * Keep the hook a function of module-level data (as `isRegisteredColorScheme`
     * is of `COLOR_SCHEMES`); one that consults state its plugin registers later
     * during `install()` would reject a base that is really fine.
     */
    validate?: (value: unknown) => boolean;
}
/**
 * A configuration slot is a plain value-union MST property: the slot's value
 * type, OR a `jexl:...` callback string. The value lives directly on the parent
 * configuration model — there is no per-slot sub-model. `types.stripDefault`
 * omits the property from the parent snapshot when it equals the default, so
 * saved sessions stay minimal. Per-slot metadata
 * (type/description/defaultValue/contextVariable) lives in the schema registry
 * (a WeakMap keyed by the MST type, see schemaRegistry.ts); jexl callbacks are
 * evaluated on read by `readConfObject`.
 */
export default function ConfigSlot(definition: ConfigSlotDefinition): import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ITypeUnion<any, any, any>, [undefined]>;
/**
 * New value when converting a fixed-value slot to a jexl callback. Already-
 * callback values are returned unchanged.
 *
 * A single JSON.stringify covers every type: `jexl:${42}` and
 * `jexl:${JSON.stringify(42)}` are identical for numbers/booleans, and the rest
 * need the quoting/serialization anyway.
 */
export declare function toCallbackValue(value: unknown): string;
/**
 * New value when converting a jexl callback back to a fixed value: try
 * evaluating with no args, else fall back to the slot default (and to the slot
 * type's `fallbackDefault` if the default is itself a callback).
 */
export declare function toFixedValue(value: unknown, type: string, defaultValue: unknown, jexl: JexlInstance): unknown;
