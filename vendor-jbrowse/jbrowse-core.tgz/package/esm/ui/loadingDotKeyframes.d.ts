export declare const dot1: {
    name: string;
    styles: string;
    anim: 1;
    toString: () => string;
} & string;
export declare const dot2: {
    name: string;
    styles: string;
    anim: 1;
    toString: () => string;
} & string;
export declare const dot3: {
    name: string;
    styles: string;
    anim: 1;
    toString: () => string;
} & string;
