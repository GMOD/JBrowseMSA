import RpcMethodTypeWithRenameRegions from '../../pluggableElementTypes/RpcMethodTypeWithRenameRegions.ts';
import type { Region } from '../../util/index.ts';
import type { StatusCallback } from '../../util/progress.ts';
import type { SimpleFeatureSerialized } from '../../util/simpleFeature.ts';
import type { StopToken } from '../../util/stopToken.ts';
import type { RpcReturn } from '../RpcRegistry.ts';
export default class CoreGetFeatures extends RpcMethodTypeWithRenameRegions {
    name: string;
    deserializeReturn(feats: SimpleFeatureSerialized[], args: unknown, rpcDriver: string): Promise<RpcReturn<'CoreGetFeatures'>>;
    execute(args: {
        sessionId: string;
        regions: Region[];
        adapterConfig: Record<string, unknown>;
        sequenceAdapter?: Record<string, unknown>;
        statusCallback?: StatusCallback;
        stopToken?: StopToken;
        opts?: Record<string, unknown>;
    }, rpcDriver: string): Promise<SimpleFeatureSerialized[]>;
}
