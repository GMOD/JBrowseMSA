import RpcMethodType from '../../pluggableElementTypes/RpcMethodType.ts';
import type { StatusCallback } from '../../util/progress.ts';
import type { StopToken } from '../../util/stopToken.ts';
export default class CoreGetRefNames extends RpcMethodType {
    name: string;
    execute(args: {
        sessionId: string;
        stopToken?: StopToken;
        statusCallback?: StatusCallback;
        adapterConfig: Record<string, unknown>;
        assemblyName?: string;
        sequenceAdapter?: Record<string, unknown>;
    }, rpcDriver: string): Promise<string[]>;
}
