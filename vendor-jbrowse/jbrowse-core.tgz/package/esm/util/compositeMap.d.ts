export default class CompositeMap<T, U> {
    private submaps;
    constructor(submaps: Map<T, U>[]);
    has(id: T): boolean;
    get(id: T): U | undefined;
    find(f: (arg0: U) => boolean): U | undefined;
    entries(): Generator<readonly [T, U], void, unknown>;
    keys(): Generator<T, void, unknown>;
    values(): Generator<U, void, unknown>;
    [Symbol.iterator](): Generator<readonly [T, U], void, unknown>;
}
