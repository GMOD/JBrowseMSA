import type React from 'react';
import PluggableElementBase from './PluggableElementBase.ts';
import type { IAnyModelType } from '@jbrowse/mobx-state-tree';
type BasicComponent = React.ComponentType<{
    model: any;
}>;
type AddTrackWorkflowComponentType = React.LazyExoticComponent<BasicComponent> | BasicComponent;
export type AddTrackWorkflowCategory = 'general' | 'specialized';
export default class AddTrackWorkflow extends PluggableElementBase {
    ReactComponent: AddTrackWorkflowComponentType;
    category: AddTrackWorkflowCategory;
    stateModel: IAnyModelType;
    constructor(stuff: {
        name: string;
        displayName?: string;
        category?: AddTrackWorkflowCategory;
        ReactComponent: AddTrackWorkflowComponentType;
        stateModel: IAnyModelType;
    });
}
export {};
