import { Canvas2DRenderingBackendBase, GpuRenderingBackendBase } from './renderingBackendBase.ts';
import type { BlockClipResult } from './blockClipUtils.ts';
import type { RenderBlock } from './renderBlock.ts';
export interface FrameDimensions {
    canvasWidth: number;
    canvasHeight: number;
}
export interface PerRegionRenderingBackend<UploadData, RenderState, Block = RenderBlock, RenderData = UploadData> {
    uploadRegion(displayedRegionIndex: number, data: UploadData): void;
    pruneRegions(activeRegions: Iterable<number>): void;
    renderBlocks(blocks: Block[], regions: ReadonlyMap<number, RenderData>, state: RenderState): void;
    dispose(): void;
}
export declare abstract class Canvas2DPerRegionRenderingBackend<UploadData, RenderState extends FrameDimensions, Block extends RenderBlock = RenderBlock, RenderData = UploadData> extends Canvas2DRenderingBackendBase implements PerRegionRenderingBackend<UploadData, RenderState, Block, RenderData> {
    uploadRegion(): void;
    pruneRegions(): void;
    renderBlocks(blocks: Block[], regions: ReadonlyMap<number, RenderData>, state: RenderState): void;
    protected abstract draw(blocks: Block[], regions: ReadonlyMap<number, RenderData>, state: RenderState): void;
}
export declare abstract class GpuPerRegionRenderingBackend<UploadData, RenderState extends FrameDimensions, Block extends RenderBlock = RenderBlock, RenderData = UploadData> extends GpuRenderingBackendBase implements PerRegionRenderingBackend<UploadData, RenderState, Block, RenderData> {
    pruneRegions(activeRegions: Iterable<number>): void;
    abstract uploadRegion(displayedRegionIndex: number, data: UploadData): void;
    renderBlocks(blocks: Block[], regions: ReadonlyMap<number, RenderData>, state: RenderState): void;
    protected abstract drawRegion(block: Block, clip: BlockClipResult, region: RenderData, state: RenderState): void;
}
