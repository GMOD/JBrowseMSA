export declare class IntervalTree<V> {
    private intervals;
    private root;
    private built;
    insert(key: [number, number], value: V): void;
    search(interval: [number, number]): V[];
}
