import type { ResolvableDisplay } from '../configuration/promotableResolve.ts';
import type { MenuItem } from './MenuTypes.ts';
import type { SliderScale } from './sliderScale.ts';
interface SizeMenuOptions {
    label: string;
    title: string;
    getValue: () => number;
    min?: number;
    max?: number;
    step?: number;
    unit?: string;
    scale?: SliderScale;
    format?: (n: number) => string;
    commitOnRelease?: boolean;
    onChange: (n: number) => void;
    onReset: () => void;
}
export declare function makeSizeMenu(opts: SizeMenuOptions & {
    isDefault: boolean;
}): MenuItem;
export declare function makePromotableSizeMenu(opts: SizeMenuOptions & {
    display: ResolvableDisplay;
    slot: string;
}): MenuItem;
export {};
