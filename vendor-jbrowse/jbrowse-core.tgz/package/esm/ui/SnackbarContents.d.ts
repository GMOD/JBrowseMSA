import type { SnackbarMessage } from './SnackbarModel.tsx';
export default function SnackbarContents({ onClose, contents, }: {
    onClose: (_event: unknown, reason?: string) => void;
    contents: SnackbarMessage;
}): import("react").JSX.Element;
