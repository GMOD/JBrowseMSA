import type { FeatureFormatter } from '../types.tsx';
export default function SimpleField({ name, value, description, prefix, width, formatter, }: {
    description?: React.ReactNode;
    name: string;
    value: unknown;
    prefix?: string[];
    width?: number;
    formatter?: FeatureFormatter;
}): import("react").JSX.Element | null;
