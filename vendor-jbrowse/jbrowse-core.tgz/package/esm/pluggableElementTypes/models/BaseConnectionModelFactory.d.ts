import type PluginManager from '../../PluginManager.ts';
import type { AnyConfigurationModel } from '../../configuration/index.ts';
type TrackConf = AnyConfigurationModel | Record<string, unknown>;
/**
 * #stateModel BaseConnectionModel
 */
declare function stateModelFactory(pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{
    /**
     * #property
     */
    tracks: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyModelType>;
    /**
     * #property
     */
    configuration: import("../../configuration/configurationSchema.ts").IConfigurationReference<import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
        readonly name: {
            readonly type: "string";
            readonly defaultValue: "nameOfConnection";
            readonly description: "a unique name for this connection";
        };
        readonly assemblyNames: {
            readonly type: "stringArray";
            readonly defaultValue: readonly [];
            readonly description: "optional list of names of assemblies in this connection";
        };
    }, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, "connectionId">>>;
    /**
     * #property
     * set when the connection is being re-established on session load (its
     * open tracks are already restored from `connectionTrackConfigs`), so
     * `doConnect` suppresses first-connect side effects like launching a view
     * or a success snackbar. Runtime-only: connection instances aren't
     * serialized.
     */
    silent: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, {
    /**
     * #volatile
     * true while `connect()` is fetching this connection's tracks; drives a
     * loading affordance in the track selector. Distinct from an empty
     * `tracks` array, which is also the state of a connection that loaded
     * successfully but has no tracks.
     */
    loading: boolean;
} & {
    /**
     * #getter
     * the connection's unique id, resolved from its configuration (the config
     * is the source of truth; connection names are not guaranteed unique)
     */
    readonly connectionId: string;
    /**
     * #getter
     */
    readonly name: string;
} & {
    /**
     * #action
     * no-op hook; concrete connections (UCSC/JB2 track hubs, etc.) override
     * this to fetch and populate their `tracks`. Returns a promise so
     * `afterAttach` can clear the loading flag once the fetch settles.
     */
    connect(): Promise<void>;
    /**
     * #action
     */
    setLoading(loading: boolean): void;
} & {
    afterAttach(): void;
    /**
     * #action
     */
    addTrackConf(trackConf: TrackConf): any;
    /**
     * #action
     */
    addTrackConfs(trackConfs: TrackConf[]): void;
    /**
     * #action
     */
    setTrackConfs(trackConfs: TrackConf[]): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type BaseConnectionModel = ReturnType<typeof stateModelFactory>;
export default stateModelFactory;
