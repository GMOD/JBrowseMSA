import type { RpcStatus } from '../util/progress.ts';
export default function StatusProgressBar({ status, className, style, }: {
    status?: RpcStatus;
    className?: string;
    style?: React.CSSProperties;
}): import("react").JSX.Element;
