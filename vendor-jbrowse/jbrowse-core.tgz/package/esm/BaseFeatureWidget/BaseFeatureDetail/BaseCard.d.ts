import type { BaseCardProps } from '../types.tsx';
export default function BaseCard({ children, title, defaultExpanded, }: BaseCardProps): import("react").JSX.Element;
