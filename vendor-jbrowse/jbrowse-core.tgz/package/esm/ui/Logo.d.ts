type LogoVariant = 'color' | 'black' | 'white';
interface LogoProps {
    variant?: LogoVariant;
}
export declare function Logomark({ variant }: LogoProps): import("react").JSX.Element;
export declare function LogoFull({ variant }: LogoProps): import("react").JSX.Element;
export {};
