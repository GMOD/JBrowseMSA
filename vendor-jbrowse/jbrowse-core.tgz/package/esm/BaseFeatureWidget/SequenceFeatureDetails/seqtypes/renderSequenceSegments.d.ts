import type { SequenceFeatureDetailsModel } from '../model.ts';
export interface SeqSegment {
    key: string;
    str: string;
    color?: string;
}
export declare function flankSegment(key: string, str: string | undefined, color: string, transform?: (s: string) => string): SeqSegment[];
export declare function renderSequenceSegments({ segments, model, mult, coordStart, onHoverBase, }: {
    segments: SeqSegment[];
    model: SequenceFeatureDetailsModel;
    mult: number;
    coordStart: number;
    onHoverBase?: (base0: number) => void;
}): import("react").ReactNode[];
