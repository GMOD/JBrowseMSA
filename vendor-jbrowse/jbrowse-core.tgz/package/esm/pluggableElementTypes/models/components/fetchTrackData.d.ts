import type { Region } from '../../../util/index.ts';
import type { FileTypeExporter } from '../saveTrackFileTypes/types.ts';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
export declare function fetchTrackData(model: IAnyStateTreeNode, visibleRegions: Region[], type: string, options: Record<string, FileTypeExporter>): Promise<{
    str: string;
    usedAdapterExport: boolean;
}>;
