import type { SimpleFeatureSerialized } from '../../util/index.ts';
import type { ErrorState, Feat, SeqState } from '../util.tsx';
export declare function getSequenceData({ feature, sequence, }: {
    feature: SimpleFeatureSerialized;
    sequence?: SeqState | ErrorState;
}): {
    seq: string;
    upstream: string | undefined;
    downstream: string | undefined;
    cds: Feat[];
    exons: Feat[];
    utr: Feat[];
} | undefined;
