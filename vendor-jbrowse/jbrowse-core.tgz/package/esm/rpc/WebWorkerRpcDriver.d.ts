import WorkerPoolRpcDriver from './WorkerPoolRpcDriver.ts';
import type { PluginDefinition } from '../pluginDefinitions.ts';
import type { StatusCallback } from '../util/progress.ts';
import type { RpcDriverConstructorArgs } from './BaseRpcDriver.ts';
interface WebWorkerRpcDriverConstructorArgs extends RpcDriverConstructorArgs {
    makeWorkerInstance: () => Worker;
}
interface Options {
    statusCallback?: StatusCallback;
    rpcDriverClassName: string;
}
declare class WebWorkerHandle {
    worker: Worker;
    private client;
    constructor(worker: Worker);
    destroy(): void;
    onError(callback: () => void): void;
    notifyStopToken(id: string): void;
    call(funcName: string, args: Record<string, unknown>, opts: Options): Promise<unknown>;
}
export default class WebWorkerRpcDriver extends WorkerPoolRpcDriver {
    workerBootConfiguration: {
        plugins: PluginDefinition[];
        windowHref: string;
        numberGrouping: boolean;
    };
    name: string;
    makeWorkerInstance: () => Worker;
    constructor(args: WebWorkerRpcDriverConstructorArgs, workerBootConfiguration: {
        plugins: PluginDefinition[];
        windowHref: string;
        numberGrouping: boolean;
    });
    makeWorker(): Promise<WebWorkerHandle>;
}
export {};
