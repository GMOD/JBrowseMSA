import type { Feature } from '@jbrowse/core/util';
export declare function formatMultiLevelFeat({ feature, parentId, parentRef, cdsPhase, }: {
    feature: Feature;
    parentId?: string;
    parentRef?: string;
    cdsPhase?: number;
}): string;
export declare function stringifyGFF3({ features }: {
    features: Feature[];
}): string;
