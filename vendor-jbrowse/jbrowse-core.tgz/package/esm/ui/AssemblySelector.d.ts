import type { AbstractSessionModel } from '../util/index.ts';
declare const AssemblySelector: ({ session, onChange, label, selected, fullWidth, localStorageKey, helperText, }: {
    session: AbstractSessionModel;
    label?: string;
    helperText?: string;
    onChange: (arg: string) => void;
    selected?: string;
    fullWidth?: boolean;
    localStorageKey?: string;
}) => import("react").JSX.Element;
export default AssemblySelector;
