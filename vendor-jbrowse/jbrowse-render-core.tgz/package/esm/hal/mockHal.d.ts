import type { GpuHal, PassDescriptor } from './types.ts';
export interface MockCall {
    method: string;
    args: unknown[];
}
export declare class MockHal implements GpuHal {
    calls: MockCall[];
    private buffers;
    private lastUniforms;
    private written;
    constructor(_passes: PassDescriptor[]);
    private bufferKey;
    private record;
    resize(width: number, height: number): void;
    uploadBuffer(regionKey: number, passId: string, data: ArrayBuffer | ArrayBufferView, count: number): void;
    getBufferCount(regionKey: number, passId: string): number;
    deleteBuffer(regionKey: number, passId: string): void;
    deleteRegion(regionKey: number): void;
    pruneRegions(active: Iterable<number>): void;
    beginUpload(): void;
    endUpload(): void;
    uploadTexture(passId: string, data: Uint8Array, width: number, height: number): void;
    writeUniforms(data: ArrayBuffer): void;
    beginFrame(clearR: number, clearG: number, clearB: number, clearA?: number): void;
    drawPass(passId: string, regionKey: number, bufferPassId?: string): void;
    endFrame(): void;
    setScissor(x: number, y: number, w: number, h: number): void;
    clearScissor(): void;
    setViewport(x: number, y: number, w: number, h: number): void;
    clearViewport(): void;
    dispose(): void;
    getLastUniformsF32(): Float32Array<ArrayBuffer> | null;
    getLastUniformsU32(): Uint32Array<ArrayBuffer> | null;
    getLastUniformsI32(): Int32Array<ArrayBuffer> | null;
    getBuffer(regionKey: number, passId: string): {
        data: ArrayBufferLike;
        count: number;
    } | undefined;
    callsOf(method: string): MockCall[];
    reset(): void;
}
