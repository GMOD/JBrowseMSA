import type { SliderValueLabelProps } from '@mui/material';
export default function SliderTooltip(props: SliderValueLabelProps): import("react").JSX.Element;
