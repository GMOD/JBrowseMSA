import type { SimpleFeatureSerialized } from '../../../util/index.ts';
import type { SequenceDisplayMode, SequenceFeatureDetailsModel } from '../model.ts';
declare const SequenceTypeSelector: ({ model, feature, mode, setMode, }: {
    model: SequenceFeatureDetailsModel;
    feature: SimpleFeatureSerialized;
    mode: SequenceDisplayMode;
    setMode: (mode: SequenceDisplayMode) => void;
}) => import("react").JSX.Element;
export default SequenceTypeSelector;
