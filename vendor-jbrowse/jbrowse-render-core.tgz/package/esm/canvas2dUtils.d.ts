import type { BpRegionBounds } from './renderBlock.ts';
export interface BlockClip {
    scissorX: number;
    scissorW: number;
    fullBlockWidth: number;
    bpLength: number;
}
export declare const MAX_DPR = 2;
/**
 * The ratio every canvas in the app renders at, capped at {@link MAX_DPR}.
 *
 * Use this, never a bare `devicePixelRatio` read — the value has to agree
 * across the backing-store sizing (`syncCanvasSize` / `prepareCanvas`), the
 * scissor/viewport rects derived from it (`clipBlock`, alignments'
 * `computeBlockGeom`), and any shader uniform that reconstructs backing-store
 * dimensions from CSS ones. A call site that reads the global directly renders
 * geometry at a different scale than the canvas it lands on.
 *
 * Two places legitimately want something other than this and should keep saying
 * so explicitly: `createSvgRasterCanvas` pins 2x because export goes to a file
 * rather than a screen, and the analytics / error-report paths read the raw
 * global because they are reporting the device, not drawing on it.
 */
export declare function getDpr(): number;
export declare const MAX_CANVAS_DIM_PX = 8192;
export declare function syncCanvasSize(canvas: HTMLCanvasElement, width: number, height: number): boolean;
export declare function prepareCanvas(canvas: HTMLCanvasElement, ctx: CanvasRenderingContext2D, canvasWidth: number, canvasHeight: number): void;
export declare function getPreparedCanvas2D(canvas: HTMLCanvasElement | null, width: number, height: number): CanvasRenderingContext2D | null;
export declare function devicePxSpan(cssStart: number, cssEnd: number, dpr: number): {
    start: number;
    width: number;
};
export declare function clampBlockScissor(screenStartPx: number, screenEndPx: number, canvasWidth: number): {
    scissorX: number;
    scissorEnd: number;
    scissorW: number;
} | null;
export declare function clipBlockForCanvas(block: BpRegionBounds, canvasWidth: number): BlockClip | null;
/**
 * The 2D-context subset the block scaffold below needs. Structural on purpose:
 * render-core must not depend on `@jbrowse/core`, where the real `Ctx2D =
 * CanvasRenderingContext2D | SvgCanvas` union lives. Both members satisfy it,
 * so a plugin passes its `Ctx2D` straight in.
 */
export interface ClipContext2D {
    save(): void;
    restore(): void;
    beginPath(): void;
    rect(x: number, y: number, w: number, h: number): void;
    clip(): void;
}
/**
 * The Canvas2D twin of `GpuPerRegionRenderingBackend.renderBlocks`' per-block
 * scissor: skip blocks with nothing to draw or no on-screen span, clip to the
 * block's columns, paint, unclip. Owning it here means a painter can't pair
 * `save()` with a missed `restore()` (leaking the clip onto every later block),
 * clip to a span other than `clipBlockForCanvas`', or forget the null check.
 *
 * `select` resolves a block to what it paints, or `undefined` to skip it — the
 * one gate covering all three reasons a painter skips: no region in the map, a
 * region with zero features, and a region whose relevant sub-field is absent
 * (MAF's `?.coverage`). It runs *before* the clip because entering the scaffold
 * for an empty block is not free on the export path: `SvgCanvas.clip()` emits a
 * `<clipPath>` + group unconditionally, so a skipped-late block leaves dead
 * markup in the SVG. Resolving here also lets `paint` take a non-optional value
 * instead of re-narrowing inside the callback.
 *
 * `clipHeight` is a parameter rather than read off a render state because
 * painters that own a sub-band of the canvas clip to that band, not the full
 * height (MAF's coverage row).
 *
 * `paint` receives the block, so callers needing bp→px build their own mapper
 * (`makeBpMapper` / `makeCellLeftMapper` — which one is a per-painter choice).
 * Two closures per draw call, not per feature: per-feature loops live inside the
 * `paint` body and stay allocation-free.
 */
export declare function forEachClippedBlock<T, B extends BpRegionBounds>(ctx: ClipContext2D, blocks: readonly B[], canvasWidth: number, clipHeight: number, select: (block: B) => T | undefined, paint: (data: T, block: B, clip: BlockClip) => void): void;
/**
 * `fillRect` x for a mark that spans `x1`→`x2` but is painted at `width` — the
 * Canvas2D pivot for every painter that widens a too-narrow span to a floor (a
 * 1bp feature, a zoomed-out coverage bin), and the twin of the pivot baked into
 * the shaders' `extendToMinWidthX`.
 *
 * The mark is anchored at `x1` and grows *away* from it. That's the whole point:
 * on a reversed block `makeBpMapper` flips, so `x2 < x1`, `x1` is the feature's
 * **start** — its right edge — and the mark must grow leftward from it. Spelling
 * the fill as `min(x1, x2)` + `max(floor, |dx|)` instead anchors whichever edge
 * happens to be leftmost, which reversed is the feature's *end*, sliding the
 * mark by up to the floor. Forward blocks are identical either way, so the error
 * only ever shows on flipped regions and survives review. The canvas rect
 * painter (2px floor), the multi-row painter (1px), and wiggle (1.5px) each had
 * it independently.
 *
 * Callers own the *width*, like `makeCellLeftMapper` below — it's a per-plugin
 * rule (canvas/multi-row take `max(floor, |dx|)`, matching `extendToMinWidthX`
 * exactly; wiggle adds a seam-closing fudge the shader deliberately omits).
 * Only the pivot is shared, and it's the part that keeps being got wrong.
 *
 * Scalar in, scalar out: runs per feature per frame, so it must not allocate.
 */
export declare function spanLeft(x1: number, x2: number, width: number): number;
export declare function lookupColorRamp(ramp: Uint8Array, t: number): {
    r: number;
    g: number;
    b: number;
    a: number;
};
export declare function makeRampFillStyleLut(ramp: Uint8Array): (t: number) => string;
export declare function bpToScreenPx(absBp: number, regionStart: number, regionEnd: number, screenStartPx: number, screenEndPx: number, reversed?: boolean): number;
export declare function makeBpMapper(bounds: BpRegionBounds): (bp: number) => number;
/**
 * Left edge of the **1bp cell** covering `bp` — for painters that fill a rect
 * per base (MAF alignment cells, the alignments pileup's mismatch /
 * modification / per-base quality+letter / soft-clip base layers).
 *
 * Use this, not `makeBpMapper`, whenever the mark is a cell rather than a point
 * or a two-edge span. `makeBpMapper(bp)` is the cell's left edge only on a
 * forward block: a reversed block runs bp leftward, so it lands on the cell's
 * *right* edge, and `fillRect(x, y, +w, h)` from there covers bp-1 instead. The
 * error is one base wide — invisible zoomed out (cells floor to ~1px), a whole
 * base off zoomed in, and it only reproduces on flipped regions, so it survives
 * casual review. Every plugin that hand-rolled the pivot had to rediscover it;
 * the alignments pileup got it wrong across all five of its cell layers.
 *
 * Two-edge spans (`min(toX(start), toX(end))`) and boundary marks (insertions,
 * clip bars, centered on a bp edge) are orientation-safe already and don't need
 * this. The GPU side has no equivalent bug — shaders span
 * `bpToClipX(pos)`→`bpToClipX(pos+1)` unflipped and mirror via `flipX` — and
 * gets its own pivot from `writeBpRangeUniforms`.
 *
 * Callers own the cell *width*: it's a per-plugin rule (MAF uses the raw
 * bp-scale; the pileup floors at 1px and adds a seam fudge). Only the pivot is
 * shared.
 */
export declare function makeCellLeftMapper(bounds: BpRegionBounds): (bp: number) => number;
/**
 * Fill the rect covering genomic `[startBp, endBp)`, given a bare
 * `makeBpMapper`. Maps **both** edges and takes the leftmost, which is
 * orientation-safe by construction: on a reversed block bp runs leftward, so
 * the span's left edge is its *end*, and there is no pivot to get backwards.
 *
 * Prefer this to `makeCellLeftMapper` + a caller-computed width for anything
 * wider than one base. The pivot in `makeCellLeftMapper` is exactly one base,
 * which is right for a 1bp cell and silently wrong for an N-bp span — it
 * anchors the rect one base from the correct edge and then grows it the wrong
 * way. `fillBpSpan(bp, bp + 1)` is *identical* to the cell-mapper spelling, so
 * a per-base painter can use this too and never think about orientation again.
 *
 * `seam` is the caller's sub-pixel overlap (MAF's `GAP_STROKE_OFFSET`), added
 * to the width so adjacent cells don't show hairlines at ~1px/bp. Widening a
 * sub-pixel *feature* to a visible floor is a different job — that's
 * `spanLeft`, which must anchor the feature's start edge.
 */
export declare function fillBpSpan(ctx: {
    fillRect: (x: number, y: number, w: number, h: number) => void;
}, toX: (bp: number) => number, startBp: number, endBp: number, top: number, height: number, seam?: number): void;
/**
 * The **integer base** whose 1bp cell covers screen pixel `px` — the inverse of
 * `makeCellLeftMapper`, for hit-testing (which base did the cursor land on) as
 * opposed to painting.
 *
 * Rounding is not `Math.floor` on both orientations, which is the trap. The
 * un-rounded inverse of `makeBpMapper` lands in `[b, b+1)` on a forward block
 * but in `(b, b+1]` on a reversed one, because bp runs leftward there — so
 * flooring reversed names `b+1` on base `b`'s leftmost pixel column, and names
 * `end` (outside the block) on the block's first column. It is the same
 * one-base pivot `makeCellLeftMapper` exists to get right, seen from the other
 * direction, and it fails the same way: invisible zoomed out, a whole base off
 * at base zoom, and only on flipped regions.
 *
 * Callers own the *range* check: a `px` outside `[screenStartPx, screenEndPx)`
 * extrapolates rather than clamping, since which block owns a pixel is the
 * caller's decision (adjacent blocks share an edge pixel).
 */
export declare function bpAtPx(px: number, bounds: BpRegionBounds): number;
