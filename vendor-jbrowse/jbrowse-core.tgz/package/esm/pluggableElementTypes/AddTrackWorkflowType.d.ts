import PluggableElementBase from './PluggableElementBase.ts';
import type { IAnyModelType } from '@jbrowse/mobx-state-tree';
import type React from 'react';
type BasicComponent = React.ComponentType<{
    model: any;
    switchWorkflow: (name: string) => void;
}>;
type AddTrackWorkflowComponentType = React.LazyExoticComponent<BasicComponent> | BasicComponent;
export type AddTrackWorkflowCategory = 'general' | 'specialized';
export default class AddTrackWorkflow extends PluggableElementBase {
    ReactComponent: AddTrackWorkflowComponentType;
    category: AddTrackWorkflowCategory;
    stateModel: IAnyModelType;
    constructor(stuff: {
        name: string;
        displayName?: string;
        category?: AddTrackWorkflowCategory;
        ReactComponent: AddTrackWorkflowComponentType;
        stateModel: IAnyModelType;
    });
}
export {};
