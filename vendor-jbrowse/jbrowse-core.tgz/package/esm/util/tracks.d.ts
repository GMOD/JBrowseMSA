import type { BlobLocation, FileHandleLocation, FileLocation, PreFileLocation } from './types/index.ts';
import type { AnyConfigurationModel } from '../configuration/index.ts';
import type { IAnyStateTreeNode, IAnyType, Instance, types } from '@jbrowse/mobx-state-tree';
export declare function getTrackAssemblyNames(track: IAnyStateTreeNode & {
    configuration: AnyConfigurationModel;
}): string[];
export declare function getConfAssemblyNames(conf: AnyConfigurationModel): string[];
export declare function getRpcSessionId(thisNode: IAnyStateTreeNode): string;
export declare function getParentRenderProps(node: IAnyStateTreeNode): Record<string, unknown>;
export declare const UNKNOWN = "UNKNOWN";
export declare const UNSUPPORTED = "UNSUPPORTED";
export declare function getBlob(id: string): File | undefined;
export declare function getBlobMap(): Record<string, File>;
export declare function setBlobMap(map: Record<string, File>): void;
export declare function storeBlobLocation(location: PreFileLocation): BlobLocation | PreFileLocation;
export declare function getFileFromCache(handleId: string): File | undefined;
export declare function setFileInCache(handleId: string, file: File): void;
export declare function clearFileFromCache(handleId: string): void;
export declare function hasFileHandlesInCache(): boolean;
export declare function ensureFileHandleReady(handleId: string, requestPermission?: boolean): Promise<File>;
export declare function storeFileHandleLocation(handle: FileSystemFileHandle): Promise<FileHandleLocation>;
export declare function restoreFileHandles(handleIds: string[], requestPermission?: boolean): Promise<({
    error?: undefined;
    handleId: string;
    success: true;
} | {
    handleId: string;
    success: false;
    error: any;
})[]>;
export declare function findFileHandleIds(obj: unknown): Set<string>;
export declare function restoreFileHandlesFromSnapshot(sessionSnapshot: unknown, requestPermission?: boolean): Promise<({
    error?: undefined;
    handleId: string;
    success: true;
} | {
    handleId: string;
    success: false;
    error: any;
})[]>;
export declare function makeIndex(location: FileLocation, suffix: string): BlobLocation | FileHandleLocation | {
    uri: string;
    locationType: string;
    localPath?: undefined;
} | {
    uri?: undefined;
    localPath: string;
    locationType: string;
};
export declare function makeIndexType(name: string | undefined, typeA: string, typeB: string): string;
export interface AdapterConfig {
    type: string;
    [key: string]: unknown;
}
export type AdapterGuesser = (file: FileLocation, index?: FileLocation, adapterHint?: string) => AdapterConfig | undefined;
export type TrackTypeGuesser = (adapterName: string, file?: FileLocation) => string | undefined;
export declare function getFileName(track: FileLocation): string;
export declare function guessAdapter(file: FileLocation, index: FileLocation | undefined, adapterHint?: string, model?: IAnyStateTreeNode): AdapterConfig;
export declare function guessTrackType(adapterType: string, model?: IAnyStateTreeNode, file?: FileLocation): string;
export declare function generateUnsupportedTrackConf(trackName: string, trackUrl: string, categories: string[] | undefined): {
    type: string;
    name: string;
    description: string;
    category: string[] | undefined;
    trackId: string;
};
export declare function generateUnknownTrackConf(trackName: string, trackUrl: string, categories?: string[]): {
    type: string;
    name: string;
    description: string;
    category: string[] | undefined;
    trackId: string;
};
export declare function getTrackName(conf: AnyConfigurationModel | {
    name?: string;
    type?: string;
}, session: {
    assemblies: AnyConfigurationModel[];
}): string;
type MSTArray<T extends IAnyType> = Instance<ReturnType<typeof types.array<T>>>;
interface MinimalTrack extends IAnyType {
    configuration: {
        trackId: string;
    };
}
interface GenericView {
    type: string;
    tracks: MSTArray<MinimalTrack>;
}
interface DisplayInitialSnapshot {
    type?: string;
    [key: string]: unknown;
}
export declare function showTrackGeneric(self: GenericView, trackId: string, initialSnapshot?: {}, displayInitialSnapshot?: DisplayInitialSnapshot, inlineConf?: Record<string, unknown>): any;
interface DisplaySnapshot {
    id: string;
    [key: string]: unknown;
}
interface TrackSnapshot {
    id: string;
    displays: DisplaySnapshot[];
    [key: string]: unknown;
}
export declare function stripTrackIds(tracks: TrackSnapshot[]): {
    displays: {
        [key: string]: unknown;
    }[];
}[];
export declare function hideTrackGeneric(self: GenericView, trackId: string): boolean;
export declare function toggleTrackGeneric(self: GenericView, trackId: string): boolean;
export {};
