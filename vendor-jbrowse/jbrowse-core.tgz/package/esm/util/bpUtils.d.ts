import type { Region } from './types/index.ts';
export interface MinimalRegion {
    start: number;
    end: number;
    reversed?: boolean;
}
export declare function bpToPx(bp: number, { reversed, end, start, }: {
    start?: number;
    end?: number;
    reversed?: boolean;
}, bpPerPx: number): number;
export declare function bpSpanPx(leftBp: number, rightBp: number, region: MinimalRegion, bpPerPx: number): readonly [number, number];
export declare function featureSpanPx(feature: {
    get: (key: string) => number;
}, region: MinimalRegion, bpPerPx: number): readonly [number, number];
export declare function getBpDisplayStr(total: number): string;
export declare function getTickDisplayStr(totalBp: number, bpPerPx: number): string;
interface VirtualOffset {
    blockPosition: number;
}
interface Block {
    minv: VirtualOffset;
    maxv: VirtualOffset;
}
export declare function bytesForRegions(regions: Region[], index: {
    blocksForRange: (ref: string, start: number, end: number) => Promise<Block[]>;
}): Promise<number>;
export {};
