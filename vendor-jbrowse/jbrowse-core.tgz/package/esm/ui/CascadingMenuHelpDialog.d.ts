export default function CascadingMenuHelpDialog({ onClose, helpText, label, }: {
    onClose: () => void;
    helpText: React.ReactNode;
    label?: React.ReactNode;
}): import("react").JSX.Element;
