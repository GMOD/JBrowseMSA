export declare function aesEncrypt(plaintext: string, password: string): Promise<string>;
export declare function aesDecrypt(ciphertext: string, password: string): Promise<string>;
export declare function sha256(data: string): Promise<Uint8Array>;
export declare function toBase64(data: Uint8Array): string;
export declare function toBase64Url(data: Uint8Array): string;
export declare function sha256Base64(data: string): Promise<string>;
export declare function sha256Base64Url(data: string): Promise<string>;
