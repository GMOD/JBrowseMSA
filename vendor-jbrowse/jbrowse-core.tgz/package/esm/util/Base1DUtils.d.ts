import type { ContentBlock } from './blockTypes.ts';
export interface BpOffset {
    refName?: string;
    index: number;
    offset: number;
    start?: number;
    end?: number;
}
/**
 * Offset in bp from a displayed region's **left screen edge**, which is its end
 * when the region is reversed. This one reflection is what "reversed" means
 * everywhere in a linear view: `bpToPx` below, the ruler's ticks
 * (`LinearGenomeView/util.ts`), and any display placing a feature against a
 * single block. Reach for it instead of writing `pos - region.start`, which
 * silently lays out forward under a right-to-left ruler.
 */
export declare function bpOffsetInRegion(region: {
    start: number;
    end: number;
    reversed?: boolean;
}, bp: number): number;
interface RegionSnap {
    start: number;
    end: number;
    refName: string;
    reversed?: boolean;
    assemblyName: string;
}
interface MoveSnap {
    displayedRegions: {
        start: number;
        end: number;
    }[];
    width: number;
}
export interface ViewLayout {
    displayedRegions: RegionSnap[];
    bpPerPx: number;
    offsetPx: number;
    width: number;
    minimumBlockWidth: number;
}
export declare function moveTo(self: MoveSnap & {
    zoomTo: (arg: number) => number;
    scrollTo: (arg: number) => void;
}, start?: BpOffset, end?: BpOffset): void;
/**
 * Pure version of moveTo: returns the {bpPerPx, offsetPx} that moveTo would
 * apply, without mutating any model. Assumes no bpPerPx clamping (i.e.
 * Base1DView with no min/maxBpPerPx).
 */
export declare function computeMoveToLayout(self: MoveSnap, start: BpOffset, end: BpOffset): {
    bpPerPx: number;
    offsetPx: number;
};
/**
 * The base **painted** at a pixel. Pair it with `pxToBp`'s `offset` field, and
 * only once you know the pixel is in bounds (`!oob`) — off the end of a region
 * no base is painted and the question has no answer.
 *
 * Use this rather than `coord0` whenever the result indexes per-base data: a
 * sequence string, a coverage bin, a per-base tooltip. Reversed, bp runs
 * leftward, so base b covers offsets (b, b+1] — `coord0`'s floor names b+1 on
 * b's leftmost pixel column, and names `r.end`, outside the region entirely, on
 * the region's first column.
 *
 * This is the same one-base pivot as render-core's `makeCellLeftMapper` /
 * `bpAtPx`, which is what the per-base painters draw with, so this is the
 * readout that agrees with what is on screen. The pivot is spelled out again
 * here rather than shared because core does not depend on render-core.
 */
export declare function basePaintedAt(r: {
    start: number;
    end: number;
    reversed?: boolean;
}, offsetBp: number): number;
export interface PxToBpResult extends RegionSnap {
    coord: number;
    coord0: number;
    index: number;
    oob: boolean;
    offset: number;
}
export declare function pxToBp(self: ViewLayout, px: number): PxToBpResult;
export declare function offsetBpToPx(self: ViewLayout, regionIndex: number, regionOffsetBp: number): number;
export declare function bpToPx({ refName, coord, displayedRegionIndex, self, }: {
    refName: string;
    coord: number;
    displayedRegionIndex?: number;
    self: ViewLayout;
}): {
    index: number;
    offsetPx: number;
} | undefined;
export declare function layoutBpToPx(layout: ViewLayout, args: {
    refName: string;
    coord: number;
    displayedRegionIndex?: number;
}): number | undefined;
export declare function getLayoutHighlightCoords(layout: ViewLayout, region: {
    refName: string;
    start: number;
    end: number;
}, minWidth?: number): {
    width: number;
    left: number;
} | undefined;
export declare function createOverviewLayout({ displayedRegions, width, minimumBlockWidth, }: {
    displayedRegions: RegionSnap[];
    width: number;
    minimumBlockWidth?: number;
}): ViewLayout;
export declare function getContentBlocksPxSpan(layout: ViewLayout, contentBlocks: ContentBlock[]): {
    leftPx: number;
    rightPx: number;
} | undefined;
export {};
