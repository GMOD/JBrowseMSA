import type { Ref } from 'react';
import type { TypographyProps } from '@mui/material';
type Variant = TypographyProps['variant'];
type EditableTypographyClassKey = 'input' | 'inputBase' | 'inputRoot' | 'inputFocused';
interface Props {
    value: string;
    setValue: (value: string) => void;
    variant: Variant;
    classes?: Partial<Record<EditableTypographyClassKey, string>>;
    ref?: Ref<HTMLDivElement>;
}
declare function EditableTypography(props: Props): import("react").JSX.Element;
export default EditableTypography;
