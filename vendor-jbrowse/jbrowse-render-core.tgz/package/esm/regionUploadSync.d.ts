interface RegionUploadTarget<T> {
    uploadRegion(displayedRegionIndex: number, data: T): void;
    pruneRegions(active: Iterable<number>): void;
}
export declare function createRegionUploadSync<T, B extends RegionUploadTarget<T>>(): (backend: B, regions: ReadonlyMap<number, T>) => void;
export {};
