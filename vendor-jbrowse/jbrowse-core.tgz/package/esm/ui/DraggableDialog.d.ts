import type { DialogProps } from '@mui/material';
declare const DraggableDialog: (props: DialogProps & {
    title: string;
}) => import("react").JSX.Element;
export default DraggableDialog;
