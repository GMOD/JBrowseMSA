import type { Feature } from './simpleFeature.ts';
import type { NoAssemblyRegion } from './types/index.ts';
import type { Observable } from 'rxjs';
export interface UnrectifiedQuantitativeStats {
    scoreMin: number;
    scoreMax: number;
    scoreSum: number;
    scoreSumSquares: number;
    featureCount?: number;
    basesCovered: number;
    scoreMeanMin?: number;
    scoreMeanMax?: number;
}
export interface RectifiedQuantitativeStats extends UnrectifiedQuantitativeStats {
    featureDensity: number;
    scoreMean: number;
    scoreStdDev: number;
}
export interface QuantitativeStats extends RectifiedQuantitativeStats {
    currStatsBpPerPx: number;
}
export declare function calcStdFromSums(sum: number, sumSquares: number, n: number, population?: boolean): number;
export declare function rectifyStats(s: UnrectifiedQuantitativeStats): RectifiedQuantitativeStats;
export declare function scoresToStats(region: NoAssemblyRegion, feats: Observable<Feature>): Promise<RectifiedQuantitativeStats>;
export declare function blankStats(): RectifiedQuantitativeStats;
