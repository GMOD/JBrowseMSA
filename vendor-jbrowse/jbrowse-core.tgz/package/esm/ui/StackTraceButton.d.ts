import type { IconButtonProps } from '@mui/material';
export default function StackTraceButton({ error, color, }: {
    error: unknown;
    color?: IconButtonProps['color'];
}): import("react").JSX.Element;
