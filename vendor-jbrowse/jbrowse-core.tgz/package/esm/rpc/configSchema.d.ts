declare const _default: import("../configuration/configurationSchema.ts").ConfigurationSchemaType<{
    defaultDriver: {
        type: string;
        description: string;
        defaultValue: string;
        advanced: true;
    };
    workerCount: {
        type: string;
        description: string;
        defaultValue: number;
        advanced: true;
    };
}, import("../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
export default _default;
