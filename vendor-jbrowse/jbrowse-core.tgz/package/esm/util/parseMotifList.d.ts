export interface ParsedMotif {
    name: string;
    site: string;
    cutOffset?: number;
}
export interface MotifParseError {
    line: number;
    text: string;
    message: string;
}
export interface MotifListParse {
    motifs: ParsedMotif[];
    errors: MotifParseError[];
}
export declare function parseMotifList(text: string): MotifListParse;
