import type { ErrorObject } from './serializeError/index.ts';
type Listener = (arg: unknown) => void;
interface RpcMessageData {
    uid: string;
    libRpc?: true;
    error?: string | ErrorObject;
    eventName?: string;
    data?: unknown;
}
interface PendingCall {
    resolve: (data: unknown) => void;
    reject: (error: Error) => void;
}
export default class RpcClient {
    worker: Worker;
    pending: Map<string, PendingCall>;
    private events;
    private counter;
    constructor(worker: Worker);
    on(event: string, listener: Listener): this;
    off(event: string, listener: Listener): this;
    emit(event: string, data: unknown): this;
    protected handler(e: MessageEvent<RpcMessageData>): void;
    destroy(): void;
    private rejectAllPending;
    protected catch(e: ErrorEvent): void;
    protected reject(uid: string, error: string | ErrorObject): void;
    protected resolve(uid: string, data: unknown): void;
    /**
     * Tell this worker that a stop token has been stopped, so the calls running
     * there see it at their next await boundary and drop their in-flight reads.
     * Fire-and-forget: it settles no pending call, and a worker holding nothing
     * under that id ignores it.
     */
    notifyStopToken(id: string): void;
    call(method: string, data: unknown, { transferables }?: {
        transferables?: Transferable[];
    }): Promise<unknown>;
}
export {};
