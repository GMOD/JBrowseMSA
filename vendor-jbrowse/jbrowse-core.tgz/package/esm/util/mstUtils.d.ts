import type PluginManager from '../PluginManager.ts';
import type { AbstractDisplayModel, AbstractSessionModel, AbstractTrackModel, AbstractViewModel, TypeTestedByPredicate } from './types/index.ts';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
export declare function findParentThat(node: IAnyStateTreeNode, predicate: (thing: IAnyStateTreeNode) => boolean): import("@jbrowse/mobx-state-tree").IStateTreeNode<IAnyStateTreeNode> | (object & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IAnyComplexType>);
export declare function findParentThatIs<T extends (a: IAnyStateTreeNode) => boolean>(node: IAnyStateTreeNode, predicate: T): TypeTestedByPredicate<T>;
/**
 * #api core/util
 * Returns the JBrowse session model for any node in the state tree. Throws if
 * the node has no session ancestor.
 */
export declare function getSession(node: IAnyStateTreeNode): AbstractSessionModel;
/**
 * #api core/util
 * Returns the view model that contains the given node. Throws if the node has no
 * containing view.
 */
export declare function getContainingView(node: IAnyStateTreeNode): AbstractViewModel;
/**
 * #api core/util
 * Returns the track model that contains the given node. Throws if the node has
 * no containing track.
 */
export declare function getContainingTrack(node: IAnyStateTreeNode): AbstractTrackModel;
/**
 * #api core/util
 * Returns the display model that contains the given node. Throws if the node has
 * no containing display.
 */
export declare function getContainingDisplay(node: IAnyStateTreeNode): AbstractDisplayModel;
/**
 * #api core/util
 * Returns the MST environment for a node, which carries the `pluginManager`.
 */
export declare function getEnv(obj: IAnyStateTreeNode): {
    pluginManager: PluginManager;
};
export declare function hashCode(str: string): number;
export declare function objectHash(obj: object): string;
