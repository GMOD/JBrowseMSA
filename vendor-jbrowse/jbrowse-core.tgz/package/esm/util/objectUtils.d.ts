export declare function isObject(x: unknown): x is Record<string | symbol | number, unknown>;
