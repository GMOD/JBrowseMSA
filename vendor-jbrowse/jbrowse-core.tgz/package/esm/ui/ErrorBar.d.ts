import type { ReactNode } from 'react';
export default function ErrorBar({ error, onRetry, extraAction, }: {
    error: unknown;
    onRetry: () => void;
    extraAction?: ReactNode;
}): import("react").JSX.Element;
