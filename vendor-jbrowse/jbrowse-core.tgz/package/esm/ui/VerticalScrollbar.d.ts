import type React from 'react';
export default function VerticalScrollbar({ scrollTop, setScrollTop, viewportHeight, contentHeight, top, }: {
    scrollTop: number;
    setScrollTop: (n: number) => void;
    viewportHeight: number;
    contentHeight: number;
    top?: number;
}): React.JSX.Element | null;
