import type { ComponentType } from 'react';
import PhasedScheduler from './PhasedScheduler.ts';
import type Plugin from './Plugin.ts';
import type { PluginDefinition } from './PluginLoader.ts';
import type AdapterType from './pluggableElementTypes/AdapterType.ts';
import type AddTrackWorkflowType from './pluggableElementTypes/AddTrackWorkflowType.ts';
import type ConnectionType from './pluggableElementTypes/ConnectionType.ts';
import type DisplayType from './pluggableElementTypes/DisplayType.ts';
import type GlyphType from './pluggableElementTypes/GlyphType.ts';
import type InternetAccountType from './pluggableElementTypes/InternetAccountType.ts';
import type PluggableElementBase from './pluggableElementTypes/PluggableElementBase.ts';
import type RpcMethodType from './pluggableElementTypes/RpcMethodType.ts';
import type TextSearchAdapterType from './pluggableElementTypes/TextSearchAdapterType.ts';
import type TrackType from './pluggableElementTypes/TrackType.ts';
import type ViewType from './pluggableElementTypes/ViewType.ts';
import type WidgetType from './pluggableElementTypes/WidgetType.ts';
import type { PluggableElementType } from './pluggableElementTypes/index.ts';
import type { AbstractRootModel, AbstractSessionModel, SimpleFeatureSerialized } from './util/index.ts';
import type { IAnyModelType, IAnyStateTreeNode, IAnyType } from '@jbrowse/mobx-state-tree';
type PluggableElementTypeGroup = 'adapter' | 'display' | 'track' | 'connection' | 'view' | 'widget' | 'rpc method' | 'internet account' | 'text search adapter' | 'add track workflow' | 'glyph';
declare class TypeRecord<ElementClass extends PluggableElementBase> {
    registeredTypes: Record<string, ElementClass>;
    typeName: string;
    constructor(typeName: string);
    add(name: string, t: ElementClass): void;
    has(name: string): boolean;
    get(name: string): ElementClass;
    all(): ElementClass[];
}
type AnyFunction = (...args: any) => any;
type ExtensionPointCallback = (extendee: unknown, props?: Record<string, unknown>) => unknown;
type FeatureWidgetModel = IAnyStateTreeNode & {
    trackId?: string;
    trackType?: string;
};
type WidgetModel = FeatureWidgetModel & {
    type: string;
};
export interface FeaturePanelProps {
    model: FeatureWidgetModel;
    feature: SimpleFeatureSerialized;
}
export interface ReplaceWidgetProps {
    session: AbstractSessionModel;
    model: WidgetModel;
    toolbarHeight?: number;
}
export interface ExtensionPointRegistry {
    'Core-extendPluggableElement': {
        args: PluggableElementType;
        result: PluggableElementType;
    };
    'Core-extraFeaturePanel': {
        args: ComponentType<FeaturePanelProps>[];
        result: ComponentType<FeaturePanelProps>[];
        props: FeaturePanelProps;
    };
    'Core-replaceWidget': {
        args: ComponentType<ReplaceWidgetProps>;
        result: ComponentType<ReplaceWidgetProps>;
        props: ReplaceWidgetProps;
    };
}
export type ExtensionPointName = keyof ExtensionPointRegistry;
export type ExtensionPointArgs<N extends ExtensionPointName> = ExtensionPointRegistry[N]['args'];
export type ExtensionPointResult<N extends ExtensionPointName> = ExtensionPointRegistry[N]['result'];
export type ExtensionPointProps<N extends ExtensionPointName> = 'props' extends keyof ExtensionPointRegistry[N] ? ExtensionPointRegistry[N]['props'] : Record<string, unknown>;
export interface PluginMetadata {
    isCore?: boolean;
    url?: string;
    [key: string]: unknown;
}
export interface PluginLoadRecord {
    metadata?: PluginMetadata;
    plugin: Plugin;
}
export interface RuntimePluginLoadRecord extends PluginLoadRecord {
    definition: PluginDefinition;
}
export default class PluginManager {
    plugins: Plugin[];
    jexl: import("@jbrowse/jexl").Jexl;
    pluginMetadata: Record<string, PluginMetadata>;
    runtimePluginDefinitions: PluginDefinition[];
    elementCreationSchedule: PhasedScheduler<PluggableElementTypeGroup>;
    pluggableElementsCreated: boolean;
    glyphTypes: TypeRecord<GlyphType>;
    adapterTypes: TypeRecord<AdapterType>;
    textSearchAdapterTypes: TypeRecord<TextSearchAdapterType>;
    trackTypes: TypeRecord<TrackType>;
    displayTypes: TypeRecord<DisplayType>;
    connectionTypes: TypeRecord<ConnectionType>;
    viewTypes: TypeRecord<ViewType>;
    widgetTypes: TypeRecord<WidgetType>;
    rpcMethods: TypeRecord<RpcMethodType>;
    addTrackWidgets: TypeRecord<AddTrackWorkflowType>;
    internetAccountTypes: TypeRecord<InternetAccountType>;
    configured: boolean;
    rootModel?: AbstractRootModel;
    extensionPoints: Map<string, ExtensionPointCallback[]>;
    trackConfigHydrationCache: WeakMap<object, WeakMap<object, unknown>>;
    constructor(initialPlugins?: (Plugin | PluginLoadRecord)[]);
    pluginConfigurationNamespacedSchemas(): Record<string, unknown>;
    pluginConfigurationUnnamespacedSchemas(): Record<string, unknown>;
    pluginConfigurationRootSchemas(): Record<string, unknown>;
    addPlugin(load: Plugin | PluginLoadRecord | RuntimePluginLoadRecord): this;
    getPlugin(name: string): Plugin | undefined;
    hasPlugin(name: string): boolean;
    removePlugin(pluginName: string): this;
    createPluggableElements(): this;
    setRootModel(rootModel: AbstractRootModel): this;
    configure(): this;
    getElementTypeRecord(groupName: PluggableElementTypeGroup): TypeRecord<PluggableElementBase>;
    addElementType(groupName: PluggableElementTypeGroup, creationCallback: (pluginManager: PluginManager) => PluggableElementType): this;
    getElementType(groupName: PluggableElementTypeGroup, typeName: string): PluggableElementBase;
    getElementTypesInGroup(groupName: PluggableElementTypeGroup): PluggableElementBase[];
    getViewElements(): ViewType[];
    getTrackElements(): TrackType[];
    getConnectionElements(): ConnectionType[];
    getAddTrackWorkflowElements(): AddTrackWorkflowType[];
    getRpcElements(): RpcMethodType[];
    getDisplayElements(): DisplayType[];
    getAdapterElements(): AdapterType[];
    pluggableMstType(groupName: PluggableElementTypeGroup, fieldName: string, fallback?: IAnyType): IAnyType;
    pluggableConfigSchemaType(typeGroup: PluggableElementTypeGroup, fieldName?: string): IAnyModelType;
    jbrequireCache: Map<any, any>;
    lib: any;
    load: <FTYPE extends AnyFunction>(lib: FTYPE) => ReturnType<FTYPE>;
    jbrequire: (lib: string | AnyFunction | {
        default: AnyFunction;
    }) => any;
    getAdapterType(typeName: string): AdapterType;
    getTextSearchAdapterType(typeName: string): TextSearchAdapterType;
    getTrackType(typeName: string): TrackType;
    getDisplayType(typeName: string): DisplayType;
    getViewType(typeName: string): ViewType;
    getAddTrackWorkflow(typeName: string): AddTrackWorkflowType;
    getWidgetType(typeName: string): WidgetType;
    getConnectionType(typeName: string): ConnectionType;
    getRpcMethodType(methodName: string): RpcMethodType;
    getInternetAccountType(name: string): InternetAccountType;
    addAdapterType(cb: (pm: PluginManager) => AdapterType): this;
    addTextSearchAdapterType(cb: (pm: PluginManager) => TextSearchAdapterType): this;
    addTrackType(cb: (pm: PluginManager) => TrackType): this;
    addDisplayType(cb: (pluginManager: PluginManager) => DisplayType): this;
    addViewType(cb: (pluginManager: PluginManager) => ViewType): this;
    addWidgetType(cb: (pm: PluginManager) => WidgetType): this;
    addConnectionType(cb: (pm: PluginManager) => ConnectionType): this;
    addRpcMethod(cb: (pm: PluginManager) => RpcMethodType): this;
    addInternetAccountType(cb: (pm: PluginManager) => InternetAccountType): this;
    addAddTrackWorkflowType(cb: (pm: PluginManager) => AddTrackWorkflowType): this;
    addGlyphType(cb: (pm: PluginManager) => GlyphType): this;
    getGlyphType(typeName: string): GlyphType;
    getGlyphTypes(): GlyphType[];
    addToExtensionPoint<N extends ExtensionPointName>(extensionPointName: N, callback: (extendee: ExtensionPointArgs<N>, props: ExtensionPointProps<N>) => ExtensionPointResult<N> | Promise<ExtensionPointResult<N>>): void;
    addToExtensionPoint<T>(extensionPointName: string, callback: (extendee: T, props: Record<string, unknown>) => T): void;
    evaluateExtensionPoint<N extends ExtensionPointName>(extensionPointName: N, extendee: ExtensionPointArgs<N>, props?: ExtensionPointProps<N>): ExtensionPointResult<N>;
    evaluateExtensionPoint(extensionPointName: string, extendee: unknown, props?: Record<string, unknown>): unknown;
    evaluateAsyncExtensionPoint<N extends ExtensionPointName>(extensionPointName: N, extendee: ExtensionPointArgs<N>, props?: ExtensionPointProps<N>): Promise<ExtensionPointResult<N>>;
    evaluateAsyncExtensionPoint(extensionPointName: string, extendee: unknown, props?: Record<string, unknown>): Promise<unknown>;
}
export {};
