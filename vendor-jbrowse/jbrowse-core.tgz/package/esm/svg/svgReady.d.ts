export interface SvgExportable {
    svgReady: boolean;
    error: unknown;
}
export declare function awaitSvgReady(model: Pick<SvgExportable, 'svgReady'>): Promise<void> & {
    cancel(): void;
};
