/**
 * Static augmented interval tree: returns the values whose interval overlaps a
 * query interval.
 *
 * Replaces a vendored red-black implementation. Every JBrowse caller builds the
 * tree fully (many `insert`s) and then only queries it (`search`) — never
 * interleaving inserts with searches and never deleting — so the self-balancing
 * machinery (rotations, color fixups, parent pointers, nil sentinels) was
 * unnecessary. Intervals are collected on `insert`; a balanced tree is built
 * lazily on the first `search` via recursive median split, giving O(n log n)
 * build and O(log n + k) query.
 *
 * Originally vendored from @flatten-js/interval-tree (MIT, Alex Bol).
 */
export declare class IntervalTree<V> {
    private intervals;
    private root;
    private built;
    insert(key: [number, number], value: V): void;
    search(interval: [number, number]): V[];
}
