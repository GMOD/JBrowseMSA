import type { CSSProperties, ReactNode } from 'react';
import type BaseResult from '../../TextSearch/BaseResults.ts';
import type { AbstractSessionModel } from '../../util/index.ts';
declare const RefNameAutocomplete: ({ session, assemblyName, value, fetchResults, onSelect, onChange, minWidth, maxWidth, style, endAdornment, helperText, inputStyle, }: {
    session: AbstractSessionModel;
    assemblyName?: string;
    value?: string;
    fetchResults: (query: string) => Promise<BaseResult[]>;
    onSelect?: (region: BaseResult) => void;
    onChange?: (val: string) => void;
    minWidth?: number;
    maxWidth?: number;
    style?: CSSProperties;
    endAdornment?: ReactNode;
    helperText?: string;
    inputStyle?: CSSProperties;
}) => import("react").JSX.Element;
export default RefNameAutocomplete;
export { default as RefNameAutocompleteEndAdornment } from './EndAdornment.tsx';
