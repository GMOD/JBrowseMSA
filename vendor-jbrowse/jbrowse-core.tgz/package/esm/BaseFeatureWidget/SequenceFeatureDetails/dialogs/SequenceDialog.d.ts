import type { SimpleFeatureSerialized } from '../../../util/index.ts';
import type { ErrorState, SeqState } from '../../util.tsx';
import type { SequenceDisplayMode, SequenceFeatureDetailsModel } from '../model.ts';
declare const SequenceDialog: ({ handleClose, sequenceFeatureDetails, feature, mode, setMode, sequence, error, assemblyGeneticCodeId, onForceLoad, }: {
    handleClose: () => void;
    feature: SimpleFeatureSerialized;
    sequenceFeatureDetails: SequenceFeatureDetailsModel;
    mode: SequenceDisplayMode;
    setMode: (mode: SequenceDisplayMode) => void;
    sequence: SeqState | ErrorState | undefined;
    error: unknown;
    assemblyGeneticCodeId?: number;
    onForceLoad: () => void;
}) => import("react").JSX.Element;
export default SequenceDialog;
