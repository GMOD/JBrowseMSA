import type TextSearchManager from '../../TextSearch/TextSearchManager.ts';
import type assemblyManager from '../../assemblyManager/index.ts';
import type { AnyConfigurationModel, ResolvableDisplay } from '../../configuration/index.ts';
import type { BaseInternetAccountModel } from '../../pluggableElementTypes/models/index.ts';
import type { PluginDefinition } from '../../pluginDefinitions.ts';
import type RpcManager from '../../rpc/RpcManager.ts';
import type { MenuItem, SerializableThemeArgs } from '../../ui/index.ts';
import type { JBrowsePalette } from '../../ui/palette.ts';
import type { Feature } from '../simpleFeature.ts';
import type { TrackConfigChange } from '../trackConfigDelta.ts';
import type { BlobLocation as MUBlobLocation, FileHandleLocation as MUFileHandleLocation, Region as MUIRegion, LocalPathLocation as MULocalPathLocation, NoAssemblyRegion as MUNoAssemblyRegion, UriLocation as MUUriLocation } from './mst.ts';
import type { IAnyStateTreeNode, IStateTreeNode, Instance, SnapshotIn } from '@jbrowse/mobx-state-tree';
import type { Theme, ThemeOptions } from '@mui/material';
import type React from 'react';
export type { AnyReactComponentType, ClassReturnedBy, InstanceTypeRestrictive, TypeTestedByPredicate, } from './util.ts';
/** abstract type for a model that contains multiple views */
export interface AbstractViewContainer extends IStateTreeNode {
    views: AbstractViewModel[];
    removeView(view: AbstractViewModel): void;
    addView(typeName: string, initialState?: Record<string, unknown>): AbstractViewModel;
}
export declare function isViewContainer(thing: unknown): thing is AbstractViewContainer;
export type NotificationLevel = 'error' | 'info' | 'warning' | 'success';
export interface SnackAction {
    name: React.ReactElement | string;
    onClick: () => void;
}
export type AssemblyManager = Instance<ReturnType<typeof assemblyManager>>;
export interface BasePlugin {
    version?: string;
    name: string;
    url?: string;
}
export interface JBrowsePluginVersion {
    pluginVersion: string;
    jbrowseRange: string;
    url?: string;
    umdUrl?: string;
    esmUrl?: string;
    cjsUrl?: string;
    integrity?: string;
}
export interface JBrowsePlugin {
    name: string;
    packageName?: string;
    authors: string[];
    description: string;
    location: string;
    url?: string;
    umdUrl?: string;
    esmUrl?: string;
    cjsUrl?: string;
    integrity?: string;
    versions?: JBrowsePluginVersion[];
    license: string;
    image?: string;
}
export type DialogComponentType = React.LazyExoticComponent<React.FC<any>> | React.FC<any>;
/**
 * the slice of a view that track-action menu items need: opening a track, and
 * (for views that show tracks) reporting which display is active for a given
 * track so the config editor can expand it and collapse the rest
 */
export interface TrackActionView {
    showTrack: (id: string) => void;
    getActiveDisplayId?: (trackId: string) => string | undefined;
}
/**
 * controls feature-layout animations. 'system' respects the OS
 * prefers-reduced-motion setting, 'enabled' always animates, 'disabled' never
 * animates
 */
export type AnimationMode = 'system' | 'enabled' | 'disabled';
/** minimum interface that all session state models must implement */
export interface AbstractSessionModel extends AbstractViewContainer {
    getTrackById: (id: string) => AnyConfigurationModel | undefined;
    /** @deprecated prefer the per-id reactive `getTrackById(id)` */
    getTracksById: () => Record<string, AnyConfigurationModel>;
    jbrowse: IAnyStateTreeNode;
    drawerPosition?: string;
    configuration: AnyConfigurationModel;
    rpcManager: RpcManager;
    assemblyNames: string[];
    assemblies: AnyConfigurationModel[];
    selection?: unknown;
    focusedViewId?: string;
    themeName?: string;
    palette: JBrowsePalette;
    theme: Theme;
    themeOptions?: SerializableThemeArgs;
    animationMode: AnimationMode;
    scrollZoom: boolean;
    highlightsVisible: boolean;
    setHighlightsVisible: (arg: boolean) => void;
    revealHighlights: () => void;
    getPreference: (key: string) => unknown;
    setPreferenceOverride: (key: string, value: unknown) => void;
    clearPreferenceOverrides: () => void;
    setScrollZoom: (flag: boolean) => void;
    getDisplayTypeDefault: (displayType: string, slot: string) => unknown;
    setDisplayTypeDefault: (displayType: string, slot: string, value: unknown) => void;
    hovered: unknown;
    setHovered: (arg: unknown) => void;
    setFocusedViewId?: (id: string) => void;
    allThemes?: () => Record<string, ThemeOptions & {
        name?: string;
    }>;
    getActiveThemeOptions?: (name?: string) => (ThemeOptions & {
        name?: string;
    }) | undefined;
    setSelection: (feature: Feature) => void;
    setSession?: (arg: {
        name: string;
        [key: string]: unknown;
    }) => void;
    clearSelection: () => void;
    duplicateCurrentSession?: () => void;
    notify: (message: string, level?: NotificationLevel, action?: SnackAction) => void;
    notifyError: (message: string, error?: unknown, extra?: unknown, action?: SnackAction) => void;
    assemblyManager: AssemblyManager;
    version: string;
    gitCommit?: string;
    getTrackActionMenuItems?: (arg: {
        config: AnyConfigurationModel;
        view?: TrackActionView;
    }) => MenuItem[];
    getTrackActions?: (arg: AnyConfigurationModel, view?: TrackActionView) => MenuItem[];
    getTrackListMenuItems?: (arg: AnyConfigurationModel, view?: TrackActionView) => MenuItem[];
    addAssembly?: (conf: Record<string, unknown>) => void;
    addSessionAssembly?: (conf: Record<string, unknown>) => void;
    sessionAssemblies?: AnyConfigurationModel[];
    removeAssembly?: (name: string) => void;
    textSearchManager?: TextSearchManager;
    connections: AnyConfigurationModel[];
    deleteConnection?: (arg: AnyConfigurationModel) => void;
    temporaryAssemblies?: unknown[];
    addTemporaryAssembly?: (arg: Record<string, unknown>) => void;
    removeTemporaryAssembly?: (arg: string) => void;
    sessionConnections?: AnyConfigurationModel[];
    sessionTracks?: AnyConfigurationModel[];
    trackConfigDeltas?: Record<string, {
        trackId: string;
        [key: string]: unknown;
    }>;
    getTrackConfigChanges?: (trackId: string) => TrackConfigChange[];
    resetTrackConfiguration?: (trackId: string) => void;
    connectionInstances?: ConnectionInstance[];
    connectionTrackConfigs?: Record<string, {
        connectionId: string;
        config: Record<string, unknown>;
    }>;
    makeConnection?: (arg: AnyConfigurationModel) => void;
    breakConnection?: (arg: AnyConfigurationModel) => void;
    captureConnectionTrack?: (trackId: string) => void;
    pruneConnectionTrackConfig?: (trackId: string) => void;
    hydrateConnection?: (connectionId: string) => void;
    adminMode: boolean;
    showWidget?: (widget: unknown) => void;
    addWidget?: (typeName: string, id: string, initialState?: Record<string, unknown>, configuration?: {
        type: string;
    }) => Widget;
    DialogComponent?: DialogComponentType;
    DialogProps: Record<string, unknown> | undefined;
    queueDialog<T extends DialogComponentType>(callback: (doneCallback: () => void) => [T, React.ComponentProps<T>]): void;
    name: string;
    id?: string;
    tracks: AnyConfigurationModel[];
}
export declare function isSessionModel(thing: unknown): thing is AbstractSessionModel;
/** abstract interface for a session allows editing configurations */
export interface SessionWithConfigEditing extends AbstractSessionModel {
    editConfiguration(configuration: AnyConfigurationModel, opts?: {
        expandedDisplayId?: string;
    }): void;
    updateTrackConfiguration(trackConf: {
        trackId: string;
        [key: string]: unknown;
    }): void;
}
export declare function isSessionModelWithConfigEditing(t: unknown): t is SessionWithConfigEditing;
/** abstract interface for a session allows adding tracks */
export interface SessionWithAddTracks extends AbstractSessionModel {
    addTrackConf(configuration: AnyConfigurationModel | SnapshotIn<AnyConfigurationModel>): AnyConfigurationModel | undefined;
}
export declare function isSessionWithAddTracks(t: unknown): t is SessionWithAddTracks;
/** abstract interface for a session that allows adding session assemblies */
export interface SessionWithAddAssembly extends AbstractSessionModel {
    addSessionAssembly(conf: Record<string, unknown>): void;
}
export declare function isSessionWithAddAssembly(t: unknown): t is SessionWithAddAssembly;
/** abstract interface for a session that allows deleting track configs */
export interface SessionWithDeleteTrackConf extends AbstractSessionModel {
    deleteTrackConf(configuration: AnyConfigurationModel): void;
}
export declare function isSessionWithDeleteTrackConf(t: unknown): t is SessionWithDeleteTrackConf;
/** abstract interface for a session allows adding tracks */
export interface SessionWithShareURL extends AbstractSessionModel {
    shareURL: string;
}
export declare function isSessionWithShareURL(thing: unknown): thing is SessionWithShareURL;
export interface Widget {
    type: string;
    id: string;
    view?: {
        id: string;
    };
}
/** Minimal map interface compatible with both native Map and MST IMSTMap */
export interface WidgetMap<K, V> {
    size: number;
    has(key: K): boolean;
    get(key: K): V | undefined;
    keys(): IterableIterator<K>;
    values(): IterableIterator<V>;
    entries(): IterableIterator<[K, V]>;
    forEach(callbackfn: (value: V, key: K) => void): void;
    [Symbol.iterator](): IterableIterator<[K, V]>;
}
/** abstract interface for a session that manages widgets */
export interface SessionWithWidgets extends AbstractSessionModel {
    minimized: boolean;
    visibleWidget?: Widget;
    widgets: WidgetMap<string, Widget>;
    activeWidgets: WidgetMap<string, Widget>;
    hideAllWidgets: () => void;
    addWidget(typeName: string, id: string, initialState?: Record<string, unknown>, configuration?: {
        type: string;
    }): Widget;
    showWidget(widget: unknown): void;
    hideWidget(widget: unknown): void;
}
export interface SessionWithDrawerWidgets extends SessionWithWidgets {
    drawerWidth: number;
    resizeDrawer(arg: number): number;
    minimizeWidgetDrawer(): void;
    showWidgetDrawer: () => void;
    drawerPosition: string;
    setDrawerPosition(arg: string): void;
    /** true while the visible widget is shown in a modal instead of the drawer */
    poppedOut: boolean;
    popoutWidget(): void;
    returnWidgetToDrawer(): void;
}
export declare function isSessionModelWithWidgets(thing: unknown): thing is SessionWithWidgets;
/** a live connection instance held in a session's `connectionInstances` */
export interface ConnectionInstance {
    name: string;
    connectionId: string;
    tracks: AnyConfigurationModel[];
    configuration: AnyConfigurationModel;
    loading: boolean;
}
/** a session that can turn connections on and off */
export interface SessionWithConnections extends AbstractSessionModel {
    connectionInstances: ConnectionInstance[];
    makeConnection: (arg: AnyConfigurationModel) => void;
    breakConnection: (arg: AnyConfigurationModel) => void;
    deleteConnection: (arg: AnyConfigurationModel) => void;
}
export declare function isSessionModelWithConnections(thing: unknown): thing is SessionWithConnections;
/** a session that can also add new connection configs */
export interface SessionWithConnectionEditing extends SessionWithConnections {
    addConnectionConf: (arg: AnyConfigurationModel) => AnyConfigurationModel;
}
export declare function isSessionModelWithConnectionEditing(thing: unknown): thing is SessionWithConnectionEditing;
export interface SessionWithSessionPlugins extends AbstractSessionModel {
    sessionPlugins: (PluginDefinition & {
        name: string;
    })[];
    addSessionPlugin: (plugin: PluginDefinition & {
        name: string;
    }) => void;
    removeSessionPlugin: (plugin: PluginDefinition) => void;
}
export declare function isSessionWithSessionPlugins(thing: unknown): thing is SessionWithSessionPlugins;
/** abstract interface for a session that manages a global selection */
export interface SelectionContainer extends AbstractSessionModel {
    selection?: unknown;
    setSelection(thing: unknown): void;
}
export declare function isSelectionContainer(thing: unknown): thing is SelectionContainer;
/** abstract interface for a session allows applying focus to views and widgets */
export interface SessionWithFocusedViewAndDrawerWidgets extends SessionWithDrawerWidgets {
    focusedViewId: string | undefined;
    setFocusedViewId(id: string): void;
}
/**
 * the slice of a view that the track-selector and add-track widgets write into:
 * a track list, the assemblies it may show tracks for, and the open/close
 * actions. A plain view is its own track container; a view that owns several
 * (the synteny view's per-level track lists) hands them out via
 * `trackContainerFor`.
 */
export interface TrackContainer {
    tracks: {
        configuration: {
            trackId: string;
        };
        displays: ResolvableDisplay[];
    }[];
    assemblyNames?: string[];
    showTrack: (trackId: string) => unknown;
    hideTrack: (trackId: string) => unknown;
    toggleTrack: (trackId: string) => unknown;
}
/** minimum interface that all view state models must implement */
export interface AbstractViewModel {
    id: string;
    type: string;
    width: number;
    minimized: boolean;
    setWidth(width: number): void;
    setMinimized(flag: boolean): void;
    displayName: string | undefined;
    setDisplayName: (arg: string) => void;
    menuItems: () => MenuItem[];
    assemblyNames?: string[];
    /**
     * a track container owned by this view, by its id. Only views holding more
     * than one track list implement it; for every other view the widget targets
     * the view itself.
     */
    trackContainerFor?: (id: string) => TrackContainer | undefined;
}
export declare function isViewModel(thing: unknown): thing is AbstractViewModel;
type Display = {
    displayId: string;
} & AnyConfigurationModel;
export interface AbstractTrackModel {
    id: string;
    displays: AbstractDisplayModel[];
    configuration: AnyConfigurationModel & {
        displays: Display[];
    };
    minimized: boolean;
}
export declare function isTrackModel(thing: unknown): thing is AbstractTrackModel;
export interface AbstractDisplayModel {
    id: string;
    parentTrack: AbstractTrackModel;
    renderDelay: number;
    cannotBeRenderedReason?: string;
}
export declare function isDisplayModel(thing: unknown): thing is AbstractDisplayModel;
export interface TrackViewModel extends AbstractViewModel {
    showTrack(trackId: string): void;
    hideTrack(trackId: string): void;
}
export declare function isTrackViewModel(thing: unknown): thing is TrackViewModel;
/** minimum interface for the root MST model of a JBrowse app */
export interface AbstractRootModel {
    jbrowse: IAnyStateTreeNode;
    session?: AbstractSessionModel;
    setSession?(arg: {
        name: string;
        [key: string]: unknown;
    }): void;
    setDefaultSession?(): void;
    adminMode: boolean;
    error?: unknown;
}
/** root model with more included for the heavier JBrowse web and desktop app */
export interface AppRootModel extends AbstractRootModel {
    internetAccounts: BaseInternetAccountModel[];
    findAppropriateInternetAccount(location: UriLocation): BaseInternetAccountModel | undefined;
    createEphemeralInternetAccount(internetAccountId: string, initialSnapshot: Record<string, unknown>, url: string): BaseInternetAccountModel;
}
export declare function isAppRootModel(thing: unknown): thing is AppRootModel;
export interface RootModelWithInternetAccounts extends AbstractRootModel {
    internetAccounts: BaseInternetAccountModel[];
    findAppropriateInternetAccount(location: UriLocation): BaseInternetAccountModel | undefined;
}
export declare function isRootModelWithInternetAccounts(thing: unknown): thing is RootModelWithInternetAccounts;
/**
 * a root model that manages global menus. Every method records a contribution
 * that is applied when the menu opens, so none of them can report where the
 * item landed
 */
export interface AbstractMenuManager {
    appendMenu(menuName: string): void;
    insertMenu(menuName: string, position: number): void;
    insertInMenu(menuName: string, menuItem: MenuItem, position: number): void;
    appendToMenu(menuName: string, menuItem: MenuItem): void;
    appendToSubMenu(menuPath: string[], menuItem: MenuItem): void;
    insertInSubMenu(menuPath: string[], menuItem: MenuItem, position: number): void;
}
export declare function isAbstractMenuManager(thing: unknown): thing is AbstractMenuManager;
export interface NoAssemblyRegion extends SnapshotIn<typeof MUNoAssemblyRegion> {
}
/**
 * a description of a specific genomic region. assemblyName, refName, start,
 * end, and reversed
 */
export interface Region extends SnapshotIn<typeof MUIRegion> {
}
export interface AugmentedRegion extends Region {
    originalRefName?: string;
}
export interface LocalPathLocation extends SnapshotIn<typeof MULocalPathLocation> {
}
export interface UriLocation extends SnapshotIn<typeof MUUriLocation> {
}
export declare function isUriLocation(location: unknown): location is UriLocation;
export declare function isLocalPathLocation(location: unknown): location is LocalPathLocation;
export declare function isBlobLocation(location: unknown): location is BlobLocation;
export interface FileHandleLocation extends SnapshotIn<typeof MUFileHandleLocation> {
}
export declare function isFileHandleLocation(location: unknown): location is FileHandleLocation;
export declare class AuthNeededError extends Error {
    url: string;
    constructor(message: string, url: string);
}
export declare function isAuthNeededException(exception: unknown): exception is AuthNeededError;
export interface BlobLocation extends SnapshotIn<typeof MUBlobLocation> {
}
export type FileLocation = LocalPathLocation | UriLocation | BlobLocation | FileHandleLocation;
export interface PreUriLocation {
    uri: string;
}
export interface PreLocalPathLocation {
    localPath: string;
}
export interface PreBlobLocation {
    blob: File;
}
export interface PreFileHandleLocation {
    handle: FileSystemFileHandle;
}
export type PreFileLocation = PreUriLocation | PreLocalPathLocation | PreBlobLocation | PreFileHandleLocation;
