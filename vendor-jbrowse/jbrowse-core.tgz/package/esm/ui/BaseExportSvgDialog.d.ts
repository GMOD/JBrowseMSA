import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
export interface BaseExportSvgOptions {
    rasterizeLayers: boolean;
    format: 'svg' | 'png';
    filename: string;
    themeName: string;
}
export default function BaseExportSvgDialog({ model, handleClose, exportSvg, children, checkboxes, }: {
    model: IAnyStateTreeNode;
    handleClose: () => void;
    exportSvg: (opts: BaseExportSvgOptions) => Promise<void>;
    children?: React.ReactNode;
    checkboxes?: React.ReactNode;
}): import("react").JSX.Element;
