import type { TranslExcept } from '../../../util/geneticCodes.ts';
import type { Feat } from '../../util.tsx';
import type { SequenceFeatureDetailsModel } from '../model.ts';
declare const ProteinSequence: ({ cds, sequence, model, codonTable, starts, translExcept, }: {
    cds: Feat[];
    sequence: string;
    model: SequenceFeatureDetailsModel;
    codonTable: Record<string, string>;
    starts?: string[];
    translExcept?: TranslExcept[];
}) => import("react").JSX.Element;
export default ProteinSequence;
