import type { SequenceDisplayMode, SequenceFeatureDetailsModel } from './model.ts';
import type { SimpleFeatureSerialized } from '../../util/index.ts';
import type { SeqState } from '../util.tsx';
declare const SequenceContents: ({ mode, feature, sequence, model, assemblyGeneticCodeId, }: {
    mode: SequenceDisplayMode;
    feature: SimpleFeatureSerialized;
    sequence: SeqState;
    model: SequenceFeatureDetailsModel;
    assemblyGeneticCodeId?: number;
}) => import("react").JSX.Element | null;
export default SequenceContents;
