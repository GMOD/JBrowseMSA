import type PluginManager from '../PluginManager.ts';
import type { Instance } from '@jbrowse/mobx-state-tree';
declare function assemblyConfigSchema(pluginManager: PluginManager): import("../configuration/configurationSchema.ts").ConfigurationSchemaType<{
    aliases: {
        type: string;
        defaultValue: never[];
        description: string;
    };
    sequence: import("../configuration/types.ts").AnyConfigurationSchemaType;
    refNameColors: {
        type: string;
        defaultValue: never[];
        description: string;
    };
    geneticCodes: {
        type: string;
        defaultValue: {};
        description: string;
    };
    geneticCodesLocation: {
        type: string;
        defaultValue: {
            uri: string;
            locationType: string;
        };
        description: string;
    };
    refNameAliases: import("../configuration/configurationSchema.ts").ConfigurationSchemaType<{
        adapter: import("@jbrowse/mobx-state-tree").IAnyModelType;
    }, import("../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
    cytobands: import("../configuration/configurationSchema.ts").ConfigurationSchemaType<{
        adapter: import("@jbrowse/mobx-state-tree").IAnyModelType;
    }, import("../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
    displayName: {
        type: string;
        defaultValue: string;
        description: string;
    };
}, import("../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, "name">>;
export default assemblyConfigSchema;
export type BaseAssemblyConfigSchema = ReturnType<typeof assemblyConfigSchema>;
export type BaseAssemblyConfigModel = Instance<BaseAssemblyConfigSchema>;
