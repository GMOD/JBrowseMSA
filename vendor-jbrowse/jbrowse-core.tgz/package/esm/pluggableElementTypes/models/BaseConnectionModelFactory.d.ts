import type PluginManager from '../../PluginManager.ts';
import type { AnyConfigurationModel } from '../../configuration/index.ts';
type TrackConf = AnyConfigurationModel | Record<string, unknown>;
declare function stateModelFactory(pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{
    tracks: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyModelType>;
    configuration: import("@jbrowse/mobx-state-tree").ITypeUnion<any, any, any>;
}, {
    readonly connectionId: string;
    readonly name: string;
} & {
    connect(_arg: AnyConfigurationModel): void;
} & {
    afterAttach(): void;
    addTrackConf(trackConf: TrackConf): any;
    addTrackConfs(trackConfs: TrackConf[]): void;
    setTrackConfs(trackConfs: TrackConf[]): void;
    clear(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type BaseConnectionModel = ReturnType<typeof stateModelFactory>;
export default stateModelFactory;
