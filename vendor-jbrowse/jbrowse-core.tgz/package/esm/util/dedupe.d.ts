type Hasher<T> = (input: T) => string;
export declare function dedupe<T>(list: T[], hasher?: Hasher<T>): T[];
export {};
