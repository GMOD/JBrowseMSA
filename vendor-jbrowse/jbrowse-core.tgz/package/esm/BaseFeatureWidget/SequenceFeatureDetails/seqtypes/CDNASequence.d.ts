import type { SimpleFeatureSerialized } from '../../../util/index.ts';
import type { Feat } from '../../util.tsx';
import type { SequenceFeatureDetailsModel } from '../model.ts';
declare const CDNASequence: ({ cds, exons, sequence, upstream, downstream, feature, includeIntrons, collapseIntron, useGenomicCoords, revcomp, onHoverBase, model, }: {
    cds: Feat[];
    exons: Feat[];
    sequence: string;
    upstream?: string;
    downstream?: string;
    feature: SimpleFeatureSerialized;
    includeIntrons?: boolean;
    collapseIntron?: boolean;
    useGenomicCoords: boolean;
    revcomp: boolean;
    onHoverBase?: (base0: number) => void;
    model: SequenceFeatureDetailsModel;
}) => import("react").JSX.Element;
export default CDNASequence;
