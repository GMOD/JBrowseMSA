export default function PopoverPicker({ color, onChange, presetAlpha, }: {
    color: string;
    onChange: (color: string) => void;
    presetAlpha?: number;
}): import("react").JSX.Element;
