import type { JexlInstance } from '../util/jexlStrings.ts';
export declare function isCallbackValue(value: unknown): value is string;
export declare function evaluateJexl(value: string, args: Record<string, unknown>, jexl?: JexlInstance): unknown;
export declare function toCallbackValue(value: unknown): string;
export declare function toFixedValue(value: unknown, type: string, defaultValue: unknown, jexl?: JexlInstance): unknown;
