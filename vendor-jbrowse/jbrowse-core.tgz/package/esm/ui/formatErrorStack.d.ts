export declare function formatErrorStack(error: unknown): string;
