import type { SequencePanelProps } from './types.ts';
declare const SequencePanel: ({ sequence, model, feature, mode, assemblyGeneticCodeId, ref, }: SequencePanelProps) => import("react").JSX.Element;
export default SequencePanel;
