export interface BpRegionBounds {
    start: number;
    end: number;
    screenStartPx: number;
    screenEndPx: number;
    reversed?: boolean;
}
export interface RenderBlock extends BpRegionBounds {
    displayedRegionIndex: number;
    reversed: boolean;
}
export declare function buildRenderBlocks(regions: (BpRegionBounds & {
    displayedRegionIndex: number;
})[]): RenderBlock[];
