import type { IAnyType, IModelReflectionPropertiesData, ISimpleType, UnionStringArray } from '@jbrowse/mobx-state-tree';
export interface ILiteralType<T> extends ISimpleType<T> {
    value: T;
}
export declare function getSubType(type: IAnyType): IAnyType;
export declare function getPropertyType(type: IModelReflectionPropertiesData, propertyName: string): IAnyType;
export declare function getDefaultValue(type: IAnyType): any;
export type IEnumerationType<T extends string> = ISimpleType<UnionStringArray<T[]>>;
export declare function getEnumerationValues(type: IAnyType): string[];
export declare function resolveLateType(maybeLate: IAnyType): IAnyType;
export { getUnionSubtypes as getUnionSubTypes } from '@jbrowse/mobx-state-tree';
