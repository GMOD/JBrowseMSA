import type React from 'react';
export declare function lazyMap(obj: Record<string, React.ComponentType<any>>, prefix?: string): any;
