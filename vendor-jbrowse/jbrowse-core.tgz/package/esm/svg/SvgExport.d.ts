export declare function SVGBackground({ width, height, }: {
    width: number;
    height: number;
}): import("react").JSX.Element;
export declare function SVGExportRoot({ width, height, margin, children, }: {
    width: number;
    height: number;
    margin?: number;
    children: React.ReactNode;
}): import("react").JSX.Element;
export declare function SVGErrorBox({ error, width, height, }: {
    error: unknown;
    width: number;
    height: number;
}): import("react").JSX.Element;
export declare function SvgChrome({ error, width, height, children, }: {
    error: unknown;
    width: number;
    height: number;
    children: React.ReactNode;
}): import("react").JSX.Element;
export declare function SvgClipRect({ id, width, height, children, }: {
    id: string;
    width: number;
    height: number;
    children: React.ReactNode;
}): import("react").JSX.Element;
