import type { ReactNode } from 'react';
import type { Accept, FileRejection } from 'react-dropzone';
export default function FileDropZoneInner({ onDrop, accept, maxSize, multiple, message, children, className, }: {
    onDrop: (accepted: File[], rejected: FileRejection[]) => void;
    accept?: Accept;
    maxSize?: number;
    multiple?: boolean;
    message?: ReactNode;
    children?: ReactNode;
    className?: string;
}): import("react").JSX.Element;
