import type { Region } from './types/index.ts';
export interface AlignmentData {
    refRefName: string;
    queryRefName: string;
    refStart: number;
    refEnd: number;
    queryStart: number;
    queryEnd: number;
    strand: number;
}
export interface DiagonalizationResult {
    newRegions: Region[];
    stats: {
        totalAlignments: number;
        regionsProcessed: number;
        regionsReordered: number;
        regionsReversed: number;
    };
}
export type DiagonalizeTick = () => void;
export declare function diagonalizeRegions(alignments: AlignmentData[], referenceRegions: Region[], currentRegions: Region[], onTick?: DiagonalizeTick): Promise<DiagonalizationResult>;
