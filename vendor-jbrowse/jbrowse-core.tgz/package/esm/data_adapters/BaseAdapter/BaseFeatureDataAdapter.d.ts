import { type Observable } from 'rxjs';
import { BaseAdapter } from './BaseAdapter.ts';
import type { BaseOptions, FeatureDensityStats } from './types.ts';
import type { AnyConfigurationModel } from '../../configuration/index.ts';
import type { Feature } from '../../util/simpleFeature.ts';
import type { RectifiedQuantitativeStats } from '../../util/stats.ts';
import type { AugmentedRegion as Region } from '../../util/types/index.ts';
export declare abstract class BaseFeatureDataAdapter<CONF extends AnyConfigurationModel = AnyConfigurationModel> extends BaseAdapter<CONF> {
    abstract getRefNames(opts?: BaseOptions): Promise<string[]>;
    abstract getFeatures(region: Region, opts?: BaseOptions): Observable<Feature>;
    getHeader(_opts?: BaseOptions): Promise<unknown>;
    getMetadata(_opts?: BaseOptions): Promise<unknown>;
    getFeaturesInRegion(region: Region, opts?: BaseOptions): Observable<Feature>;
    getFeaturesInMultipleRegions(regions: Region[], opts?: BaseOptions): Observable<Feature>;
    getFeaturesArray(region: Region, opts?: BaseOptions): Promise<Feature[]>;
    getFeaturesInMultipleRegionsArray(regions: Region[], opts?: BaseOptions): Promise<Feature[]>;
    hasDataForRefName(refName: string, opts?: BaseOptions): Promise<boolean>;
    getGlobalStats(_opts?: BaseOptions): Promise<Partial<RectifiedQuantitativeStats> | undefined>;
    getRegionQuantitativeStats(region: Region, opts?: BaseOptions): Promise<RectifiedQuantitativeStats>;
    getMultiRegionQuantitativeStats(regions?: Region[], opts?: BaseOptions): Promise<RectifiedQuantitativeStats>;
    getMultiRegionFeatureDensityStats(regions: Region[], opts?: BaseOptions): Promise<FeatureDensityStats>;
    getRegionByteSize(_regions: Region[], _opts?: BaseOptions): Promise<number | undefined>;
    getSources(regions: Region[]): Promise<{
        name: string;
        color?: string;
        [key: string]: unknown;
    }[]>;
    getExportData(_regions: Region[], _formatType: string, _opts?: BaseOptions): Promise<string | undefined>;
}
