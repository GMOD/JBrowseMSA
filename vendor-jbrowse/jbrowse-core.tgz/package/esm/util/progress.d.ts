import type { StopToken, StopTokenChecker } from './stopToken.ts';
/**
 * Indeterminate phase: set `label` on the status channel, run `fn`, then clear
 * it. Pass `stopToken` to check for cancellation before clearing (a no-op when
 * undefined). The determinate counterpart is {@link withProgress}.
 */
export declare function updateStatus<U>(msg: string, cb: StatusCallback | undefined, fn: () => U | Promise<U>, stopToken?: StopToken): Promise<U>;
/**
 * A value flowing through the RPC `statusCallback` channel.
 *
 * Historically this was always a plain human-readable string (e.g. "Loading
 * features"). It may now also carry determinate progress, which the loading UI
 * renders as a progress bar in addition to the message. Plain strings remain
 * valid for indeterminate phases, so existing callers are unaffected.
 */
export interface StatusWithProgress {
    message: string;
    current: number;
    total: number;
}
export type RpcStatus = string | StatusWithProgress;
/**
 * The single out-of-band status transport carried across the RPC boundary. A
 * plain string is an indeterminate phase label; a {@link StatusWithProgress}
 * adds a determinate fraction. Adapters wrap raw byte/block/feature counts into
 * this; the loading UI renders the message and (when present) a progress bar.
 */
export type StatusCallback = (status: RpcStatus) => void;
/** Extract the human-readable text from any status value. */
export declare function statusMessageText(status: RpcStatus | undefined): string | undefined;
/**
 * Fraction complete in [0,1], or undefined when the status is indeterminate
 * (a plain string, or a zero total).
 */
export declare function statusFraction(status: RpcStatus | undefined): number | undefined;
/**
 * Leading-edge throttle for a display's RPC progress stream: sparse updates pass
 * straight through, dense bursts are thinned. Create **one per display** and
 * share it across that display's status callbacks, so N parallel per-region
 * fetches thin to one stream between them rather than N.
 *
 * Deliberately wraps only the *callback* path, never `setStatusMessage` itself
 * — a display writing a phase label by hand ("Downloading" → "Parsing") must
 * see every write land, and there is no trailing flush to recover a dropped one.
 *
 * Both fetch families own one: `FetchMixin` for the LGV displays, and
 * `createStopTokenRotation` for the bare-autorun fetches (dotplot, synteny)
 * that compose no fetch mixin. A plain function rather than shared model state
 * because the two families declare their status fields separately and one set
 * shadows the other — see ADR-041.
 */
export declare function createStatusThrottle(): {
    run(apply: () => void): void;
    /** reopen the window, so the next fetch reports its first status at once */
    reset(): void;
};
/**
 * Format a phase label with a rounded percentage appended when a determinate
 * `fraction` is present (e.g. `progressLabel('Downloading', 0.45)` →
 * `"Downloading 45%"`). The single place the `X%` suffix is formatted: both
 * {@link statusProgressLabel} (RpcStatus callers) and the loading
 * overlays/indicators — which hold the message and fraction already split apart
 * onto the model — route through it, so no caller hand-rolls `Math.round`.
 */
export declare function progressLabel(message: string | undefined, fraction: number | undefined): string;
/**
 * {@link progressLabel} for an {@link RpcStatus}: the message, with a rounded
 * percentage appended when the status is determinate (e.g. `"Downloading 45%"`).
 * The form the loading dialogs use, holding the raw status object.
 */
export declare function statusProgressLabel(status: RpcStatus | undefined): string;
/**
 * Adapt the byte-granularity download callback exposed by the readers
 * (generic-filehandle2 `readFile`, @gmod/tabix `getLines`, @gmod/bam /
 * @gmod/cram `getRecordsForRange`) to the structured {@link StatusCallback}
 * transport, labelling each tick with `message`. Returns undefined when there's
 * no `statusCallback`, so the reader can skip its progress bookkeeping entirely.
 *
 * `total` is optional because not every reader knows the size up front
 * (generic-filehandle2 omits it when the response has no Content-Length): with a
 * total we emit a determinate bar, without one we emit just the label so the UI
 * still shows the phase as an indeterminate spinner.
 *
 * Internal to this module — the only caller is {@link downloadStatus}, which is
 * the API adapters use. Kept separate purely so the reporter logic reads on its
 * own line.
 */
declare function downloadStatusReporter(statusCallback: StatusCallback | undefined, message: string): ((current: number, total?: number) => void) | undefined;
/**
 * Run a download phase with byte-granularity progress. Shows `label`, hands
 * `fn` the {@link downloadStatusReporter} to pass straight to an index reader's
 * `onProgress` (byte ticks upgrade the same label to a determinate bar), then
 * clears the status. Combines {@link updateStatus} with the reporter so the
 * label is written in exactly one place — the phase label and the progress
 * label can't drift apart.
 */
export declare function downloadStatus<T>(label: string, statusCallback: StatusCallback | undefined, fn: (onProgress: ReturnType<typeof downloadStatusReporter>) => T | Promise<T>): Promise<T>;
/**
 * Combine the in-flight statuses of several concurrent operations (one RPC per
 * visible region, say) into the single status the loading UI shows. Because
 * `current`/`total` are unit-agnostic and additive, determinate statuses are
 * summed into one Σcurrent/Σtotal bar — so N regions downloading in parallel
 * read as one honest bar instead of each clobbering the shared field. The
 * message is borrowed from a determinate status when any is present (regions
 * downloading at once share the same phase label), else the first status.
 * Returns undefined when nothing is in flight.
 */
export declare function aggregateStatus(statuses: (RpcStatus | undefined)[]): RpcStatus | undefined;
/**
 * Fan one status field out to several concurrent operations that would
 * otherwise fight over it. Each `slot()` returns a {@link StatusCallback}
 * remembering only its own latest value; every write re-derives the shared
 * status from all slots through {@link aggregateStatus}, so N concurrent
 * downloads read as one Σcurrent/Σtotal bar instead of last-writer-wins — and
 * the first one to finish (which writes the `''` every phase helper clears
 * with) can't blank the label while the others are still running.
 *
 * The worker-side counterpart to `FetchMixin.setRegionStatus`, which does the
 * same keyed by region on the main thread. Use it wherever a `Promise.all` or
 * an rxjs `merge` hands one `statusCallback` to several operations at once.
 */
export declare function createStatusFanOut(statusCallback: StatusCallback | undefined): () => StatusCallback;
/**
 * Call once per outer-loop iteration. With no argument it auto-increments an
 * internal counter (the elegant default — `for (…) report()`); pass an explicit
 * `current` when the caller tracks its own position, e.g. a running offset that
 * spans several batches.
 */
export type ProgressReporter = (current?: number) => void;
/**
 * The single per-iteration callback for long synchronous worker loops. The
 * returned `report(current)` is called once per outer-loop iteration and does
 * two throttled jobs on each call:
 *
 * - checks the stop token via the existing throttled {@link checkStopTokenThrottled}
 *   machinery, so cancellation interrupts the loop within milliseconds instead
 *   of only at phase boundaries, and
 * - emits a {@link StatusWithProgress} through `statusCallback` at most once per
 *   `throttleMs`, so the main thread gets a live percentage without flooding
 *   the postMessage channel.
 *
 * Both jobs are optional: with no `statusCallback`/`total` this is purely a
 * throttled cancellation tick (the replacement for calling {@link
 * checkStopTokenThrottled} directly in a loop), so a loop has exactly one inner
 * callback whether or not it drives the progress UI.
 *
 * Emission is gated on wall-clock time (`throttleMs`) through {@link
 * createTimeGate}, which caps emits at ~1/throttleMs. This used to read the
 * clock on every call, reasoning that it was negligible next to the per-item
 * work; at a 666k-read pileup that measured ~28ms, so the gate now thins the
 * clock reads too — see createTimeGate for why its stride is learned rather
 * than fixed (a fixed one froze this bar at 0% for low-count/heavy phases).
 * Keep the loop a plain `for`; just call `report()` once per item (it owns the
 * counter) — or `report(n)` to report an explicit position.
 *
 * Reuses {@link createStopTokenChecker}, matching the cancellation convention
 * already used across the variant/alignments/gwas RPC paths.
 */
export declare function createProgressReporter({ label, total, statusCallback, stopToken, stopTokenCheck, throttleMs, }: {
    label?: string;
    total?: number;
    statusCallback?: (status: RpcStatus) => void;
    stopToken?: StopToken;
    stopTokenCheck?: StopTokenChecker;
    throttleMs?: number;
}): ProgressReporter;
/**
 * Run a measurable phase: shows `label` at 0%, hands `fn` a {@link
 * ProgressReporter} to drive during the work, then checks the stop token once
 * more and clears the status. The determinate counterpart to `updateStatus`.
 */
export declare function withProgress<T>({ label, total, statusCallback, stopToken, }: {
    label: string;
    total: number;
    statusCallback?: (status: RpcStatus) => void;
    stopToken?: StopToken;
}, fn: (report: ProgressReporter) => T | Promise<T>): Promise<T>;
export {};
