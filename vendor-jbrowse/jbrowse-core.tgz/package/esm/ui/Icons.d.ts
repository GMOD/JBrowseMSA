import type { SvgIconProps } from '@mui/material/SvgIcon';
export { default as InfoIcon } from '@mui/icons-material/Info';
export declare function Indexing(props: SvgIconProps): import("react").JSX.Element;
export declare function TrackSelector(props: SvgIconProps): import("react").JSX.Element;
export declare function DNA(props: SvgIconProps): import("react").JSX.Element;
export declare function Highlighter(props: SvgIconProps): import("react").JSX.Element;
export declare function Cable(props: SvgIconProps): import("react").JSX.Element;
