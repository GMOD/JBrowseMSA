export default function DataGridDetails({ value, prefix, name, }: {
    name: string;
    prefix?: string[];
    value: Record<string, unknown>[];
}): import("react").JSX.Element;
