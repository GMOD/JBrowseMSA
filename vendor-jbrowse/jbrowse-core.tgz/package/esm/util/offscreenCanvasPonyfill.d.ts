export { collectTransferables, isDetachedBuffer } from './transferables.ts';
export declare function isImageBitmap(value: unknown): value is ImageBitmap;
export declare function drawImageOntoCanvasContext(imageData: any, context: CanvasRenderingContext2D): void;
export declare function createCanvas(width: number, height: number): any;
export declare function createImageBitmap(canvas: any): Promise<unknown>;
