export type CxArg = undefined | null | string | boolean | Record<string, boolean | null | undefined> | readonly CxArg[];
export declare const classnames: (args: CxArg[]) => string;
