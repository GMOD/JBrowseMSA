export interface BasicFeature {
    end: number;
    start: number;
    refName: string;
}
/**
 * Merge intervals that overlap once each is grown by `padding` on both sides.
 * `padding` is per side, so the merge window between two intervals is `2 *
 * padding` — the default merges anything within 10kb of its neighbour, not 5kb.
 * Callers that have already baked their padding into start/end pass 0.
 */
export declare function mergeIntervals<T extends {
    start: number;
    end: number;
}>(intervals: T[], padding?: number): T[];
/**
 * {@link mergeIntervals} per refName: returns a new array of non-overlapping
 * features. `padding` carries the same per-side meaning.
 */
export declare function gatherOverlaps<T extends BasicFeature>(regions: T[], padding?: number): T[];
