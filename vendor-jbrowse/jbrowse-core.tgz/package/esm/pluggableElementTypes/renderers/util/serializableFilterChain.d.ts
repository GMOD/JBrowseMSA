import type { JexlExpression, JexlInstance } from '../../../util/jexlStrings.ts';
interface Filter {
    string: string;
    expr: JexlExpression;
}
export type SerializedFilterChain = string[];
export default class SerializableFilterChain {
    filterChain: Filter[];
    constructor({ filters, jexl, }: {
        filters: SerializedFilterChain;
        jexl?: JexlInstance;
    });
    passes(...args: unknown[]): boolean;
    toJSON(): {
        filters: string[];
    };
    static fromJSON(json: {
        filters: SerializedFilterChain;
    }): SerializableFilterChain;
}
export {};
