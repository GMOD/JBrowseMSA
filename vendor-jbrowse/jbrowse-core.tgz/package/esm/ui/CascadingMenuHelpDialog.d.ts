export default function CascadingMenuHelpDialog({ onClose, helpText, label, }: {
    onClose: (event: React.MouseEvent | React.KeyboardEvent) => void;
    helpText: React.ReactNode;
    label?: React.ReactNode;
}): import("react").JSX.Element;
