import type { SimpleFeatureSerialized } from '../../../util/index.ts';
import type { Feat } from '../../util.tsx';
import type { SequenceFeatureDetailsModel } from '../model.ts';
declare const CDNASequence: ({ utr, cds, exons, sequence, upstream, downstream, feature, includeIntrons, collapseIntron, model, }: {
    utr: Feat[];
    cds: Feat[];
    exons: Feat[];
    sequence: string;
    upstream?: string;
    downstream?: string;
    feature: SimpleFeatureSerialized;
    includeIntrons?: boolean;
    collapseIntron?: boolean;
    model: SequenceFeatureDetailsModel;
}) => import("react").JSX.Element;
export default CDNASequence;
