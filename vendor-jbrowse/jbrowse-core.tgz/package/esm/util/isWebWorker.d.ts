export declare function isWebWorker(): boolean;
