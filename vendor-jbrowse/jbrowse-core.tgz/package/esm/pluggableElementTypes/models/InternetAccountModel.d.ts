import type React from 'react';
import { RemoteFileWithRangeCache } from '../../util/io/index.ts';
import type { AnyReactComponentType, UriLocation } from '../../util/types/index.ts';
import type { Instance } from '@jbrowse/mobx-state-tree';
export declare const InternetAccount: import("@jbrowse/mobx-state-tree").IModelType<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    configuration: import("@jbrowse/mobx-state-tree").ITypeUnion<any, any, any>;
}, {
    readonly name: string;
    readonly description: string;
    readonly internetAccountId: string;
    readonly authHeader: string;
    readonly tokenType: string;
    readonly domains: string[];
    readonly toggleContents: React.ReactNode;
    readonly SelectorComponent: AnyReactComponentType | undefined;
    readonly selectorLabel: string | undefined;
} & {
    handlesLocation(location: UriLocation): boolean;
    readonly tokenKey: string;
} & {
    getTokenFromUser(_resolve: (token: string) => void, _reject: (error: Error) => void): void;
    storeToken(token: string): void;
    removeToken(): void;
    retrieveToken(): string | null;
    validateToken(token: string, _loc: UriLocation): Promise<string>;
} & {
    getToken(location?: UriLocation): Promise<string>;
} & {
    addAuthHeaderToInit(init?: RequestInit, token?: string): {
        body?: BodyInit | null;
        cache?: RequestCache;
        credentials?: RequestCredentials;
        integrity?: string;
        keepalive?: boolean;
        method?: string;
        mode?: RequestMode;
        priority?: RequestPriority;
        redirect?: RequestRedirect;
        referrer?: string;
        referrerPolicy?: ReferrerPolicy;
        signal?: AbortSignal | null;
        window?: null;
        headers: Headers;
    };
    getPreAuthorizationInformation(location: UriLocation): Promise<{
        internetAccountType: string;
        authInfo: {
            token: string;
            configuration: any;
        };
    }>;
} & {
    getFetcher(loc?: UriLocation): (input: RequestInfo, init?: RequestInit) => Promise<Response>;
} & {
    openLocation(location: UriLocation): RemoteFileWithRangeCache;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type BaseInternetAccountStateModel = typeof InternetAccount;
export type BaseInternetAccountModel = Instance<BaseInternetAccountStateModel>;
