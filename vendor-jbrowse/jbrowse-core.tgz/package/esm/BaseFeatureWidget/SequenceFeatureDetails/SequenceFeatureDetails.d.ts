import type { SimpleFeatureSerialized } from '../../util/index.ts';
import type { BaseFeatureWidgetModel } from '../stateModelFactory.ts';
declare const SequenceFeatureDetails: ({ model, feature, }: {
    model: BaseFeatureWidgetModel;
    feature: SimpleFeatureSerialized;
}) => import("react").JSX.Element;
export default SequenceFeatureDetails;
