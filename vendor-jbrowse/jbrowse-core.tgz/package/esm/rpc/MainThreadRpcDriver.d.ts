import BaseRpcDriver from './BaseRpcDriver.ts';
import type RpcMethodType from '../pluggableElementTypes/RpcMethodType.ts';
import type { StatusCallback } from '../util/progress.ts';
export default class MainThreadRpcDriver extends BaseRpcDriver {
    name: string;
    protected transport(_pluginManager: unknown, _sessionId: string, rpcMethod: RpcMethodType, serializedArgs: Record<string, unknown>, statusCallback: StatusCallback | undefined): Promise<unknown>;
}
