import type { SequenceDisplayMode, SequenceFeatureDetailsModel } from './model.ts';
import type { SimpleFeatureSerialized } from '../../util/index.ts';
declare const SequenceName: ({ mode, model, feature, }: {
    model: SequenceFeatureDetailsModel;
    mode: SequenceDisplayMode;
    feature: SimpleFeatureSerialized;
}) => import("react").JSX.Element;
export default SequenceName;
