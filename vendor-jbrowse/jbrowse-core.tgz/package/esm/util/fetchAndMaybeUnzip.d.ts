import type { BaseOptions } from '../data_adapters/BaseAdapter/index.ts';
import type { GenericFilehandle } from 'generic-filehandle2';
export declare function isGzip(buf: Uint8Array): boolean;
export declare function fetchAndMaybeUnzip(loc: GenericFilehandle, opts?: BaseOptions): Promise<any>;
export declare function fetchAndMaybeUnzipText(loc: GenericFilehandle, opts?: BaseOptions): Promise<string>;
