interface RegionUploadTarget<T> {
    uploadRegion(displayedRegionIndex: number, data: T): void;
    pruneRegions(active: Iterable<number>): void;
}
/**
 * Incremental whole-map GPU upload for displays whose per-region data is a
 * single MobX computed that re-clones the whole map on any change (canvas,
 * alignments). Per-key autoruns can't help those — reading the computed in a
 * per-key autorun still tracks the whole computed (see
 * `installPerRegionLifecycle` for the per-key case that *can*).
 *
 * The returned function diffs the current map against the last upload by
 * reference and:
 *
 *  - uploads only regions whose data reference changed,
 *  - prunes regions no longer present (and forgets them, so a later
 *    same-reference re-arrival still re-uploads),
 *  - re-uploads everything when the backend identity changes — a context-loss
 *    recovery hands a fresh backend with empty GPU buffers.
 *
 * For the skip to fire, the data map must keep **stable references** for
 * unchanged regions across recomputes (e.g. canvas's `createIncrementalLayout`
 * memoizes per ref-group). With an always-fresh map every region re-uploads,
 * which is correct but defeats the optimization.
 *
 * Hold one instance per backend lifecycle (call from `startRenderingBackend`); the
 * closure keeps the last-uploaded references.
 *
 * @see regionUploadSync.test.ts — covers the reference-diff skip, prune, and
 * backend-swap re-upload paths.
 */
export declare function createRegionUploadSync<T, B extends RegionUploadTarget<T>>(): (backend: B, regions: ReadonlyMap<number, T>) => void;
export {};
