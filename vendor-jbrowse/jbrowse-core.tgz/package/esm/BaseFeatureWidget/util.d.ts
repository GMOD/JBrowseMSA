import type { SerializedFeat } from './types.tsx';
export interface Feat {
    start: number;
    end: number;
    type?: string;
    name?: string;
    id?: string | number;
    phase?: number;
}
export interface ParentFeat extends Feat {
    uniqueId: string;
    strand?: number;
    refName: string;
    subfeatures?: Feat[];
    parentId?: string;
}
export interface SeqState {
    seq: string;
    upstream?: string;
    downstream?: string;
}
export interface ErrorState {
    error: string;
}
export declare function filterSuccessiveElementsWithSameStartAndEndCoord(list: Feat[]): Feat[];
export declare function ellipses(slug: string): string;
export declare function getStrandStr(strand: number | undefined): "" | "(+)" | "(-)";
export declare const nullReplacer: (_: string, v: unknown) => {} | null;
export declare function formatSubfeatures(obj: SerializedFeat, depth: number, parse: (obj: Record<string, unknown>) => void, currentDepth?: number): void;
