type Listener = (arg: unknown) => void;
interface RpcMessageData {
    uid: string;
    libRpc?: true;
    error?: string;
    method?: string;
    eventName?: string;
    data: unknown;
}
interface PendingCall {
    resolve: (data: unknown) => void;
    reject: (error: Error) => void;
}
export default class RpcClient {
    worker: Worker;
    pending: Map<string, PendingCall>;
    private events;
    private counter;
    constructor(worker: Worker);
    on(event: string, listener: Listener): this;
    off(event: string, listener: Listener): this;
    emit(event: string, data: unknown): this;
    protected handler(e: MessageEvent<RpcMessageData>): void;
    protected catch(e: ErrorEvent): void;
    protected reject(uid: string, error: string | Error): void;
    protected resolve(uid: string, data: unknown): void;
    call(method: string, data: unknown, { transferables }?: {
        transferables?: Transferable[];
    }): Promise<unknown>;
}
export {};
