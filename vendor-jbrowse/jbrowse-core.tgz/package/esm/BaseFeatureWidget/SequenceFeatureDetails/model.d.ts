import type { Instance } from '@jbrowse/mobx-state-tree';
export type ShowCoordinatesMode = 'none' | 'relative' | 'genomic';
export interface SequenceHoverPosition {
    refName: string;
    start: number;
    end: number;
    assemblyName?: string;
}
export interface SequenceHoverTarget {
    setSequenceHoverPosition: (pos: SequenceHoverPosition | undefined) => void;
}
export type SequenceDisplayMode = 'gene' | 'gene_collapsed_intron' | 'gene_updownstream' | 'gene_updownstream_collapsed_intron' | 'cdna' | 'cds' | 'genomic' | 'genomic_sequence_updownstream' | 'protein';
export declare function SequenceFeatureDetailsF(): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    /**
     * #volatile
     */
    showCoordinatesSetting: ShowCoordinatesMode;
    /**
     * #volatile
     */
    intronBp: number;
    /**
     * #volatile
     */
    upDownBp: number;
    /**
     * #volatile
     */
    upperCaseCDS: boolean;
    /**
     * #volatile
     */
    charactersPerRow: number;
} & {
    /**
     * #action
     */
    setUpDownBp(f: number): void;
    /**
     * #action
     */
    setIntronBp(f: number): void;
    /**
     * #action
     */
    setUpperCaseCDS(f: boolean): void;
    /**
     * #action
     */
    setShowCoordinates(f: ShowCoordinatesMode): void;
} & {
    /**
     * #getter
     */
    readonly showCoordinates: boolean;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type SequenceFeatureDetailsStateModel = ReturnType<typeof SequenceFeatureDetailsF>;
export type SequenceFeatureDetailsModel = Instance<SequenceFeatureDetailsStateModel>;
