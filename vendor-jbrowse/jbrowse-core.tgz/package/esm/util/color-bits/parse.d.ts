import type { Color } from './core.ts';
/**
 * Parse CSS color
 * @param color CSS color string: #xxx, #xxxxxx, #xxxxxxxx, rgb(), rgba(), hsl(), hsla(), color()
 */
export declare function parse(color: string): Color;
/**
 * Parse hexadecimal CSS color
 * @param color Hex color string: #xxx, #xxxx, #xxxxxx, #xxxxxxxx
 */
export declare function parseHex(color: string): Color;
/**
 * Parse CSS color
 * https://developer.mozilla.org/en-US/docs/Web/CSS/color_value
 * @param color CSS color string: rgb(), rgba(), hsl(), hsla(), color()
 */
export declare function parseColor(color: string): Color;
