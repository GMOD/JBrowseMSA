type TypedArrayConstructor = Int8ArrayConstructor | Uint8ArrayConstructor | Uint8ClampedArrayConstructor | Int16ArrayConstructor | Uint16ArrayConstructor | Int32ArrayConstructor | Uint32ArrayConstructor | Float32ArrayConstructor | Float64ArrayConstructor;
type FilterFn = (index: number, x0: number, y0: number, x1: number, y1: number) => boolean;
export default class Flatbush {
    numItems: number;
    nodeSize: number;
    byteOffset: number;
    ArrayType: TypedArrayConstructor;
    IndexArrayType: Uint16ArrayConstructor | Uint32ArrayConstructor;
    data: ArrayBuffer;
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
    private _levelBounds;
    private _boxes;
    private _indices;
    private _pos;
    /**
     * Recreate a Flatbush index from raw `ArrayBuffer` data.
     */
    static from(data: ArrayBuffer, byteOffset?: number): Flatbush;
    /**
     * Create a Flatbush index that will hold a given number of items.
     */
    constructor(numItems: number, nodeSize?: number, ArrayType?: TypedArrayConstructor, ArrayBufferType?: ArrayBufferConstructor, data?: ArrayBuffer, byteOffset?: number);
    /**
     * Add a given rectangle to the index.
     * @returns A zero-based, incremental number that represents the newly added rectangle.
     */
    add(minX: number, minY: number, maxX?: number, maxY?: number): number;
    /** Perform indexing of the added rectangles. */
    finish(): void;
    /**
     * Search the index by a bounding box.
     * @param filterFn An optional function that is called on every found item; if supplied, only items for which this function returns true will be included in the results array.
     * @returns An array of indices of items intersecting or touching the given bounding box.
     */
    search(minX: number, minY: number, maxX: number, maxY: number, filterFn?: FilterFn): number[];
    /**
     * Collect all leaves of a subtree that's fully inside the query, skipping intersection tests.
     * Because the tree is packed bottom-up, those leaves occupy one contiguous block of the leaf
     * level, so we skip traversal entirely: descend to the first leaf, then sweep the flat range.
     */
    private _collectContained;
}
export {};
