export interface GlAttributeLayout {
    name: string;
    components: number;
    type: 'float' | 'uint' | 'int';
    offsetBytes: number;
    integer: boolean;
}
export interface BlendState {
    srcFactor: 'one' | 'src-alpha' | 'one-minus-src-alpha' | 'zero';
    dstFactor: 'one' | 'src-alpha' | 'one-minus-src-alpha' | 'zero';
}
export interface TextureBinding {
    textureBinding: number;
    samplerBinding: number;
    glTextureUnit: number;
    glUniformName: string;
    filter: 'linear' | 'nearest';
}
export interface PassDescriptor {
    id: string;
    wgslSource: string;
    glslVertex: string;
    glslFragment: string;
    instanceStride: number;
    verticesPerInstance: number;
    blend: boolean;
    blendState?: BlendState;
    glAttributes: readonly GlAttributeLayout[];
    wgslFragmentEntry?: string;
    glslFragmentOverride?: string;
    topology?: 'triangle-list' | 'triangle-strip' | 'line-list';
    textures?: readonly [TextureBinding, ...TextureBinding[]];
}
export interface GpuHal {
    resize(width: number, height: number): void;
    uploadBuffer(regionKey: number, passId: string, data: ArrayBuffer | ArrayBufferView, count: number): void;
    getBufferCount(regionKey: number, passId: string): number;
    deleteBuffer(regionKey: number, passId: string): void;
    deleteRegion(regionKey: number): void;
    pruneRegions(active: Iterable<number>): void;
    beginUpload(): void;
    endUpload(): void;
    uploadTexture(passId: string, data: Uint8Array, width: number, height: number): void;
    writeUniforms(data: ArrayBuffer): void;
    beginFrame(clearR: number, clearG: number, clearB: number, clearA?: number): void;
    drawPass(passId: string, regionKey: number, bufferPassId?: string): void;
    endFrame(): void;
    setScissor(x: number, y: number, w: number, h: number): void;
    clearScissor(): void;
    setViewport(x: number, y: number, w: number, h: number): void;
    clearViewport(): void;
    dispose(): void;
}
