import type { SliderProps } from '@mui/material';
type Props = Omit<SliderProps, 'value' | 'defaultValue' | 'onChange' | 'onChangeCommitted'> & {
    value: number;
    onChange?: (value: number) => void;
    onChangeCommitted?: (value: number) => void;
};
export default function SingleSlider(props: Props): import("react").JSX.Element;
export {};
