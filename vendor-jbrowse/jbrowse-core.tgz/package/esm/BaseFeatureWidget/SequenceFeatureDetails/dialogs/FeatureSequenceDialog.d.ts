import type { AbstractSessionModel, SimpleFeatureSerialized } from '../../../util/index.ts';
import type { SequenceHoverTarget } from '../model.ts';
declare const FeatureSequenceDialog: ({ feature, error, session, assemblyName, hoverTarget, handleClose, }: {
    feature: SimpleFeatureSerialized | undefined;
    error?: unknown;
    session: AbstractSessionModel;
    assemblyName: string | undefined;
    hoverTarget?: SequenceHoverTarget;
    handleClose: () => void;
}) => import("react").JSX.Element;
export default FeatureSequenceDialog;
