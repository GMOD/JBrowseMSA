import type { SequenceFeatureDetailsModel } from '../model.ts';
declare const SequenceDisplay: ({ chunks, start, color, strand, coordStart, highlight, model, }: {
    chunks: string[];
    start: number;
    coordStart?: number;
    strand?: number;
    color?: string;
    highlight?: (index: number) => string | undefined;
    model: SequenceFeatureDetailsModel;
}) => import("react").JSX.Element[];
export default SequenceDisplay;
