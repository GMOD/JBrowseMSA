export { getFileName } from './getFileName.ts';
import type PluginManager from '../PluginManager.ts';
import type { AnyConfigurationModel } from '../configuration/index.ts';
import type { BlobLocation, FileHandleLocation, FileLocation, PreFileLocation } from './types/index.ts';
import type { IAnyStateTreeNode, IAnyType, Instance, types } from '@jbrowse/mobx-state-tree';
export declare function getTrackAssemblyNames(track: IAnyStateTreeNode & {
    configuration: AnyConfigurationModel;
}): string[];
export declare function getConfAssemblyNames(conf: AnyConfigurationModel): string[];
/**
 * return the rpcSessionId of the highest parent node in the tree that has an
 * rpcSessionId */
export declare function getRpcSessionId(thisNode: IAnyStateTreeNode): string;
export declare const UNKNOWN = "UNKNOWN";
export declare const UNSUPPORTED = "UNSUPPORTED";
export declare function getBlob(id: string): File | undefined;
export declare function getBlobMap(): Record<string, File>;
export declare function setBlobMap(map: Record<string, File>): void;
export declare function storeBlobLocation(location: PreFileLocation): BlobLocation | PreFileLocation;
export declare function getFileFromCache(handleId: string): File | undefined;
export declare function setFileInCache(handleId: string, file: File): void;
export declare function clearFileFromCache(handleId: string): void;
export declare function hasFileHandlesInCache(): boolean;
export declare function ensureFileHandleReady(handleId: string, requestPermission?: boolean): Promise<File>;
export declare function storeFileHandleLocation(handle: FileSystemFileHandle): Promise<FileHandleLocation>;
export declare function restoreFileHandles(handleIds: string[], requestPermission?: boolean): Promise<({
    handleId: string;
    success: true;
    error?: undefined;
} | {
    handleId: string;
    success: false;
    error: any;
})[]>;
export declare function findFileHandleIds(obj: unknown): Set<string>;
export declare function restoreFileHandlesFromSnapshot(sessionSnapshot: unknown, requestPermission?: boolean): Promise<({
    handleId: string;
    success: true;
    error?: undefined;
} | {
    handleId: string;
    success: false;
    error: any;
})[]>;
/**
 * creates a new location from the provided location including the appropriate
 * suffix and location type
 *
 * @param location - the FileLocation
 * @param suffix - the file suffix (e.g. .bam)
 * @returns the constructed location object from the provided parameters
 */
export declare function makeIndex(location: FileLocation, suffix: string): BlobLocation | FileHandleLocation | {
    uri: string;
    locationType: string;
    baseUri?: string | undefined;
    localPath?: undefined;
} | {
    localPath: string;
    locationType: string;
};
/**
 * constructs a potential index file (with suffix) from the provided file name
 *
 * @param name - the name of the index file
 * @param typeA - one option of a potential two file suffix (e.g. CSI, BAI)
 * @param typeB - the second option of a potential two file suffix (e.g. CSI, BAI)
 * @returns a likely name of the index file for a given filename
 */
export declare function makeIndexType(name: string | undefined, typeA: string, typeB: string): string;
export interface AdapterConfig {
    type: string;
    [key: string]: unknown;
}
export type AdapterGuesser = (file: FileLocation, index?: FileLocation, adapterHint?: string) => AdapterConfig | undefined;
export type TrackTypeGuesser = (adapterName: string, file?: FileLocation) => string | undefined;
declare module '../PluginManager.ts' {
    interface ExtensionPointRegistry {
        'Core-guessAdapterForLocation': {
            args: AdapterGuesser;
            result: AdapterGuesser;
        };
        'Core-guessTrackTypeForLocation': {
            args: TrackTypeGuesser;
            result: TrackTypeGuesser;
        };
    }
}
/**
 * Register a guess on `Core-guessAdapterForLocation`. Return an adapter config
 * to claim the file, or `undefined` to defer to the plugins registered before
 * this one.
 *
 * Prefer this over calling `addToExtensionPoint` directly: the chaining is done
 * once here, so a plugin cannot break the chain by forgetting to delegate, nor
 * drop an argument on the way through.
 */
export declare function addAdapterGuesser(pluginManager: PluginManager, guess: AdapterGuesser): void;
/**
 * Register a guess on `Core-guessTrackTypeForLocation`. Return a track type
 * name to claim the adapter, or `undefined` to defer. See `addAdapterGuesser`
 * for why this wrapper exists — hand-written delegates here used to drop the
 * optional `file`, which hid it from every guesser registered earlier in the
 * chain.
 */
export declare function addTrackTypeGuesser(pluginManager: PluginManager, guess: TrackTypeGuesser): void;
/**
 * Drop the format extension from a filename, plus any compression suffix, so
 * `volvox.vcf.gz` becomes `volvox` rather than `volvox.vcf`. Names with no
 * extension, and dotfiles, are returned unchanged.
 */
export declare function stripFileExtension(name: string): string;
export declare function guessAdapter(file: FileLocation, index: FileLocation | undefined, adapterHint?: string, model?: IAnyStateTreeNode): AdapterConfig;
export declare function guessTrackType(adapterType: string, model?: IAnyStateTreeNode, file?: FileLocation): string;
export interface LooseTrackInput {
    uri: string;
    index?: string;
    [key: string]: unknown;
}
/**
 * Expand a loose track description — a bare data-file URI, or an object with
 * `uri` (and optional `index`) plus any extra config keys — into a full track
 * config, the same inference the "Add track" flow does: the adapter and track
 * type are guessed from the file via the format plugins, a stable `trackId` and
 * a `name` are derived from the filename, and the assembly is stamped on. Extra
 * keys on the input (`name`, `category`, `displays`, ...) override the inferred
 * defaults. Takes a `pluginManager` (not a model) so it runs headlessly — in a
 * worker/Node export as well as the browser. Throws when no format matches, so
 * the caller can ask for a full config instead.
 */
export declare function guessTrackConf(input: string | LooseTrackInput, pluginManager: PluginManager, assemblyName?: string): {
    trackId: string;
    type: string;
    name: string;
    assemblyNames: string[];
    adapter: AdapterConfig;
};
export declare function generateUnsupportedTrackConf(trackName: string, trackUrl: string, categories: string[] | undefined): {
    type: string;
    name: string;
    description: string;
    category: string[] | undefined;
    trackId: string;
};
export declare function generateUnknownTrackConf(trackName: string, trackUrl: string, categories?: string[]): {
    type: string;
    name: string;
    description: string;
    category: string[] | undefined;
    trackId: string;
};
export declare function getTrackName(conf: AnyConfigurationModel | {
    name?: string;
    type?: string;
    trackId?: string;
}, session: {
    assemblies: AnyConfigurationModel[];
}): string;
type MSTArray<T extends IAnyType> = Instance<ReturnType<typeof types.array<T>>>;
interface MinimalTrack extends IAnyType {
    configuration: {
        trackId: string;
    };
}
interface GenericView {
    type: string;
    tracks: MSTArray<MinimalTrack>;
}
interface DisplayInitialSnapshot {
    type?: string;
    [key: string]: unknown;
}
interface DisplayConfSnapshot {
    type: string;
    displayId?: string;
}
/**
 * Which display a track opens with in a given view, and the display config that
 * display must use: `{ type, conf }`, or undefined when the view supports none
 * of the track's displays.
 *
 * Two decisions, in this order, and the order is the point. The **type** is what
 * the caller asked for, else the track's first declared display the view
 * supports, else the track type's first supported display. The **config** is
 * then whichever declared entry has that type — never "the first supported one",
 * which is what let a display be created wearing another display's config node
 * (a multi-sample VCF declares both the matrix and the regular display, so the
 * regular one inherited the matrix's 20px connector-line zone and drew its
 * clustering tree offset from the rows it labels). `display.type ===
 * display.configuration.type` is the invariant `DisplayConfigurationReference`
 * already assumes when it falls back to resolving a display config by type; this
 * is where it has to hold.
 *
 * `conf` is undefined when the track config declares no entry of that type;
 * `baseTrackConfig.preProcessSnapshot` injects one for every registered display
 * type, so the caller's `${trackId}-${type}` id resolves to it.
 */
export declare function pickDisplayForView({ declaredDisplays, requestedType, trackDisplayTypes, viewDisplayTypes, }: {
    declaredDisplays: DisplayConfSnapshot[];
    requestedType: string | undefined;
    trackDisplayTypes: string[];
    viewDisplayTypes: string[];
}): {
    type: string;
    conf: DisplayConfSnapshot | undefined;
} | undefined;
export type TrackInit = string | {
    trackId: string;
    trackSnapshot?: Record<string, unknown>;
    displaySnapshot?: Record<string, unknown>;
    [key: string]: unknown;
};
export declare function normalizeTrackInit(t: TrackInit): {
    trackId: string;
    trackSnapshot: Record<string, unknown>;
    displaySnapshot: {
        [x: string]: unknown;
    };
};
export declare function showTrackGeneric(self: GenericView, trackId: string, initialSnapshot?: {}, displayInitialSnapshot?: DisplayInitialSnapshot, inlineConf?: Record<string, unknown>): any;
interface DisplaySnapshot {
    id: string;
    [key: string]: unknown;
}
interface TrackSnapshot {
    id: string;
    displays: DisplaySnapshot[];
    [key: string]: unknown;
}
export declare function stripTrackIds(tracks: TrackSnapshot[]): {
    displays: {
        [key: string]: unknown;
    }[];
}[];
export declare function hideTrackGeneric(self: GenericView, trackId: string): boolean;
export declare function toggleTrackGeneric(self: GenericView, trackId: string): boolean;
/**
 * Every track config the session can show, connection-supplied ones included.
 *
 * `session.tracks` is only sessionTracks plus the admin config (see
 * product-core's SessionTracks), so a track that arrived from a hub or registry
 * connection is absent from it while still being toggleable from the track
 * selector, which unions the same two sources. Anything answering "what tracks
 * exist for X" wants this, or a feature silently can't see connection tracks.
 *
 * Note `session.tracks` already contains `sessionTracks` — unioning those two
 * yields every session track twice.
 */
export declare function allSessionTracks(session: {
    tracks: AnyConfigurationModel[];
    connectionInstances?: {
        tracks: AnyConfigurationModel[];
    }[];
}): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
    setSubschema(slotName: string, data: Record<string, unknown>): any;
    setSlot(slotName: string, value: unknown): void;
} & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("../configuration/types.ts").AnyConfigurationSchemaType>)[];
