import type { SimpleFeatureSerialized } from '../../util/index.ts';
import type { SeqState } from '../util.tsx';
import type { SequenceDisplayMode, SequenceFeatureDetailsModel } from './model.ts';
declare const SequenceContents: ({ mode, feature, sequence, model, assemblyGeneticCodeId, revcomp, onHoverBase, }: {
    mode: SequenceDisplayMode;
    feature: SimpleFeatureSerialized;
    sequence: SeqState;
    model: SequenceFeatureDetailsModel;
    assemblyGeneticCodeId?: number;
    revcomp: boolean;
    onHoverBase?: (base0: number) => void;
}) => import("react").JSX.Element;
export default SequenceContents;
