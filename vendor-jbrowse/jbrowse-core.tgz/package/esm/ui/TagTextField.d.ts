import type { TextFieldProps } from '@mui/material';
interface OwnProps {
    defaultValue?: string;
    onValueChange: (value: string | undefined) => void;
    helperText?: TextFieldProps['helperText'];
    inputTestId?: string;
}
type Props = Omit<TextFieldProps, 'value' | 'onChange' | 'error' | 'helperText'> & OwnProps;
export default function TagTextField(props: Props): import("react").JSX.Element;
export {};
