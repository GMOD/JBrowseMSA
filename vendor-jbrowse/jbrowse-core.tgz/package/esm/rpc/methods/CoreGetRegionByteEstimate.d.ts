import RpcMethodTypeWithRenameRegions from '../../pluggableElementTypes/RpcMethodTypeWithRenameRegions.ts';
import type { Region } from '../../util/index.ts';
import type { StatusCallback } from '../../util/progress.ts';
import type { StopToken } from '../../util/stopToken.ts';
export default class CoreGetRegionByteEstimate extends RpcMethodTypeWithRenameRegions<'CoreGetRegionByteEstimate'> {
    name: string;
    execute(args: {
        adapterConfig: Record<string, unknown>;
        regions: Region[];
        stopToken?: StopToken;
        headers?: Record<string, string>;
        statusCallback?: StatusCallback;
        sessionId: string;
    }, rpcDriver: string): Promise<number | undefined>;
}
