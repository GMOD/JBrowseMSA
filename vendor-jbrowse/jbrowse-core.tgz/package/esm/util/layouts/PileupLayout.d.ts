import type { BaseLayout, RectTuple, Rectangle, SerializedLayout } from './BaseLayout.ts';
export interface PileupLayoutOptions {
    featureHeight?: number;
    spacing?: number;
    maxHeight?: number;
    padding?: number;
}
export interface PileupRectangle {
    id: string;
    left: number;
    right: number;
    top: number;
}
export default class PileupLayout<T> implements BaseLayout<T> {
    private featureHeight;
    private spacing;
    private rowHeight;
    private padding;
    private maxRows;
    private rows;
    private rowMaxEnd;
    private rectangles;
    private lastLeft;
    private lastRow;
    maxHeightReached: boolean;
    constructor(options?: PileupLayoutOptions);
    addRect(id: string, left: number, right: number, height: number, data?: T, serializableData?: T): number | null;
    private findFreeRow;
    private addToRow;
    collides(_rect: Rectangle<T>, _top: number): boolean;
    addRectToBitmap(_rect: Rectangle<T>): void;
    getTotalHeight(): number;
    getRectangles(): Map<string, RectTuple>;
    discardRange(left: number, right: number): void;
    getDataByID(id: string): T | undefined;
    serializeRegion(region: {
        start: number;
        end: number;
    }): SerializedLayout;
    toJSON(): SerializedLayout;
}
