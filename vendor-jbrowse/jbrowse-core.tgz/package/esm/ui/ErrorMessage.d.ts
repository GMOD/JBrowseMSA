export default function ErrorMessage({ error }: {
    error: unknown;
}): import("react").JSX.Element;
