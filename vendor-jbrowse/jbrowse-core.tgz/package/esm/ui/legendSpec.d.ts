import type { ColorLegendEntry } from './SvgColorLegend.tsx';
export interface LegendItem {
    color?: string;
    label: string;
}
export interface LegendSection {
    id: string;
    title?: string;
    items: LegendItem[];
}
export interface LegendSpec {
    title?: string;
    items?: LegendItem[];
    sections?: LegendSection[];
}
export declare function nonEmptyLegendSections({ items, sections }: LegendSpec): LegendSection[];
export declare function legendEntries(spec: LegendSpec): ColorLegendEntry[];
