import type { Descriptors, FeatureFormatter } from '../types.tsx';
export default function Attributes(props: {
    attributes: {
        [key: string]: unknown;
        __jbrowsefmt?: Record<string, unknown>;
    };
    omit?: string[];
    omitSingleLevel?: string[];
    formatter?: FeatureFormatter;
    descriptions?: Descriptors;
    prefix?: string[];
    hideUris?: boolean;
}): import("react").JSX.Element;
