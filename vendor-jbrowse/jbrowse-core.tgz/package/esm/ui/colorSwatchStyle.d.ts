export declare const swatchStyle: {
    readonly width: 24;
    readonly height: 24;
    readonly margin: 4;
    readonly border: 'none';
    readonly padding: 0;
    readonly cursor: 'pointer';
    readonly outline: 'none';
};
