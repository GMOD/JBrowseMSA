/** A Link that acts as a button — no real navigation, just calls onClick. */
export default function ActionLink({ onClick, children, className, title, }: {
    onClick: () => void;
    children: React.ReactNode;
    className?: string;
    title?: string;
}): import("react").JSX.Element;
