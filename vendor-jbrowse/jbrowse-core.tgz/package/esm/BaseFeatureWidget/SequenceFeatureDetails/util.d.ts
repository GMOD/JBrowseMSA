import type { SimpleFeatureSerialized } from '../../util/index.ts';
import type { Feat } from '../util.tsx';
/**
 * Splits a string into chunks for display with optional coordinate spacing.
 * The first chunk may be short to complete a row partially filled by a prior
 * call (tracked via `currRemainder`).
 */
export declare function splitString({ str, charactersPerRow, showCoordinates, currRemainder, spacingInterval, }: {
    str: string;
    charactersPerRow: number;
    showCoordinates: boolean;
    currRemainder?: number;
    spacingInterval?: number;
}): {
    segments: string[];
    remainder: number;
};
/**
 * Width to pad every coordinate label in a panel to, so all rows start their
 * sequence at the same column. Row labels step by charactersPerRow from
 * firstCoord, so the longest is at one end of the panel or the other. Floors at
 * 4 to keep the historical look of short (feature-relative) labels.
 */
export declare function coordLabelWidth({ firstCoord, totalLength, charactersPerRow, strand, }: {
    firstCoord: number;
    totalLength: number;
    charactersPerRow: number;
    strand: number;
}): number;
/**
 * The strand the panel reads. A minus-strand feature is already rendered
 * reverse-complemented, so the revcomp toggle flips whichever strand the
 * feature would otherwise be read on rather than forcing the minus strand.
 */
export declare function displayStrand(feature: SimpleFeatureSerialized, revcomp: boolean): -1 | 1;
/**
 * Computes the coordinate multiplier and genomic coordinate start for a sequence
 * display. Both GenomicSequence and CDNASequence use this to initialize their
 * coordinate-tracking state.
 */
export declare function computeCoordProps({ feature, useGenomicCoords, upstream, revcomp, }: {
    feature: SimpleFeatureSerialized;
    useGenomicCoords: boolean;
    upstream: string | undefined;
    revcomp: boolean;
}): {
    mult: number;
    coordStart: number;
};
/**
 * The exonic blocks making up a transcript, feature-relative. Without exon
 * subfeatures the CDS blocks stand in for them, the first and last stretched to
 * the feature bounds so the untranslated flanks are still rendered.
 */
export declare function transcriptRegions({ cds, exons, featureLength, }: {
    cds: Feat[];
    exons: Feat[];
    featureLength: number;
}): Feat[];
/**
 * Splits an exonic region into its coding and untranslated stretches. `cds` must
 * be sorted by start. A region no CDS overlaps comes back wholly untranslated,
 * so a CDS annotated outside the exons degrades to an uncolored transcript
 * rather than dropping sequence or throwing.
 */
export declare function splitRegionByCds(region: Feat, cds: Feat[]): {
    start: number;
    end: number;
    isCds: boolean;
}[];
/**
 * Returns the display string for an intron. Collapses long introns to
 * "NNN...NNN" when collapseIntron is true and the intron exceeds 2*intronBp.
 */
export declare function getIntronDisplayStr(intron: string, intronBp: number, collapseIntron: boolean): string;
/**
 * Text content of the sequence panel for plaintext/FASTA copy+download, with
 * `[data-no-plaintext]` elements (e.g. the legend) stripped so they don't
 * corrupt the sequence output.
 */
export declare function getSequencePlaintext(el: HTMLElement): string;
