export declare const BaseInternetAccountConfig: import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
    name: {
        description: string;
        type: string;
        defaultValue: string;
    };
    description: {
        description: string;
        type: string;
        defaultValue: string;
    };
    authHeader: {
        description: string;
        type: string;
        defaultValue: string;
    };
    tokenType: {
        description: string;
        type: string;
        defaultValue: string;
    };
    domains: {
        description: string;
        type: string;
        defaultValue: never[];
    };
}, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, "internetAccountId">>;
