import type PluginManager from '../../PluginManager';
interface DisplayConfigSnapshot {
    type?: string;
    [key: string]: unknown;
}
export interface TrackConfigSnapshot {
    displays?: DisplayConfigSnapshot[];
    [key: string]: unknown;
}
declare module '../../PluginManager.ts' {
    interface ExtensionPointRegistry {
        'Core-preProcessTrackConfig': {
            args: TrackConfigSnapshot;
            result: TrackConfigSnapshot;
        };
    }
}
export declare function addDisplayConfigMigration(pluginManager: PluginManager, displayTypes: string[], migrate: (displaySnap: Record<string, unknown>) => Record<string, unknown>): void;
export interface LegacyDisplaySnapshot {
    type: string;
    displayId?: string;
    renderer?: {
        type: string;
        height?: unknown;
        [key: string]: unknown;
    };
    [key: string]: unknown;
}
export declare function liftLegacyRendererConfig(d: LegacyDisplaySnapshot, trackId: string): {
    type: string;
    featureHeight?: {} | null | undefined;
    displayId: string;
};
export {};
