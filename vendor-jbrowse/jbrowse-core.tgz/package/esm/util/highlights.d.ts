import type { Theme } from '@mui/material';
export declare function highlightKey(h: {
    assemblyName?: string;
    refName: string;
    start: number;
    end: number;
}, i: number): string;
export declare function getHighlightColor(highlight: {
    color?: string;
}, theme: Theme, alpha?: number): import("./colord.ts").Colord;
