export default function RubberbandTooltip({ anchorEl, side, text, }: {
    anchorEl: HTMLSpanElement;
    side: string;
    text: React.ReactNode;
}): import("react").JSX.Element;
