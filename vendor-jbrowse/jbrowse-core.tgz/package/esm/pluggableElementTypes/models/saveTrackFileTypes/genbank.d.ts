import type { AbstractSessionModel, Feature } from '../../../util/index.ts';
export declare function formatFeatWithSubfeatures({ feature, minPos, geneName, }: {
    feature: Feature;
    minPos: number;
    geneName?: string;
}): string;
export declare function stringifyGBK({ features, assemblyName, session, }: {
    assemblyName: string;
    session: AbstractSessionModel;
    features: Feature[];
}): Promise<string>;
