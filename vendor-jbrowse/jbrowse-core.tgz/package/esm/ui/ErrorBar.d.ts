export default function ErrorBar({ error, onRetry, }: {
    error: unknown;
    onRetry: () => void;
}): import("react").JSX.Element;
