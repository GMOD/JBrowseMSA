export default function FatalErrorDialog({ componentStack, error, onFactoryReset, resetButtonText, extraActions, }: {
    componentStack?: string;
    error?: unknown;
    onFactoryReset: () => void;
    resetButtonText?: string;
    extraActions?: React.ReactNode;
}): import("react").JSX.Element;
