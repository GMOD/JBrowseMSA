import type { PluginDefinition } from '../PluginLoader.ts';
import type { JBrowsePlugin } from './types/index.ts';
export interface ResolvedPlugin {
    compatible: boolean;
    pluginVersion?: string;
    supportedRanges: string[];
    definition: PluginDefinition;
}
export interface PluginUpdate {
    pluginVersion: string;
    definition: PluginDefinition;
}
export declare function resolvePlugin(plugin: JBrowsePlugin, jbrowseVersion: string): ResolvedPlugin;
export declare function installedVersionFromUrl(url: string | undefined, packageName: string | undefined): string | undefined;
export declare function getPluginUpdate(plugin: JBrowsePlugin, jbrowseVersion: string, installedVersion: string | undefined): PluginUpdate | undefined;
