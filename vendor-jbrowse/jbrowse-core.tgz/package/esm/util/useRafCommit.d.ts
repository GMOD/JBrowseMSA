export declare function useRafCommit(commit: (value: number) => void): {
    schedule: (value: number) => void;
    flush: () => void;
};
