import type { SimpleFeatureSerialized } from '../../util/index.ts';
export declare function splitString({ str, charactersPerRow, showCoordinates, currRemainder, spacingInterval, }: {
    str: string;
    charactersPerRow: number;
    showCoordinates: boolean;
    currRemainder?: number;
    spacingInterval?: number;
}): {
    segments: string[];
    remainder: number;
};
export declare function computeCoordProps(feature: SimpleFeatureSerialized, useGenomicCoords: boolean, upstream: string | undefined): {
    strand: number;
    mult: number;
    coordStart: number;
};
export declare function getIntronDisplayStr(intron: string, intronBp: number, collapseIntron: boolean): string;
export declare function getSequencePlaintext(el: HTMLElement): string;
