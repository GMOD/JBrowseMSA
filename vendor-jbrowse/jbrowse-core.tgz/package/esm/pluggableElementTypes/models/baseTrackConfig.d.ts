import type PluginManager from '../../PluginManager.ts';
import type { Instance } from '@jbrowse/mobx-state-tree';
export declare function createBaseTrackConfig(pluginManager: PluginManager): import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
    name: {
        description: string;
        type: string;
        defaultValue: string;
    };
    assemblyNames: {
        description: string;
        type: string;
        defaultValue: string[];
    };
    description: {
        description: string;
        type: string;
        defaultValue: string;
    };
    category: {
        description: string;
        type: string;
        defaultValue: never[];
    };
    metadata: {
        type: string;
        description: string;
        defaultValue: {};
    };
    rpcDriverName: {
        type: string;
        description: string;
        defaultValue: string;
        advanced: true;
    };
    adapter: import("@jbrowse/mobx-state-tree").IAnyModelType;
    textSearching: import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
        indexingAttributes: {
            type: string;
            description: string;
            defaultValue: string[];
        };
        indexingFeatureTypesToExclude: {
            type: string;
            description: string;
            defaultValue: string[];
        };
        textSearchAdapter: import("@jbrowse/mobx-state-tree").IAnyModelType;
    }, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
    displays: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyModelType>;
    formatDetails: import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
        feature: {
            type: string;
            description: string;
            defaultValue: {};
            contextVariable: string[];
        };
        subfeatures: {
            type: string;
            description: string;
            defaultValue: {};
            contextVariable: string[];
        };
        depth: {
            type: string;
            defaultValue: number;
            description: string;
        };
        maxDepth: {
            type: string;
            defaultValue: number;
            description: string;
        };
    }, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
    formatAbout: import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
        config: {
            type: string;
            description: string;
            defaultValue: {};
            contextVariable: string[];
        };
        hideUris: {
            type: string;
            defaultValue: boolean;
        };
    }, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
}, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, "trackId">>;
export type BaseTrackConfigSchema = ReturnType<typeof createBaseTrackConfig>;
export type BaseTrackConfig = Instance<BaseTrackConfigSchema>;
