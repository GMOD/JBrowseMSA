/**
 * Used by plugin build systems to determine if a module is provided by JBrowse
 * globally and thus doesn't need to be bundled. A check in ./modules.tsx makes
 * sure this is in sync with the re-exported modules.
 *
 * Using this instead of just Object.keys(modules) allows this file to be
 * easily used by downstream tooling like simple esbuild scripts, rollup
 * configs, etc. without actually importing all the modules in modules.tsx,
 * which a Object.keys(modules) would do
 */
declare const _default: string[];
export default _default;
