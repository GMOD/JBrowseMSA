import type { ConfigSlotDefinition } from './configurationSlot.ts';
import type { AnyConfigurationSchemaType } from './types.ts';
import type { IAnyType } from '@jbrowse/mobx-state-tree';
export type { AnyConfigurationModel, AnyConfigurationSchemaType, AnyConfigurationSlot, AnyConfigurationSlotType, } from './types.ts';
export interface ConfigurationSchemaDefinition {
    [n: string]: ConfigSlotDefinition | ConfigurationSchemaDefinition | string | number | IAnyType;
}
export interface ConfigurationSchemaOptions<BASE_SCHEMA extends AnyConfigurationSchemaType | undefined, EXPLICIT_IDENTIFIER extends string | undefined> {
    explicitlyTyped?: boolean;
    explicitIdentifier?: EXPLICIT_IDENTIFIER;
    implicitIdentifier?: string | boolean;
    baseConfiguration?: BASE_SCHEMA;
    actions?: (self: unknown) => any;
    views?: (self: unknown) => any;
    extend?: (self: unknown) => any;
    preProcessSnapshot?: (snapshot: Record<string, unknown>) => Record<string, unknown>;
}
declare function makeConfigurationSchemaModel<DEFINITION extends ConfigurationSchemaDefinition, OPTIONS extends ConfigurationSchemaOptions<any, any>>(modelName: string, schemaDefinition: DEFINITION, options: OPTIONS): import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IModelType<Record<string, any>, {
    setSubschema(slotName: string, data: Record<string, unknown>): any;
    setSlot(slotName: string, value: unknown): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>, [undefined]>;
export interface ConfigurationSchemaType<DEFINITION extends ConfigurationSchemaDefinition, OPTIONS extends ConfigurationSchemaOptions<any, any>> extends ReturnType<typeof makeConfigurationSchemaModel<DEFINITION, OPTIONS>> {
    type: string;
}
export declare function ConfigurationSchema<DEFINITION extends ConfigurationSchemaDefinition, BASE_SCHEMA extends AnyConfigurationSchemaType | undefined = undefined, EXPLICIT_IDENTIFIER extends string | undefined = undefined>(modelName: string, inputSchemaDefinition: DEFINITION, inputOptions?: ConfigurationSchemaOptions<BASE_SCHEMA, EXPLICIT_IDENTIFIER>): ConfigurationSchemaType<DEFINITION, ConfigurationSchemaOptions<BASE_SCHEMA, EXPLICIT_IDENTIFIER>>;
export declare function TrackConfigurationReference(schemaType: IAnyType): import("@jbrowse/mobx-state-tree").ITypeUnion<any, any, any>;
export declare function DisplayConfigurationReference(schemaType: IAnyType): import("@jbrowse/mobx-state-tree").ITypeUnion<any, any, any>;
export declare function ConfigurationReference<SCHEMATYPE extends AnyConfigurationSchemaType>(schemaType: SCHEMATYPE): import("@jbrowse/mobx-state-tree").ITypeUnion<any, any, any>;
