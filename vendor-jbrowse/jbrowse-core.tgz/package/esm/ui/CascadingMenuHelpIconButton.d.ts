import type React from 'react';
export declare function CascadingMenuHelpIconSpacer(): React.JSX.Element;
export default function CascadingMenuHelpIconButton({ helpText, label, }: {
    helpText: string;
    label?: React.ReactNode;
}): React.JSX.Element;
