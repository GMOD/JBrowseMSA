import PluggableElementBase from './PluggableElementBase.ts';
import type { AnyConfigurationSchemaType } from '../configuration/index.ts';
import type { AnyAdapter } from '../data_adapters/BaseAdapter/index.ts';
export interface AdapterMetadata {
    category?: string;
    hiddenFromGUI?: boolean;
    description?: string;
}
export type NormalizeSnapshot = (snap: Record<string, unknown>) => Record<string, unknown>;
export default class AdapterType extends PluggableElementBase {
    getAdapterClass: () => Promise<AnyAdapter>;
    configSchema: AnyConfigurationSchemaType;
    adapterCapabilities: string[];
    adapterMetadata?: AdapterMetadata;
    normalizeSnapshot?: NormalizeSnapshot;
    locationKey?: string;
    constructor(stuff: {
        name: string;
        configSchema: AnyConfigurationSchemaType;
        displayName?: string;
        adapterCapabilities?: string[];
        adapterMetadata?: AdapterMetadata;
        normalizeSnapshot?: NormalizeSnapshot;
        locationKey?: string;
    } & ({
        getAdapterClass: () => Promise<AnyAdapter>;
    } | {
        AdapterClass: AnyAdapter;
    }));
}
