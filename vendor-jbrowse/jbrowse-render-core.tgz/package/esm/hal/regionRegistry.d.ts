export declare class RegionRegistry<Buf> {
    private readonly destroy;
    private regions;
    private written;
    constructor(destroy: (buf: Buf) => void);
    get(regionKey: number, passId: string): Buf | undefined;
    set(regionKey: number, passId: string, buf: Buf): void;
    beginUpload(): void;
    endUpload(): void;
    deleteBuffer(regionKey: number, passId: string): void;
    deleteRegion(regionKey: number): void;
    deleteAll(): void;
    prune(active: Iterable<number>): void;
    forEachInPass(passId: string, visit: (buf: Buf, regionKey: number) => void): void;
}
