import RpcMethodType from '../../pluggableElementTypes/RpcMethodType.ts';
export default class CoreFreeResources extends RpcMethodType {
    name: string;
    execute(args: {
        sessionId?: string;
    }): Promise<void>;
    serializeArguments(args: Record<string, unknown>, _rpcDriver: string): Promise<Record<string, unknown>>;
}
