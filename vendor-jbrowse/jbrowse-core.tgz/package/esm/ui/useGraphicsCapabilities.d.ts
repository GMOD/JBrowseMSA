export declare function useGraphicsCapabilities(): import("./getGraphicsCapabilities.ts").GraphicsCapabilities | null;
