import type React from 'react';
import PluggableElementBase from '../PluggableElementBase.ts';
import type PluginManager from '../../PluginManager.ts';
import type { AnyConfigurationSchemaType } from '../../configuration/index.ts';
import type { AnyReactComponentType } from '../../util/index.ts';
import type { RpcResult } from '../../util/librpc.ts';
export type RenderProps = Record<string, unknown>;
export interface RenderResults {
    reactElement?: React.ReactElement;
    html?: string;
    [key: string]: unknown;
}
export type RenderReturn = RenderResults | RpcResult;
export default class RendererType extends PluggableElementBase {
    ReactComponent: AnyReactComponentType;
    supportsSVG: boolean;
    configSchema: AnyConfigurationSchemaType;
    pluginManager: PluginManager;
    constructor(stuff: {
        name: string;
        ReactComponent: AnyReactComponentType;
        displayName?: string;
        configSchema: AnyConfigurationSchemaType;
        pluginManager: PluginManager;
    });
    render(props: RenderProps): Promise<RenderReturn>;
    freeResources(_args: unknown): void;
}
