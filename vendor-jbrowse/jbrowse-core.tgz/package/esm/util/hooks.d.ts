import type { RefObject } from 'react';
export declare function useFocusOnInteraction(ref: RefObject<HTMLElement | null>, onInteract: () => void): void;
export declare function useDebounce<T>(value: T, delay: number): T;
export declare function useWidthSetter(view: {
    setWidth: (arg: number) => void;
    id?: string;
}, padding: string): RefObject<HTMLDivElement | null>;
export declare function useLocalStorage<T>(key: string, initialValue: T, enabled?: boolean): readonly [T, (value: T | ((val: T) => T)) => void];
