import type { MenuItem } from './MenuTypes.ts';
import type PluginManager from '../PluginManager.ts';
export type Compactness = 'normal' | 'compact' | 'super-compact';
export interface CompactableDisplay {
    setCompactness: (v: Compactness) => void;
}
export declare function isCompactable(d: unknown): d is CompactableDisplay;
export type GroupOp = (displays: unknown[]) => MenuItem[];
declare module '@jbrowse/core/PluginManager' {
    interface ExtensionPointRegistry {
        'Core-extendAllTracksMenu': {
            args: GroupOp[];
            result: GroupOp[];
        };
    }
}
export declare function buildAllTracksMenu(pluginManager: PluginManager, tracks: {
    displays: unknown[];
}[]): MenuItem[];
