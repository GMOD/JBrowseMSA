import type { GpuHal } from './hal/types.ts';
export declare abstract class GpuRenderingBackendBase {
    protected hal: GpuHal;
    protected uniformData: ArrayBuffer;
    constructor(hal: GpuHal, uniformByteSize: number);
    dispose(): void;
}
export declare abstract class Canvas2DRenderingBackendBase {
    protected canvas: HTMLCanvasElement;
    protected ctx: CanvasRenderingContext2D;
    constructor(canvas: HTMLCanvasElement);
    dispose(): void;
}
