import type { Props as DialogProps } from './Dialog.tsx';
declare const DraggableDialog: (props: Omit<DialogProps, 'slotProps'> & {
    title: string;
}) => import("react").JSX.Element;
export default DraggableDialog;
