export declare function onDeviceLost(listener: () => void): () => void;
export declare function setGpuOverride(value: string | null): void;
export declare function getGpuOverride(): string | null;
/**
 * Whether the GPU is off for the whole page — either pinned by `?renderer=` at
 * startup or switched off from a display's GPU-error banner after an
 * unrecoverable WebGL context loss. `createGpuHal` returns null in that case, so
 * every backend built from then on is the Canvas2D one.
 */
export declare function isGpuRenderingDisabled(): boolean;
/**
 * Reset module-level singleton state. For use in tests only — clears
 * `device` and `devicePromise` so the next `getGpuDevice()` call starts
 * fresh rather than returning the cached (possibly null) promise from a
 * previous test.
 */
export declare function resetGpuDeviceForTests(): void;
export declare function getGpuDevice(): Promise<GPUDevice | null>;
