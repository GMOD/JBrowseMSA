import type { AbstractRootModel } from '../../util/types/index.ts';
export default function useInternetAccounts(rootModel?: AbstractRootModel): {
    accountMap: {
        [k: string]: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            configuration: import("../../configuration/configurationSchema.ts").IConfigurationReference<import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
                readonly name: {
                    readonly description: "descriptive name of the internet account";
                    readonly type: "string";
                    readonly defaultValue: "";
                };
                readonly description: {
                    readonly description: "a description of the internet account";
                    readonly type: "string";
                    readonly defaultValue: "";
                };
                readonly authHeader: {
                    readonly description: "request header for credentials";
                    readonly type: "string";
                    readonly defaultValue: "Authorization";
                };
                readonly tokenType: {
                    readonly description: "a custom name for a token to include in the header";
                    readonly type: "string";
                    readonly defaultValue: "";
                };
                readonly domains: {
                    readonly description: "array of valid domains the url can contain to use this account";
                    readonly type: "stringArray";
                    readonly defaultValue: readonly [];
                };
            }, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, "internetAccountId">>>;
        }> & {
            readonly name: string;
            readonly description: string;
            readonly internetAccountId: string;
            readonly authHeader: string;
            readonly tokenType: string;
            readonly domains: string[];
            readonly toggleContents: React.ReactNode;
            readonly SelectorComponent: import("../../util/index.ts").AnyReactComponentType | undefined;
            readonly selectorLabel: string | undefined;
        } & {
            handlesLocation(location: import("../../util/index.ts").UriLocation): boolean;
            readonly tokenKey: string;
        } & {
            getTokenFromUser(_resolve: (token: string) => void, _reject: (error: Error) => void): void;
            storeToken(token: string): void;
            retrieveToken(): string | null;
            validateToken(token: string, _loc: import("../../util/index.ts").UriLocation): Promise<string>;
        } & {
            removeToken(): void;
            getToken(location?: import("../../util/index.ts").UriLocation): Promise<string>;
        } & {
            addAuthHeaderToInit(init?: RequestInit, token?: string): {
                body?: BodyInit | null;
                cache?: RequestCache;
                credentials?: RequestCredentials;
                integrity?: string;
                keepalive?: boolean;
                method?: string;
                mode?: RequestMode;
                priority?: RequestPriority;
                redirect?: RequestRedirect;
                referrer?: string;
                referrerPolicy?: ReferrerPolicy;
                signal?: AbortSignal | null;
                window?: null;
                headers: Headers;
            };
            getValidatedToken(loc?: import("../../util/index.ts").UriLocation): Promise<string>;
            getPreAuthorizationInformation(location: import("../../util/index.ts").UriLocation): Promise<{
                internetAccountType: string;
                authInfo: {
                    token: string;
                    configuration: any;
                };
            }>;
        } & {
            getFetcher(loc?: import("../../util/index.ts").UriLocation): (input: RequestInfo, init?: RequestInit) => Promise<Response>;
        } & {
            openLocation(location: import("../../util/index.ts").UriLocation): import("../../util/io/RemoteFileWithRangeCache.ts").RemoteFileWithRangeCache;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            configuration: import("../../configuration/configurationSchema.ts").IConfigurationReference<import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
                readonly name: {
                    readonly description: "descriptive name of the internet account";
                    readonly type: "string";
                    readonly defaultValue: "";
                };
                readonly description: {
                    readonly description: "a description of the internet account";
                    readonly type: "string";
                    readonly defaultValue: "";
                };
                readonly authHeader: {
                    readonly description: "request header for credentials";
                    readonly type: "string";
                    readonly defaultValue: "Authorization";
                };
                readonly tokenType: {
                    readonly description: "a custom name for a token to include in the header";
                    readonly type: "string";
                    readonly defaultValue: "";
                };
                readonly domains: {
                    readonly description: "array of valid domains the url can contain to use this account";
                    readonly type: "stringArray";
                    readonly defaultValue: readonly [];
                };
            }, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, "internetAccountId">>>;
        }, {
            readonly name: string;
            readonly description: string;
            readonly internetAccountId: string;
            readonly authHeader: string;
            readonly tokenType: string;
            readonly domains: string[];
            readonly toggleContents: React.ReactNode;
            readonly SelectorComponent: import("../../util/index.ts").AnyReactComponentType | undefined;
            readonly selectorLabel: string | undefined;
        } & {
            handlesLocation(location: import("../../util/index.ts").UriLocation): boolean;
            readonly tokenKey: string;
        } & {
            getTokenFromUser(_resolve: (token: string) => void, _reject: (error: Error) => void): void;
            storeToken(token: string): void;
            retrieveToken(): string | null;
            validateToken(token: string, _loc: import("../../util/index.ts").UriLocation): Promise<string>;
        } & {
            removeToken(): void;
            getToken(location?: import("../../util/index.ts").UriLocation): Promise<string>;
        } & {
            addAuthHeaderToInit(init?: RequestInit, token?: string): {
                body?: BodyInit | null;
                cache?: RequestCache;
                credentials?: RequestCredentials;
                integrity?: string;
                keepalive?: boolean;
                method?: string;
                mode?: RequestMode;
                priority?: RequestPriority;
                redirect?: RequestRedirect;
                referrer?: string;
                referrerPolicy?: ReferrerPolicy;
                signal?: AbortSignal | null;
                window?: null;
                headers: Headers;
            };
            getValidatedToken(loc?: import("../../util/index.ts").UriLocation): Promise<string>;
            getPreAuthorizationInformation(location: import("../../util/index.ts").UriLocation): Promise<{
                internetAccountType: string;
                authInfo: {
                    token: string;
                    configuration: any;
                };
            }>;
        } & {
            getFetcher(loc?: import("../../util/index.ts").UriLocation): (input: RequestInfo, init?: RequestInit) => Promise<Response>;
        } & {
            openLocation(location: import("../../util/index.ts").UriLocation): import("../../util/io/RemoteFileWithRangeCache.ts").RemoteFileWithRangeCache;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
    };
    shownAccounts: (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
        type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        configuration: import("../../configuration/configurationSchema.ts").IConfigurationReference<import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
            readonly name: {
                readonly description: "descriptive name of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly description: {
                readonly description: "a description of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly authHeader: {
                readonly description: "request header for credentials";
                readonly type: "string";
                readonly defaultValue: "Authorization";
            };
            readonly tokenType: {
                readonly description: "a custom name for a token to include in the header";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly domains: {
                readonly description: "array of valid domains the url can contain to use this account";
                readonly type: "stringArray";
                readonly defaultValue: readonly [];
            };
        }, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, "internetAccountId">>>;
    }> & {
        readonly name: string;
        readonly description: string;
        readonly internetAccountId: string;
        readonly authHeader: string;
        readonly tokenType: string;
        readonly domains: string[];
        readonly toggleContents: React.ReactNode;
        readonly SelectorComponent: import("../../util/index.ts").AnyReactComponentType | undefined;
        readonly selectorLabel: string | undefined;
    } & {
        handlesLocation(location: import("../../util/index.ts").UriLocation): boolean;
        readonly tokenKey: string;
    } & {
        getTokenFromUser(_resolve: (token: string) => void, _reject: (error: Error) => void): void;
        storeToken(token: string): void;
        retrieveToken(): string | null;
        validateToken(token: string, _loc: import("../../util/index.ts").UriLocation): Promise<string>;
    } & {
        removeToken(): void;
        getToken(location?: import("../../util/index.ts").UriLocation): Promise<string>;
    } & {
        addAuthHeaderToInit(init?: RequestInit, token?: string): {
            body?: BodyInit | null;
            cache?: RequestCache;
            credentials?: RequestCredentials;
            integrity?: string;
            keepalive?: boolean;
            method?: string;
            mode?: RequestMode;
            priority?: RequestPriority;
            redirect?: RequestRedirect;
            referrer?: string;
            referrerPolicy?: ReferrerPolicy;
            signal?: AbortSignal | null;
            window?: null;
            headers: Headers;
        };
        getValidatedToken(loc?: import("../../util/index.ts").UriLocation): Promise<string>;
        getPreAuthorizationInformation(location: import("../../util/index.ts").UriLocation): Promise<{
            internetAccountType: string;
            authInfo: {
                token: string;
                configuration: any;
            };
        }>;
    } & {
        getFetcher(loc?: import("../../util/index.ts").UriLocation): (input: RequestInfo, init?: RequestInit) => Promise<Response>;
    } & {
        openLocation(location: import("../../util/index.ts").UriLocation): import("../../util/io/RemoteFileWithRangeCache.ts").RemoteFileWithRangeCache;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
        type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        configuration: import("../../configuration/configurationSchema.ts").IConfigurationReference<import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
            readonly name: {
                readonly description: "descriptive name of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly description: {
                readonly description: "a description of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly authHeader: {
                readonly description: "request header for credentials";
                readonly type: "string";
                readonly defaultValue: "Authorization";
            };
            readonly tokenType: {
                readonly description: "a custom name for a token to include in the header";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly domains: {
                readonly description: "array of valid domains the url can contain to use this account";
                readonly type: "stringArray";
                readonly defaultValue: readonly [];
            };
        }, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, "internetAccountId">>>;
    }, {
        readonly name: string;
        readonly description: string;
        readonly internetAccountId: string;
        readonly authHeader: string;
        readonly tokenType: string;
        readonly domains: string[];
        readonly toggleContents: React.ReactNode;
        readonly SelectorComponent: import("../../util/index.ts").AnyReactComponentType | undefined;
        readonly selectorLabel: string | undefined;
    } & {
        handlesLocation(location: import("../../util/index.ts").UriLocation): boolean;
        readonly tokenKey: string;
    } & {
        getTokenFromUser(_resolve: (token: string) => void, _reject: (error: Error) => void): void;
        storeToken(token: string): void;
        retrieveToken(): string | null;
        validateToken(token: string, _loc: import("../../util/index.ts").UriLocation): Promise<string>;
    } & {
        removeToken(): void;
        getToken(location?: import("../../util/index.ts").UriLocation): Promise<string>;
    } & {
        addAuthHeaderToInit(init?: RequestInit, token?: string): {
            body?: BodyInit | null;
            cache?: RequestCache;
            credentials?: RequestCredentials;
            integrity?: string;
            keepalive?: boolean;
            method?: string;
            mode?: RequestMode;
            priority?: RequestPriority;
            redirect?: RequestRedirect;
            referrer?: string;
            referrerPolicy?: ReferrerPolicy;
            signal?: AbortSignal | null;
            window?: null;
            headers: Headers;
        };
        getValidatedToken(loc?: import("../../util/index.ts").UriLocation): Promise<string>;
        getPreAuthorizationInformation(location: import("../../util/index.ts").UriLocation): Promise<{
            internetAccountType: string;
            authInfo: {
                token: string;
                configuration: any;
            };
        }>;
    } & {
        getFetcher(loc?: import("../../util/index.ts").UriLocation): (input: RequestInfo, init?: RequestInit) => Promise<Response>;
    } & {
        openLocation(location: import("../../util/index.ts").UriLocation): import("../../util/io/RemoteFileWithRangeCache.ts").RemoteFileWithRangeCache;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>)[];
    hiddenAccounts: (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
        type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        configuration: import("../../configuration/configurationSchema.ts").IConfigurationReference<import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
            readonly name: {
                readonly description: "descriptive name of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly description: {
                readonly description: "a description of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly authHeader: {
                readonly description: "request header for credentials";
                readonly type: "string";
                readonly defaultValue: "Authorization";
            };
            readonly tokenType: {
                readonly description: "a custom name for a token to include in the header";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly domains: {
                readonly description: "array of valid domains the url can contain to use this account";
                readonly type: "stringArray";
                readonly defaultValue: readonly [];
            };
        }, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, "internetAccountId">>>;
    }> & {
        readonly name: string;
        readonly description: string;
        readonly internetAccountId: string;
        readonly authHeader: string;
        readonly tokenType: string;
        readonly domains: string[];
        readonly toggleContents: React.ReactNode;
        readonly SelectorComponent: import("../../util/index.ts").AnyReactComponentType | undefined;
        readonly selectorLabel: string | undefined;
    } & {
        handlesLocation(location: import("../../util/index.ts").UriLocation): boolean;
        readonly tokenKey: string;
    } & {
        getTokenFromUser(_resolve: (token: string) => void, _reject: (error: Error) => void): void;
        storeToken(token: string): void;
        retrieveToken(): string | null;
        validateToken(token: string, _loc: import("../../util/index.ts").UriLocation): Promise<string>;
    } & {
        removeToken(): void;
        getToken(location?: import("../../util/index.ts").UriLocation): Promise<string>;
    } & {
        addAuthHeaderToInit(init?: RequestInit, token?: string): {
            body?: BodyInit | null;
            cache?: RequestCache;
            credentials?: RequestCredentials;
            integrity?: string;
            keepalive?: boolean;
            method?: string;
            mode?: RequestMode;
            priority?: RequestPriority;
            redirect?: RequestRedirect;
            referrer?: string;
            referrerPolicy?: ReferrerPolicy;
            signal?: AbortSignal | null;
            window?: null;
            headers: Headers;
        };
        getValidatedToken(loc?: import("../../util/index.ts").UriLocation): Promise<string>;
        getPreAuthorizationInformation(location: import("../../util/index.ts").UriLocation): Promise<{
            internetAccountType: string;
            authInfo: {
                token: string;
                configuration: any;
            };
        }>;
    } & {
        getFetcher(loc?: import("../../util/index.ts").UriLocation): (input: RequestInfo, init?: RequestInit) => Promise<Response>;
    } & {
        openLocation(location: import("../../util/index.ts").UriLocation): import("../../util/io/RemoteFileWithRangeCache.ts").RemoteFileWithRangeCache;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
        type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        configuration: import("../../configuration/configurationSchema.ts").IConfigurationReference<import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
            readonly name: {
                readonly description: "descriptive name of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly description: {
                readonly description: "a description of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly authHeader: {
                readonly description: "request header for credentials";
                readonly type: "string";
                readonly defaultValue: "Authorization";
            };
            readonly tokenType: {
                readonly description: "a custom name for a token to include in the header";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly domains: {
                readonly description: "array of valid domains the url can contain to use this account";
                readonly type: "stringArray";
                readonly defaultValue: readonly [];
            };
        }, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, "internetAccountId">>>;
    }, {
        readonly name: string;
        readonly description: string;
        readonly internetAccountId: string;
        readonly authHeader: string;
        readonly tokenType: string;
        readonly domains: string[];
        readonly toggleContents: React.ReactNode;
        readonly SelectorComponent: import("../../util/index.ts").AnyReactComponentType | undefined;
        readonly selectorLabel: string | undefined;
    } & {
        handlesLocation(location: import("../../util/index.ts").UriLocation): boolean;
        readonly tokenKey: string;
    } & {
        getTokenFromUser(_resolve: (token: string) => void, _reject: (error: Error) => void): void;
        storeToken(token: string): void;
        retrieveToken(): string | null;
        validateToken(token: string, _loc: import("../../util/index.ts").UriLocation): Promise<string>;
    } & {
        removeToken(): void;
        getToken(location?: import("../../util/index.ts").UriLocation): Promise<string>;
    } & {
        addAuthHeaderToInit(init?: RequestInit, token?: string): {
            body?: BodyInit | null;
            cache?: RequestCache;
            credentials?: RequestCredentials;
            integrity?: string;
            keepalive?: boolean;
            method?: string;
            mode?: RequestMode;
            priority?: RequestPriority;
            redirect?: RequestRedirect;
            referrer?: string;
            referrerPolicy?: ReferrerPolicy;
            signal?: AbortSignal | null;
            window?: null;
            headers: Headers;
        };
        getValidatedToken(loc?: import("../../util/index.ts").UriLocation): Promise<string>;
        getPreAuthorizationInformation(location: import("../../util/index.ts").UriLocation): Promise<{
            internetAccountType: string;
            authInfo: {
                token: string;
                configuration: any;
            };
        }>;
    } & {
        getFetcher(loc?: import("../../util/index.ts").UriLocation): (input: RequestInfo, init?: RequestInit) => Promise<Response>;
    } & {
        openLocation(location: import("../../util/index.ts").UriLocation): import("../../util/io/RemoteFileWithRangeCache.ts").RemoteFileWithRangeCache;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>)[];
    recentlyUsed: string[];
    setRecentlyUsed: (value: string[] | ((val: string[]) => string[])) => void;
};
