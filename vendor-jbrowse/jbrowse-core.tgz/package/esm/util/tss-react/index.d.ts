export { keyframes } from '@emotion/react';
export { makeStyles } from './mui/index.ts';
import { type CxArg } from './tools/classnames.ts';
export declare function cx(...args: CxArg[]): string;
