import type { TextFieldProps } from '@mui/material';
export default function MonospaceTextField({ value, onChange, error, label, children, style, readOnly, ...rest }: {
    value: string;
    onChange?: (value: string) => void;
    error?: unknown;
    label?: React.ReactNode;
    children?: React.ReactNode;
    readOnly?: boolean;
} & Omit<TextFieldProps, 'value' | 'onChange' | 'error' | 'slotProps'>): import("react").JSX.Element;
