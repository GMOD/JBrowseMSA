import PluggableElementBase from './PluggableElementBase.ts';
import type { AnyConfigurationModel } from '../configuration/index.ts';
import type { Feature, Region } from '../util/index.ts';
import type { Theme } from '@mui/material';
export interface GlyphRenderContext {
    ctx: CanvasRenderingContext2D;
    feature: Feature;
    featureLayout: GlyphFeatureLayout;
    region: Region;
    bpPerPx: number;
    config: AnyConfigurationModel;
    theme: Theme;
    reversed: boolean;
    topLevel: boolean;
    canvasWidth: number;
}
export interface GlyphFeatureLayout {
    feature: Feature;
    x: number;
    y: number;
    width: number;
    height: number;
    children: GlyphFeatureLayout[];
}
export interface GlyphArgs {
    name: string;
    displayName?: string;
    draw: (context: GlyphRenderContext) => void;
    getChildFeatures?: (feature: Feature, config: AnyConfigurationModel) => Feature[];
    getHeightMultiplier?: (feature: Feature, config: AnyConfigurationModel) => number;
    getSubfeatureMouseover?: (childFeature: Feature) => string | undefined;
    match?: (feature: Feature) => boolean;
    priority?: number;
}
export default class GlyphType extends PluggableElementBase {
    draw: (context: GlyphRenderContext) => void;
    getChildFeatures?: (feature: Feature, config: AnyConfigurationModel) => Feature[];
    getHeightMultiplier?: (feature: Feature, config: AnyConfigurationModel) => number;
    getSubfeatureMouseover?: (childFeature: Feature) => string | undefined;
    match?: (feature: Feature) => boolean;
    priority: number;
    constructor(args: GlyphArgs);
}
