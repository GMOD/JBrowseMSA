import type { SimpleFeatureSerialized } from '../../util/index.ts';
import type { Feat, SeqState } from '../util.tsx';
export declare function getSequenceData({ feature, sequence, revcomp, }: {
    feature: SimpleFeatureSerialized;
    sequence: SeqState;
    revcomp: boolean;
}): {
    seq: string;
    upstream?: string;
    downstream?: string;
    cds: Feat[];
    exons: Feat[];
};
