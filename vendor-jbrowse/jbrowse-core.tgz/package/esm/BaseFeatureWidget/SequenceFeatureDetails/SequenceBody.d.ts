import type { RefObject } from 'react';
import type { SequenceDisplayMode, SequenceFeatureDetailsModel } from './model.ts';
import type { SimpleFeatureSerialized } from '../../util/index.ts';
import type { ErrorState, SeqState } from '../util.tsx';
export default function SequenceBody({ error, sequence, feature, seqPanelRef, model, mode, assemblyGeneticCodeId, onForceLoad, }: {
    error: unknown;
    sequence: SeqState | ErrorState | undefined;
    feature: SimpleFeatureSerialized;
    seqPanelRef: RefObject<HTMLDivElement | null>;
    model: SequenceFeatureDetailsModel;
    mode: SequenceDisplayMode;
    assemblyGeneticCodeId?: number;
    onForceLoad: () => void;
}): import("react").JSX.Element;
