import type { FileLocation } from '../../util/types/index.ts';
declare const UrlChooser: ({ location, label, style, setLocation, }: {
    location?: FileLocation;
    label?: string;
    style?: Record<string, unknown>;
    setLocation: (arg: FileLocation) => void;
}) => import("react").JSX.Element;
export default UrlChooser;
