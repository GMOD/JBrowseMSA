export interface SpringAnimateOptions {
    from: number;
    to: number;
    /** applies one frame's value */
    write: (value: number) => void;
    /**
     * The live value `write` drives. Supply it when that value is shared with
     * anything else that can move it, and the spring stops as soon as it reads
     * back something other than what it last wrote — an interrupted animation
     * yields instead of overwriting the interruption on its next frame. Omit it for
     * a value only this spring touches.
     */
    read?: () => number;
    onFinish?: () => void;
    precision?: number;
    tension?: number;
    friction?: number;
    clamp?: boolean;
}
export declare function springAnimate({ from, to, write, read, onFinish, precision, tension, friction, clamp, }: SpringAnimateOptions): readonly [() => void, () => void];
