import type { SimpleFeatureSerialized } from '../../../util/index.ts';
import type { SequenceFeatureDetailsModel } from '../model.ts';
declare const GenomicSequence: ({ sequence, upstream, feature, downstream, model, }: {
    sequence: string;
    feature: SimpleFeatureSerialized;
    upstream?: string;
    downstream?: string;
    model: SequenceFeatureDetailsModel;
}) => import("react").JSX.Element;
export default GenomicSequence;
