/**
 * AES encrypt compatible with crypto-js OpenSSL format
 * Uses Web Crypto API when available, falls back to pure JS in non-secure contexts
 */
export declare function aesEncrypt(plaintext: string, password: string): Promise<string>;
/**
 * AES decrypt compatible with crypto-js OpenSSL format
 * Uses Web Crypto API when available, falls back to pure JS in non-secure contexts
 */
export declare function aesDecrypt(ciphertext: string, password: string): Promise<string>;
/**
 * SHA256 hash
 * Uses Web Crypto API when available, falls back to pure JS in non-secure contexts
 */
export declare function sha256(data: string): Promise<Uint8Array>;
/**
 * Base64 encode a Uint8Array
 */
export declare function toBase64(data: Uint8Array): string;
/**
 * URL-safe Base64 encode (for OAuth PKCE)
 */
export declare function toBase64Url(data: Uint8Array): string;
/**
 * SHA256 hash and return as Base64 (for OAuth PKCE code challenge)
 */
export declare function sha256Base64(data: string): Promise<string>;
/**
 * SHA256 hash and return as URL-safe Base64 (for OAuth PKCE code challenge)
 */
export declare function sha256Base64Url(data: string): Promise<string>;
