export type StopToken = string | SharedArrayBuffer;
export declare const hasSharedArrayBuffer: boolean;
export declare function createStopToken(): StopToken;
export declare function stopStopToken(stopToken?: StopToken): void;
export declare function checkStopToken(stopToken: StopToken | undefined): void;
export interface StopTokenChecker {
    stopToken?: StopToken;
    sabView?: Int32Array;
    iters: number;
    time: number;
    checkIters: number;
    checkInterval: number;
    backoff: boolean;
}
export declare function createStopTokenChecker(stopToken: StopToken | undefined): StopTokenChecker;
export declare function checkStopToken2(checker?: StopTokenChecker): void;
export type LastStopTokenCheck = StopTokenChecker;
