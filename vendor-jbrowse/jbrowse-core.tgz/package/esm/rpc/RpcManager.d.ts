import type BaseRpcDriver from './BaseRpcDriver.ts';
import type PluginManager from '../PluginManager.ts';
import type { RpcArgs, RpcMethodName, RpcReturn } from './RpcRegistry.ts';
import type { AnyConfigurationModel } from '../configuration/index.ts';
export type RpcDriverFactory = (config: AnyConfigurationModel, pluginManager: PluginManager) => BaseRpcDriver;
type RpcCallArgs<M extends string> = M extends RpcMethodName ? Omit<RpcArgs<M & RpcMethodName>, 'sessionId'> : Record<string, unknown>;
type RpcCallReturn<M extends string> = M extends RpcMethodName ? RpcReturn<M & RpcMethodName> : unknown;
export interface RpcManagerOptions {
    makeWorkerInstance?: () => Worker;
    defaultDriverName?: string;
}
export default class RpcManager {
    static configSchema: import("../configuration/configurationSchema.ts").ConfigurationSchemaType<{
        defaultDriver: {
            type: string;
            description: string;
            defaultValue: string;
            advanced: true;
        };
        workerCount: {
            type: string;
            description: string;
            defaultValue: number;
            advanced: true;
        };
    }, import("../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
    pluginManager: PluginManager;
    mainConfiguration: AnyConfigurationModel;
    defaultDriverName: string;
    driverObjects: Map<string, BaseRpcDriver>;
    driverFactories: Map<string, RpcDriverFactory>;
    constructor(pluginManager: PluginManager, mainConfiguration: AnyConfigurationModel, { makeWorkerInstance, defaultDriverName, }?: RpcManagerOptions);
    registerDriverFactory(name: string, factory: RpcDriverFactory): void;
    getDriver(backendName: string): BaseRpcDriver;
    private getDriverForCall;
    call<M extends string>(sessionId: string, functionName: M, args: RpcCallArgs<M>, opts?: {
        rpcDriverName?: string;
    } & Record<string, unknown>): Promise<RpcCallReturn<M>>;
    private withAuthRetry;
    private ensureAuthForOrigin;
    private freeSessionOnAllDrivers;
    destroy(): void;
}
export {};
