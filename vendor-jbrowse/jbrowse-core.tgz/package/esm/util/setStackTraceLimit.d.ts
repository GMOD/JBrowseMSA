declare global {
    interface ErrorConstructor {
        stackTraceLimit: number;
    }
}
export declare function setStackTraceLimit(): void;
