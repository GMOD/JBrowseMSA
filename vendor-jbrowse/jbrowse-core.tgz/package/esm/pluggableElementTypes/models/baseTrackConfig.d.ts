import type PluginManager from '../../PluginManager.ts';
import type { Instance } from '@jbrowse/mobx-state-tree';
/**
 * Snapshot normalization shared by every track config schema (including
 * ReferenceSequenceTrack). Runs the `Core-preProcessTrackConfig` extension
 * point, expands the `displayDefaults` shorthand, auto-fills a stub display for
 * each of the track type's registered displays, normalizes legacy display-type
 * aliases to their canonical name, dedupes by type (first wins), and lifts
 * legacy renderer configs.
 */
export declare function preprocessTrackConfigSnapshot(pluginManager: PluginManager, snapshot: Record<string, unknown>): {
    trackId: string;
    name: string;
    type: string;
    displays: {
        type: string;
        featureHeight?: {} | null | undefined;
        displayId: string;
    }[];
};
/**
 * The `addDisplayConf` action shared by every track config schema — appends a
 * display config unless one with the same displayId already exists.
 */
interface DisplayConf {
    type: string;
    displayId: string;
}
export declare function trackConfigActions(self: unknown): {
    addDisplayConf(conf: DisplayConf): DisplayConf | undefined;
};
/**
 * #config BaseTrack
 * Configuration shared by all track types. Concrete tracks (FeatureTrack,
 * AlignmentsTrack, VariantTrack, ...) extend this, so every track accepts these
 * fields in addition to its own.
 */
export declare function createBaseTrackConfig(pluginManager: PluginManager): import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
    /**
     * #slot
     */
    readonly name: {
        readonly description: "descriptive name of the track, falls back to the trackId when unset";
        readonly type: "string";
        readonly defaultValue: "";
    };
    /**
     * #slot
     */
    readonly assemblyNames: {
        readonly description: "name of the assembly (or assemblies) track belongs to";
        readonly type: "stringArray";
        readonly defaultValue: readonly ["assemblyName"];
    };
    /**
     * #slot
     */
    readonly description: {
        readonly description: "a description of the track";
        readonly type: "string";
        readonly defaultValue: "";
    };
    /**
     * #slot
     */
    readonly category: {
        readonly description: "the category and sub-categories of a track";
        readonly type: "stringArray";
        readonly defaultValue: readonly [];
    };
    /**
     * #slot
     */
    readonly metadata: {
        readonly type: "frozen";
        readonly description: "anything to add about this track";
        readonly defaultValue: {};
    };
    /**
     * #slot
     */
    readonly rpcDriverName: {
        readonly type: "string";
        readonly description: "RPC driver to use for this track. Leave empty to use the display-level or global default.";
        readonly defaultValue: "";
        readonly advanced: true;
    };
    /**
     * #slot
     */
    readonly adapter: import("@jbrowse/mobx-state-tree").IAnyModelType;
    readonly textSearching: import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
        /**
         * #slot textSearching.indexingAttributes
         */
        readonly indexingAttributes: {
            readonly type: "stringArray";
            readonly description: "list of which feature attributes to index for text searching";
            readonly defaultValue: readonly ["Name", "ID", "symbol"];
        };
        /**
         * #slot textSearching.indexingFeatureTypesToExclude
         */
        readonly indexingFeatureTypesToExclude: {
            readonly type: "stringArray";
            readonly description: "list of feature types to exclude in text search index";
            readonly defaultValue: readonly ["CDS", "exon"];
        };
        /**
         * #slot textSearching.textSearchAdapter
         */
        readonly textSearchAdapter: import("@jbrowse/mobx-state-tree").IAnyModelType;
    }, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
    /**
     * #slot
     * An **array** of full display configs, e.g.
     * `displays: [{ type: 'LinearBasicDisplay', color: 'green' }]`. Each entry
     * names a display `type`; use this when you need exact control — your own
     * `displayId`, different settings for two displays, or choosing which
     * display is the default.
     *
     * For the common case, prefer the `displayDefaults` shorthand instead — an
     * object of appearance settings (e.g. `displayDefaults: { color: 'green' }`)
     * that JBrowse routes to whichever display uses each setting, so you don't
     * have to name the display or write the array.
     *
     * See the [track config guide](/docs/config_guides/tracks/#configuring-displays).
     */
    readonly displays: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyModelType>;
    readonly formatDetails: import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
        /**
         * #slot formatDetails.feature
         */
        readonly feature: {
            readonly type: "frozen";
            readonly description: "adds extra fields to the feature details";
            readonly defaultValue: {};
            readonly contextVariable: ["feature"];
        };
        /**
         * #slot formatDetails.subfeatures
         */
        readonly subfeatures: {
            readonly type: "frozen";
            readonly description: "adds extra fields to the subfeatures of a feature";
            readonly defaultValue: {};
            readonly contextVariable: ["feature"];
        };
        /**
         * #slot formatDetails.depth
         */
        readonly depth: {
            readonly type: "number";
            readonly defaultValue: 2;
            readonly description: "depth of subfeatures to iterate the formatter on formatDetails.subfeatures (e.g. you may not want to format the exon/cds subfeatures, so limited to 2";
        };
        /**
         * #slot formatDetails.maxDepth
         */
        readonly maxDepth: {
            readonly type: "number";
            readonly defaultValue: 99999;
            readonly description: "Maximum depth to render subfeatures";
        };
    }, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
    readonly formatAbout: import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
        /**
         * #slot formatAbout.config
         */
        readonly config: {
            readonly type: "frozen";
            readonly description: "formats configuration object in about dialog";
            readonly defaultValue: {};
            readonly contextVariable: ["config"];
        };
        /**
         * #slot formatAbout.hideUris
         */
        readonly hideUris: {
            readonly type: "boolean";
            readonly defaultValue: false;
        };
    }, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
}, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, "trackId">>;
export type BaseTrackConfigSchema = ReturnType<typeof createBaseTrackConfig>;
export type BaseTrackConfig = Instance<BaseTrackConfigSchema>;
export {};
