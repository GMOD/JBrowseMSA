import type { AbstractSessionModel } from './types/index.ts';
export declare function fetchSeq({ start, end, refName, assemblyName, session, }: {
    start: number;
    end: number;
    refName: string;
    assemblyName: string;
    session: AbstractSessionModel;
}): Promise<string>;
