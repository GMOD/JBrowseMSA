import type React from 'react';
import { SvgCanvas } from './SvgCanvas.ts';
import type { SvgRasterCanvasOpts } from './createSvgRasterCanvas.ts';
export type Ctx2D = CanvasRenderingContext2D | SvgCanvas;
export type PaintLayerOpts = SvgRasterCanvasOpts & {
    rasterizeLayers?: boolean;
};
export declare function paintLayer(width: number, height: number, opts: PaintLayerOpts | undefined, paint: (ctx: Ctx2D) => void): React.ReactNode;
