import type { BpOffset } from './Base1DUtils.ts';
import type { Feature } from './simpleFeature.ts';
import type { Region as IRegion } from './types/index.ts';
import type { Instance } from '@jbrowse/mobx-state-tree';
declare const Base1DView: import("@jbrowse/mobx-state-tree").IModelType<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    displayedRegions: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IType<IRegion[], IRegion[], IRegion[]>, [undefined]>;
    bpPerPx: import("@jbrowse/mobx-state-tree").IType<number | undefined, number, number>;
    offsetPx: import("@jbrowse/mobx-state-tree").IType<number | undefined, number, number>;
    minimumBlockWidth: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<number>, [undefined]>;
}, {
    features: undefined | Feature[];
    volatileWidth: number;
} & {
    setDisplayedRegions(regions: IRegion[]): void;
    setBpPerPx(val: number): void;
    setVolatileWidth(width: number): void;
} & {
    readonly width: number;
    readonly assemblyNames: string[];
    readonly displayedRegionsTotalPx: number;
    readonly maxOffset: number;
    readonly minOffset: number;
    readonly totalBp: number;
} & {
    readonly dynamicBlocks: import("./blockTypes.ts").BlockSet;
    readonly staticBlocks: import("./blockTypes.ts").BlockSet;
    readonly currBp: number;
} & {
    pxToBp(px: number): {
        coord: number;
        index: number;
        refName: string;
        oob: boolean;
        assemblyName: string;
        offset: number;
        start: number;
        end: number;
        reversed?: boolean;
    };
    bpToPx({ refName, coord, displayedRegionIndex, }: {
        refName: string;
        coord: number;
        displayedRegionIndex?: number;
    }): number | undefined;
} & {
    setFeatures(features: Feature[]): void;
    showAllRegions(): void;
    zoomOut(): void;
    zoomIn(): void;
    zoomTo(bpPerPx: number, offset?: any): number;
    scrollTo(offsetPx: number): number;
    centerAt(coord: number, refName: string | undefined, displayedRegionIndex: number): void;
    scroll(distance: number): number;
} & {
    moveTo(start?: BpOffset, end?: BpOffset): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type Base1DViewStateModel = typeof Base1DView;
export type Base1DViewModel = Instance<Base1DViewStateModel>;
export default Base1DView;
