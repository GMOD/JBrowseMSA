/**
 * Structural equality: identity for primitives, recursive comparison for
 * arrays/objects. Key order doesn't matter, unlike a `JSON.stringify`
 * compare — which also can't tell `NaN` from `null` and silently drops
 * `undefined`-valued keys, so `{ a: 1, b: undefined }` and `{ a: 1 }` would
 * read as equal.
 */
export declare function deepEqual(a: unknown, b: unknown): boolean;
