import Plugin from './Plugin.ts';
import type PluginManager from './PluginManager.ts';
export default class CorePlugin extends Plugin {
    name: string;
    install(pluginManager: PluginManager): void;
}
