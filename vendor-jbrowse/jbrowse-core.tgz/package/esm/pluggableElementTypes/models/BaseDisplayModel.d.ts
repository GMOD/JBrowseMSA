import type React from 'react';
import type { MenuItem } from '../../ui/index.ts';
import type { RpcStatus } from '../../util/progress.ts';
import type { Instance } from '@jbrowse/mobx-state-tree';
export declare const BaseDisplay: import("@jbrowse/mobx-state-tree").IModelType<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
}, {
    error: unknown;
    statusMessage: string | undefined;
} & {
    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
    readonly parentDisplay: {
        type?: string;
        effectiveRpcDriverName?: string;
    } | undefined;
} & {
    readonly RenderingComponent: React.FC<{
        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
        }> & {
            error: unknown;
            statusMessage: string | undefined;
        } & {
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
            readonly parentDisplay: {
                type?: string;
                effectiveRpcDriverName?: string;
            } | undefined;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
        }, {
            error: unknown;
            statusMessage: string | undefined;
        } & {
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
            readonly parentDisplay: {
                type?: string;
                effectiveRpcDriverName?: string;
            } | undefined;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
        onHorizontalScroll?: () => void;
        blockState?: Record<string, unknown>;
    }>;
    readonly DisplayBlurb: React.FC<{
        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
        }> & {
            error: unknown;
            statusMessage: string | undefined;
        } & {
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
            readonly parentDisplay: {
                type?: string;
                effectiveRpcDriverName?: string;
            } | undefined;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
        }, {
            error: unknown;
            statusMessage: string | undefined;
        } & {
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
            readonly parentDisplay: {
                type?: string;
                effectiveRpcDriverName?: string;
            } | undefined;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
    }> | null;
    readonly adapterConfig: any;
    readonly isMinimized: boolean;
    readonly effectiveRpcDriverName: any;
    readonly effectiveTrackConfig: import("@jbrowse/mobx-state-tree").ModelSnapshotType<Record<string, any>>;
} & {
    renderProps(): {
        notReady: boolean;
        rpcDriverName: any;
    };
    renderingProps(): {
        displayModel: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
        }> & {
            error: unknown;
            statusMessage: string | undefined;
        } & {
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
            readonly parentDisplay: {
                type?: string;
                effectiveRpcDriverName?: string;
            } | undefined;
        } & {
            readonly RenderingComponent: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                } & {
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                } & {
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                onHorizontalScroll?: () => void;
                blockState?: Record<string, unknown>;
            }>;
            readonly DisplayBlurb: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                } & {
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                } & {
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
            }> | null;
            readonly adapterConfig: any;
            readonly isMinimized: boolean;
            readonly effectiveRpcDriverName: any;
            readonly effectiveTrackConfig: import("@jbrowse/mobx-state-tree").ModelSnapshotType<Record<string, any>>;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
        }, {
            error: unknown;
            statusMessage: string | undefined;
        } & {
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
            readonly parentDisplay: {
                type?: string;
                effectiveRpcDriverName?: string;
            } | undefined;
        } & {
            readonly RenderingComponent: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                } & {
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                } & {
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                onHorizontalScroll?: () => void;
                blockState?: Record<string, unknown>;
            }>;
            readonly DisplayBlurb: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                } & {
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                } & {
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
            }> | null;
            readonly adapterConfig: any;
            readonly isMinimized: boolean;
            readonly effectiveRpcDriverName: any;
            readonly effectiveTrackConfig: import("@jbrowse/mobx-state-tree").ModelSnapshotType<Record<string, any>>;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
    };
    readonly DisplayMessageComponent: undefined | React.FC<any>;
    trackMenuItems(): MenuItem[];
    readonly viewMenuActions: MenuItem[];
    regionCannotBeRendered(): null;
} & {
    setStatusMessage(arg?: RpcStatus): void;
    setError(error?: unknown): void;
    setRpcDriverName(rpcDriverName: string): void;
    reload(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type BaseDisplayStateModel = typeof BaseDisplay;
export type BaseDisplayModel = Instance<BaseDisplayStateModel>;
