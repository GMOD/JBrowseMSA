import type { AbstractSessionModel, SimpleFeatureSerialized } from '../../util/index.ts';
import type { SequenceFeatureDetailsModel, SequenceHoverTarget } from './model.ts';
interface SequenceFeatureDetailsProps {
    model: SequenceFeatureDetailsModel;
    session: AbstractSessionModel;
    assemblyName: string | undefined;
    feature: SimpleFeatureSerialized;
    hoverTarget?: SequenceHoverTarget;
    showOpenInDialog?: boolean;
}
declare function SequenceFeatureDetails(props: SequenceFeatureDetailsProps): import("react").JSX.Element;
export default SequenceFeatureDetails;
