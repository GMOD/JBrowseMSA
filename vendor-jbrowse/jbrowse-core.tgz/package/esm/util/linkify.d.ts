export declare function linkify(s: string): string;
