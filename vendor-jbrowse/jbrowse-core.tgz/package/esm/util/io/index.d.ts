import type PluginManager from '../../PluginManager.ts';
import type { FileLocation, UriLocation } from '../types/index.ts';
import type { Fetcher, GenericFilehandle } from 'generic-filehandle2';
export declare function resolveUriLocation(location: UriLocation): UriLocation;
export declare function openLocation(location: FileLocation, pluginManager?: PluginManager): GenericFilehandle;
export declare function openTabixIndexFilehandle(location: FileLocation, indexType: string | undefined, pluginManager?: PluginManager): {
    csiFilehandle: GenericFilehandle;
    tbiFilehandle?: undefined;
} | {
    csiFilehandle?: undefined;
    tbiFilehandle: GenericFilehandle;
};
export declare function getFetcher(location: FileLocation, pluginManager?: PluginManager): Fetcher;
export { RemoteFileWithRangeCache } from './RemoteFileWithRangeCache.ts';
