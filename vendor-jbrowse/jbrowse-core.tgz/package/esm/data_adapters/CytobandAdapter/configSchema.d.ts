declare const configSchema: import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
    cytobandLocation: {
        type: string;
        defaultValue: {
            uri: string;
        };
    };
}, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
export default configSchema;
