import type { TextFieldProps } from '@mui/material';
interface OwnProps {
    defaultValue?: number;
    onValueChange: (value: number | undefined) => void;
    min?: number;
    max?: number;
    errorText?: string;
}
type Props = Omit<TextFieldProps, 'value' | 'onChange' | 'type' | 'error'> & OwnProps & {
    helperText?: TextFieldProps['helperText'];
};
export default function NumberTextField(props: Props): import("react").JSX.Element;
export {};
