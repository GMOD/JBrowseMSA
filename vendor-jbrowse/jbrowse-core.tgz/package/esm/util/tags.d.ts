export declare const tagRegex: RegExp;
export declare function isValidTag(tag: string): boolean;
