import type { BpRegionBounds } from './renderBlock.ts';
export declare function splitPositionWithFrac(value: number): [number, number];
export interface BlockClipResult {
    scissorX: number;
    scissorW: number;
    pxX: number;
    pxW: number;
    pxH: number;
    bpStartHi: number;
    bpStartLo: number;
    bpEndHi: number;
    bpEndLo: number;
    clippedLengthBp: number;
    bpPerPx: number;
}
export declare function bpRangeXTuple(clip: BlockClipResult, reversed: boolean): [number, number, number];
export declare function writeBpRangeUniforms(uniformF32: Float32Array, offsetF32: number, clip: BlockClipResult, reversed: boolean): void;
export declare function clipBlock(block: BpRegionBounds, canvasWidth: number, canvasHeight: number, dpr: number): BlockClipResult | null;
