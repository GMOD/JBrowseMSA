export default function EndAdornment({ showHelp }: {
    showHelp?: boolean;
}): import("react").JSX.Element;
