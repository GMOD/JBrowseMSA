/**
 * Flagged rather than matched by message or `instanceof`, so the error UI can
 * offer the remedy specific to a loss (switch the page to Canvas2D) without
 * offering it for render errors whose remedy differs (an over-allocation says to
 * zoom in).
 */
export declare function createGpuContextLostError(): Error & {
    gpuContextLost: true;
};
export declare function isGpuContextLostError(error: unknown): error is object & Record<"gpuContextLost", unknown>;
/**
 * Duck-typed shape of an MST display model that owns a GPU backend
 * lifecycle via `RenderLifecycleMixin`. Plugins pass their own
 * model; the hook only touches these actions/fields.
 */
export interface RenderLifecycleModel<RenderingBackendType> {
    startRenderingBackend: (backend: RenderingBackendType) => void;
    stopRenderingBackend: () => void;
    renderNow: () => void;
    renderError: unknown;
    setRenderError: (error: unknown) => void;
}
/**
 * Drives the GPU/Canvas2D backend lifecycle for a display: canvas
 * initialization, context-loss / device-loss recovery, page-navigation
 * cleanup, and retry — wiring each event directly to the model's
 * `RenderLifecycleMixin` actions so the model (not React-local hook state)
 * owns every terminal state.
 *
 * The returned `canvasRef` is a callback ref — assign it directly to a
 * `<canvas ref={canvasRef} />`. React invokes it with the DOM node on mount
 * and with `null` on unmount, so the initialization effect re-runs when the
 * underlying canvas element is actually replaced (e.g. after regionTooLarge
 * unmounts then remounts the canvas).
 *
 * Lifecycle:
 *   1. Canvas mounts → init effect calls `factory(canvas)`; on success
 *      `setRenderError(undefined)` + `startRenderingBackend(backend)`, on
 *      failure `setRenderError(error)`.
 *   2. WebGL context loss → the browser gets one grace window to fire
 *      `webglcontextrestored` (which bumps `contextVersion` → rebuild, no user-
 *      visible state); if it doesn't, the loss is reported as `renderError`
 *      (`createGpuContextLostError`), which unmounts the canvas and so is what
 *      makes a fresh context obtainable at all. Bounded auto-recovery then
 *      clears it. WebGPU device loss bumps `contextVersion` directly.
 *   3. `retry()` clears `renderError` + bumps `contextVersion` so the next
 *      mount reinitializes.
 *
 * Page navigation fires `pagehide` on every mounted component, disposing its
 * backend AND clearing `model.currentRenderingBackend` (so the render/upload
 * autoruns no-op); React unmount disposes via the effect cleanup. A bfcache
 * restore fires `pageshow` with `persisted`, which rebuilds the backend for the
 * still-mounted canvas. No global tracking.
 *
 * The model argument is duck-typed to the slot mixin's contract — the listed
 * actions/fields are all the hook touches.
 */
export declare function useRenderingBackend<RenderingBackendType extends {
    dispose(): void;
    setErrorHandler?: (handler: (error: Error) => void) => void;
}>(factory: (canvas: HTMLCanvasElement) => Promise<RenderingBackendType>, model: RenderLifecycleModel<RenderingBackendType>): {
    canvas: HTMLCanvasElement | null;
    canvasRef: (node: HTMLCanvasElement | null) => void;
    error: unknown;
    retry: () => void;
    canvasKey: number;
};
