export default class NonError extends Error {
    value: unknown;
    constructor(value: unknown);
    static isNonError(value: unknown): value is NonError;
    static [Symbol.hasInstance](instance: unknown): instance is NonError;
}
