export declare function stripAlpha(str: string): string;
export declare function getStrokeProps(str: string): {
    [x: string]: string | number;
};
export declare function getFillProps(str: string): {
    [x: string]: string | number;
};
