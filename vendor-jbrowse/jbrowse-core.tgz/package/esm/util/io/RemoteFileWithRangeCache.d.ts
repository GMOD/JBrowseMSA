import { RemoteFile } from 'generic-filehandle2';
export declare function clearCache(): void;
export declare class RemoteFileWithRangeCache extends RemoteFile {
    stat(): Promise<{
        size: number;
    }>;
    private fetchRange;
    /**
     * Fetch one contiguous run of missing chunks as a single range request, and
     * publish a promise for each of its chunks. Publication is synchronous —
     * before the request is awaited — so a read planned while this is in flight
     * awaits these chunks instead of asking for the same bytes again.
     */
    private fetchRun;
    /**
     * Await a chunk fetch another read already had in flight, and re-issue it if
     * that read was canceled out from under us.
     *
     * Sharing one fetch between reads is what makes a row of adjacent genomic
     * blocks cheap, but it also means another reader's `AbortSignal` can reject a
     * chunk this read still needs — a failure that says nothing about this read.
     * Our own abort, and every other error, propagates untouched. `@gmod/bam`
     * applies the same retry to its own chunk cache one layer up.
     *
     * Retried exactly once, then propagated: the re-issue prefers the cache or a
     * live sibling, and bounding it means the pathological case is one duplicate
     * 256 KiB fetch *per joined chunk* — this runs once per chunk, so a read that
     * joined N chunks of a cancelled owner can re-issue N of them — rather than a
     * recursion whose depth depends on how the aborts interleave.
     */
    private joinChunk;
    private getCachedRange;
    fetch(url: string | RequestInfo, init?: RequestInit): Promise<Response>;
}
