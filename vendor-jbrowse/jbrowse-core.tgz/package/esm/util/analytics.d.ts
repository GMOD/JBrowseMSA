import type { AnyConfigurationModel } from '../configuration/index.ts';
type TrackConfig = AnyConfigurationModel & {
    type: string;
};
interface AnalyticsRootModel {
    jbrowse: {
        tracks: TrackConfig[];
        assemblies: unknown[];
        plugins?: {
            name?: string;
        }[];
        configuration: AnyConfigurationModel;
    };
    session?: {
        sessionTracks: TrackConfig[];
        views: unknown[];
    };
    version: string;
}
export declare function writeAWSAnalytics(rootModel: AnalyticsRootModel, initialTimestamp: number, sessionQuery?: string | null): Promise<void>;
export declare function writeGAAnalytics(rootModel: AnalyticsRootModel, initialTimestamp: number): Promise<void>;
export declare function doAnalytics(rootModel: AnalyticsRootModel | undefined, initialTimestamp: number, initialSessionQuery: string | null | undefined): void;
export {};
