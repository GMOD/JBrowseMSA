import PluggableElementBase from './PluggableElementBase.ts';
import type DisplayType from './DisplayType.ts';
import type { IAnyModelType, IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
import type React from 'react';
type BasicView = React.ComponentType<{
    model: any;
    session?: IAnyStateTreeNode;
}>;
type ViewComponentType = React.LazyExoticComponent<BasicView> | BasicView;
interface ViewMetadata {
    hiddenFromGUI?: boolean;
}
export default class ViewType extends PluggableElementBase {
    ReactComponent: ViewComponentType;
    stateModel: IAnyModelType;
    displayTypes: DisplayType[];
    viewMetadata: ViewMetadata;
    extendedName?: string;
    constructor(stuff: {
        name: string;
        displayName?: string;
        stateModel: IAnyModelType;
        extendedName?: string;
        viewMetadata?: ViewMetadata;
        ReactComponent: ViewComponentType;
    });
    addDisplayType(display: DisplayType): void;
}
export {};
