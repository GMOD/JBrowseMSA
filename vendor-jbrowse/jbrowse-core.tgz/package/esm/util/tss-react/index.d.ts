import type { CxArg } from './tools/classnames.ts';
export { keyframes } from '@emotion/react';
export { makeStyles } from './mui/index.ts';
export declare function cx(...args: CxArg[]): string;
