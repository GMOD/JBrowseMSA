import RpcMethodType from './RpcMethodType.ts';
import type { RenameRegionsArgs } from './RpcMethodType.ts';
export default abstract class RpcMethodTypeWithRenameRegions extends RpcMethodType {
    serializeArguments<T extends RenameRegionsArgs>(args: T, rpcDriverClassName: string): Promise<Record<string, unknown>>;
}
