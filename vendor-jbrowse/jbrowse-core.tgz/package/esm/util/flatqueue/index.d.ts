export default class FlatQueue<T> {
    ids: T[];
    values: number[];
    length: number;
    clear(): void;
    push(item: T, priority: number): void;
    pop(): T | undefined;
    peek(): T | undefined;
    peekValue(): number | undefined;
    shrink(): void;
}
