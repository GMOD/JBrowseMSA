export default function SequenceLegend({ items, }: {
    items: {
        color: string;
        label: string;
    }[];
}): import("react").JSX.Element;
