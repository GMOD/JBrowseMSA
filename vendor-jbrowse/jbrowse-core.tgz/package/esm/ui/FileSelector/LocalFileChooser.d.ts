declare global {
    interface Window {
        showOpenFilePicker(): Promise<FileSystemFileHandle[]>;
    }
}
import type { FileLocation } from '../../util/types/index.ts';
declare const LocalFileChooser: ({ location, setLocation, }: {
    location?: FileLocation;
    setLocation: (arg: FileLocation) => void;
}) => import("react").JSX.Element;
export default LocalFileChooser;
