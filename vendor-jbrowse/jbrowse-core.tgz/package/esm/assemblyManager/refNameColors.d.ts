export declare const defaultRefNameColors: string[];
