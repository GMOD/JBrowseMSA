export declare function useExportSvgPreference<T>(key: string, val: T): readonly [T, (value: T | ((val: T) => T)) => void];
