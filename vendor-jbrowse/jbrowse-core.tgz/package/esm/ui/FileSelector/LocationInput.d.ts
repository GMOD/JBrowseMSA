import type { BaseInternetAccountModel } from '../../pluggableElementTypes/index.ts';
import type { FileLocation } from '../../util/types/index.ts';
export default function LocationInput({ toggleButtonValue, selectedAccount, location, inline, setLocation, }: {
    toggleButtonValue: string;
    selectedAccount?: BaseInternetAccountModel;
    location?: FileLocation;
    inline?: boolean;
    setLocation: (arg: FileLocation) => void;
}): import("react").JSX.Element | null;
