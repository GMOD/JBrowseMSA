import type { Instance } from '@jbrowse/mobx-state-tree';
export type ShowCoordinatesMode = 'none' | 'relative' | 'genomic';
export type SequenceDisplayMode = 'gene' | 'gene_collapsed_intron' | 'gene_updownstream' | 'gene_updownstream_collapsed_intron' | 'cdna' | 'cds' | 'genomic' | 'genomic_sequence_updownstream' | 'protein';
export declare function SequenceFeatureDetailsF(): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    showCoordinatesSetting: ShowCoordinatesMode;
    intronBp: number;
    upDownBp: number;
    upperCaseCDS: boolean;
    charactersPerRow: number;
} & {
    setUpDownBp(f: number): void;
    setIntronBp(f: number): void;
    setUpperCaseCDS(f: boolean): void;
    setShowCoordinates(f: ShowCoordinatesMode): void;
} & {
    readonly showCoordinates: boolean;
} & {
    afterCreate(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type SequenceFeatureDetailsStateModel = ReturnType<typeof SequenceFeatureDetailsF>;
export type SequenceFeatureDetailsModel = Instance<SequenceFeatureDetailsStateModel>;
