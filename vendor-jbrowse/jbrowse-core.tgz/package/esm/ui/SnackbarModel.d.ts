import type { NotificationLevel, SnackAction } from '../util/types/index.ts';
export interface SnackbarMessage {
    message: string;
    level?: NotificationLevel;
    actions?: SnackAction[];
}
export interface ErrorDialogState {
    error: unknown;
    extra?: unknown;
}
/**
 * #stateModel SnackbarModel
 * #category session
 */
export default function SnackbarModel(): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    /**
     * #volatile
     */
    snackbarMessages: import("mobx").IObservableArray<SnackbarMessage>;
    /**
     * #volatile
     * the error currently shown in the stack-trace dialog. Kept off the
     * dialog queue so it can stack on top of an already-open dialog (e.g. the
     * one whose action raised the error) instead of waiting behind it
     */
    errorDialog: ErrorDialogState | undefined;
} & {
    /**
     * #getter
     */
    readonly snackbarMessageSet: Map<string, SnackbarMessage>;
} & {
    /**
     * #action
     */
    notify(message: string, level?: NotificationLevel, action?: SnackAction | SnackAction[]): void;
    /**
     * #action
     */
    notifyError(errorMessage: string, error?: unknown, extra?: unknown, action?: SnackAction): void;
    /**
     * #action
     */
    setErrorDialog(state: ErrorDialogState | undefined): void;
    /**
     * #action
     */
    pushSnackbarMessage(message: string, level?: NotificationLevel, actions?: SnackAction[]): void;
    /**
     * #action
     */
    popSnackbarMessage(): SnackbarMessage | undefined;
    /**
     * #action
     */
    removeSnackbarMessage(message: string): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
