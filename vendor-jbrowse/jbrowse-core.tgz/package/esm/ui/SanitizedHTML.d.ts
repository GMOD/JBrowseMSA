declare global {
    interface Element {
        setHTML?(html: string): void;
    }
}
export default function SanitizedHTML({ html: pre, className, }: {
    className?: string;
    html: unknown;
}): import("react").JSX.Element;
