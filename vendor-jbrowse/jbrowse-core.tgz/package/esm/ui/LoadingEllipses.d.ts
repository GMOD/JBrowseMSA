import type { TypographyProps } from '@mui/material';
interface Props extends TypographyProps {
    message?: string;
    children?: never;
}
export default function LoadingEllipses({ message, variant, ...rest }: Props): import("react").JSX.Element;
export {};
