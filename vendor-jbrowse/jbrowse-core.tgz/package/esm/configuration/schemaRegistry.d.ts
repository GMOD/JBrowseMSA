import type { ConfigurationSchemaDefinition, ConfigurationSchemaOptions } from './configurationSchema.ts';
import type { IAnyType } from '@jbrowse/mobx-state-tree';
export interface ConfigurationSchemaMetadata {
    /** the raw slot/sub-schema/constant table, also carrying per-slot editor metadata */
    definition: ConfigurationSchemaDefinition;
    /** construction options (identifier kind, baseConfiguration, etc.) */
    options: ConfigurationSchemaOptions<any, any>;
}
export declare function registerConfigurationSchema(type: IAnyType, metadata: ConfigurationSchemaMetadata): void;
export declare function getConfigurationSchemaMetadata(type: IAnyType): ConfigurationSchemaMetadata | undefined;
export declare function isRegisteredConfigurationSchema(type: IAnyType): boolean;
