export interface BaseResultArgs {
    label: string;
    displayString?: string;
    locString?: string;
    refName?: string;
    trackId?: string;
    results?: BaseResult[];
}
export default class BaseResult {
    label: string;
    displayString?: string;
    trackId?: string;
    locString?: string;
    results?: BaseResult[];
    constructor(args: BaseResultArgs);
    getLabel(): string;
    getDisplayString(): string;
    getTrackId(): string | undefined;
    getId(): string;
    hasLocation(): boolean;
    getLocation(): string | undefined;
}
export declare class RefSequenceResult extends BaseResult {
    constructor(args: BaseResultArgs);
}
