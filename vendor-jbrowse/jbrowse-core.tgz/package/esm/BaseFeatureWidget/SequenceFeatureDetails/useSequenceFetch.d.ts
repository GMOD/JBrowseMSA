import type { SimpleFeatureSerialized } from '../../util/index.ts';
import type { BaseFeatureWidgetModel } from '../stateModelFactory.ts';
export declare function useSequenceFetch({ model, feature, upDownBp, }: {
    model: BaseFeatureWidgetModel;
    feature: SimpleFeatureSerialized;
    upDownBp: number;
}): {
    sequence: {
        error: string;
        seq?: undefined;
        upstream?: undefined;
        downstream?: undefined;
    } | {
        error?: undefined;
        seq: string;
        upstream: string;
        downstream: string;
    } | undefined;
    error: unknown;
    assemblyGeneticCodeId: number | undefined;
    onForceLoad: () => void;
};
