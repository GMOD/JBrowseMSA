export default function idMaker(args: Record<string, unknown>): string;
