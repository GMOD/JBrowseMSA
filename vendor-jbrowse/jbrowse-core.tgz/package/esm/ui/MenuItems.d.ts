export declare function MenuItemEndDecoration({ type, checked, disabled, }: {
    type: 'checkbox' | 'radio';
    checked: boolean;
    disabled?: boolean;
}): import("react").JSX.Element;
export declare function LoadingMenuItem(): import("react").JSX.Element;
export declare function ErrorMenuItem({ error }: {
    error: unknown;
}): import("react").JSX.Element;
