import type { BaseAdapter } from './BaseAdapter.ts';
import type { BaseFeatureDataAdapter } from './BaseFeatureDataAdapter.ts';
import type { BaseRefNameAliasAdapter } from './BaseRefNameAliasAdapter.ts';
import type { BaseSequenceAdapter } from './BaseSequenceAdapter.ts';
import type { BaseTextSearchAdapter } from './BaseTextSearchAdapter.ts';
import type { RegionsAdapter } from './RegionsAdapter.ts';
export type AnyDataAdapter = BaseAdapter | BaseFeatureDataAdapter | BaseRefNameAliasAdapter | BaseTextSearchAdapter | RegionsAdapter | BaseSequenceAdapter;
export interface RefNameSource {
    getRefNames(opts?: Record<string, unknown>): Promise<string[]>;
}
export declare function isRegionsAdapter(t: AnyDataAdapter): t is RegionsAdapter;
export declare function isFeatureAdapter(t: AnyDataAdapter): t is BaseFeatureDataAdapter;
export declare function isRefNameSource(t: AnyDataAdapter): t is AnyDataAdapter & RefNameSource;
export declare function isSequenceAdapter(t: AnyDataAdapter): t is BaseSequenceAdapter;
export declare function isRefNameAliasAdapter(t: object): t is BaseRefNameAliasAdapter;
export declare function isTextSearchAdapter(t: AnyDataAdapter): t is BaseTextSearchAdapter;
