import type { CSSObject } from './types.ts';
export declare function createMakeStyles<Theme>(params: {
    useTheme: () => Theme;
}): {
    makeStyles: () => <RuleName extends string>(cssObjectByRuleNameOrGetCssObjectByRuleName: ((theme: Theme) => Record<RuleName, CSSObject>) | Record<RuleName, CSSObject>) => (_params?: unknown, muiStyleOverridesParams?: {
        props: {
            classes?: Record<string, string>;
        };
    }) => {
        classes: Record<RuleName, string>;
        theme: Theme;
        css: import("./types.ts").Css;
        cx: import("./types.ts").Cx;
    };
};
