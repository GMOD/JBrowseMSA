import type { Fetcher, Key, SWRConfiguration, SWRResponse } from 'swr';
export declare function useFetch<Data = unknown, Err = unknown, K extends Key = Key>(key: K, fetcher: Fetcher<Data, K> | null, options?: SWRConfiguration<Data, Err>): SWRResponse<Data, Err>;
