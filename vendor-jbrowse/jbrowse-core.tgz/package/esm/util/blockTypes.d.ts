export declare function makeDisplayedRegionKey(r: {
    assemblyName: string;
    refName: string;
    start: number;
    end: number;
    reversed?: boolean;
}): string;
interface BlockData {
    key: string;
    offsetPx: number;
    widthPx: number;
    assemblyName?: string;
    refName?: string;
    start?: number;
    end?: number;
    reversed?: boolean;
    displayedRegionIndex?: number;
    isLeftEndOfDisplayedRegion?: boolean;
    isRightEndOfDisplayedRegion?: boolean;
    variant?: 'boundary';
}
export interface ContentBlock extends BlockData {
    type: 'ContentBlock';
    assemblyName: string;
    refName: string;
    start: number;
    end: number;
}
export interface ElidedBlock extends BlockData {
    type: 'ElidedBlock';
    elidedBlockCount: number;
}
export interface InterRegionPaddingBlock extends BlockData {
    type: 'InterRegionPaddingBlock';
}
export type BaseBlock = ContentBlock | ElidedBlock | InterRegionPaddingBlock;
export declare function makeContentBlock(data: Omit<ContentBlock, 'type'>): ContentBlock;
export declare function makeElidedBlock(data: Omit<ElidedBlock, 'type' | 'elidedBlockCount'>): ElidedBlock;
export declare function makeInterRegionPaddingBlock(data: Omit<InterRegionPaddingBlock, 'type'>): InterRegionPaddingBlock;
export declare function blockToRegion(b: ContentBlock): {
    refName: string;
    start: number;
    end: number;
    assemblyName: string;
    reversed: boolean | undefined;
};
type Func<T> = (value: BaseBlock, index: number, array: BaseBlock[]) => T;
export declare class BlockSet {
    blocks: BaseBlock[];
    constructor(blocks?: BaseBlock[]);
    push(block: BaseBlock): void;
    map<T, U = this>(func: Func<T>, thisarg?: U): T[];
    forEach<T, U = this>(func: Func<T>, thisarg?: U): void;
    get length(): number;
    get totalWidthPx(): number;
    get totalWidthPxWithoutBorders(): number;
    get offsetPx(): number;
    get contentBlocks(): ContentBlock[];
    get totalBp(): number;
}
export {};
