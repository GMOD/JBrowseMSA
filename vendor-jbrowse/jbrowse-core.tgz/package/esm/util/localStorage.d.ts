export declare function localStorageGetItem(item: string): string | null | undefined;
export declare function localStorageSetItem(str: string, item: string): void;
export declare function localStorageGetNumber(key: string, defaultVal: number): number;
export declare function localStorageGetBoolean(key: string, defaultVal: boolean): boolean;
export declare function localStorageSetBoolean(key: string, value: boolean): void;
export declare function localStorageSetNumber(key: string, value: number): void;
