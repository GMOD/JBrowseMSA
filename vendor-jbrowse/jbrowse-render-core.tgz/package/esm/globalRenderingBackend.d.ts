import { Canvas2DRenderingBackendBase, GpuRenderingBackendBase } from './renderingBackendBase.ts';
export interface GlobalRenderingBackend<UploadData, RenderState> {
    uploadData(data: UploadData): void;
    render(data: UploadData | null, state: RenderState): void;
    dispose(): void;
}
export declare abstract class Canvas2DGlobalRenderingBackend<UploadData, RenderState> extends Canvas2DRenderingBackendBase implements GlobalRenderingBackend<UploadData, RenderState> {
    uploadData(): void;
    abstract render(data: UploadData | null, state: RenderState): void;
}
export declare abstract class GpuGlobalRenderingBackend<UploadData, RenderState> extends GpuRenderingBackendBase implements GlobalRenderingBackend<UploadData, RenderState> {
    abstract uploadData(data: UploadData): void;
    abstract render(data: UploadData | null, state: RenderState): void;
}
