export declare function b64PadSuffix(b64: string): string;
/**
 * Decode and inflate a url-safe base64 to a string
 * See {@link https://en.wikipedia.org/wiki/Base64#URL_applications}
 */
export declare function fromUrlSafeB64(b64: string): Promise<string>;
/**
 * Compress and encode a string as url-safe base64
 * See {@link https://en.wikipedia.org/wiki/Base64#URL_applications}
 */
export declare function toUrlSafeB64(str: string): Promise<string>;
export type SessionShareMode = 'short' | 'long' | 'json';
export interface EncodedSessionParam {
    sessionParam: string;
    password?: string;
    plaintext?: string;
}
export declare function encodeSessionParam(mode: SessionShareMode, session: unknown, options: {
    shareURL: string;
    referer: string;
}): Promise<EncodedSessionParam>;
export declare function readSessionFromDynamo(baseUrl: string, sessionQueryParam: string, password: string, signal?: AbortSignal): Promise<string>;
