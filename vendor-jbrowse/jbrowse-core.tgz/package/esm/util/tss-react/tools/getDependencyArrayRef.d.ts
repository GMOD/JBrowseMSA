export declare function getDependencyArrayRef(obj: any): any;
