import { type LazyExoticComponent } from 'react';
export declare const Entries: Record<string, LazyExoticComponent<any>>;
