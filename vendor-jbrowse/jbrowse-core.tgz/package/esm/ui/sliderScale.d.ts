export type SliderScale = 'linear' | 'log' | 'cubic';
export declare function sliderScale(scale: SliderScale): {
    toSlider: (n: number) => number;
    fromSlider: (v: number) => number;
    sliderStep: number | undefined;
};
