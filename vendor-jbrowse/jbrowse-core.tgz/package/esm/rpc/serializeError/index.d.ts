export interface ErrorObject {
    name?: string;
    message: string;
    stack?: string;
    code?: string;
    cause?: unknown;
}
export declare function isErrorLike(value: unknown): value is Error;
export declare function serializeError(value: unknown, options?: {
    maxDepth?: number;
    useToJSON?: boolean;
}): ErrorObject;
export declare function deserializeError(value: unknown, options?: {
    maxDepth?: number;
}): Error;
