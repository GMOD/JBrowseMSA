import type { Alias } from '../data_adapters/BaseAdapter/index.ts';
export type RefNameAliases = Record<string, string>;
export declare function checkRefName(refName: string): void;
export interface RefNameMaps {
    refNameAliases: RefNameAliases;
    lowerCaseRefNameAliases: RefNameAliases;
    canonicalToSeqAdapterRefNames: Record<string, string>;
}
export declare function buildRefNameMaps(regions: {
    refName: string;
}[], refNameAliasCollection: Alias[]): RefNameMaps;
