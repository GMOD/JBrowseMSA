export interface GraphicsCapabilities {
    webgpu: boolean;
    webgl2: boolean;
    gpuVendor?: string;
    gpuArchitecture?: string;
}
export declare function getGraphicsCapabilities(): Promise<GraphicsCapabilities>;
export declare function preferredRenderer(c: GraphicsCapabilities): "Canvas2D" | "WebGL2" | "WebGPU";
export declare function availableRenderers(c: GraphicsCapabilities): string[];
