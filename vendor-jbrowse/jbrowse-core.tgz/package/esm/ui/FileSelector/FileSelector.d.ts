import type { AbstractRootModel, FileLocation } from '../../util/types/index.ts';
declare const FileSelector: ({ inline, location, name, description, rootModel, setLocation, }: {
    location?: FileLocation;
    name?: string;
    description?: string;
    inline?: boolean;
    rootModel?: AbstractRootModel;
    setLocation: (param: FileLocation) => void;
}) => import("react").JSX.Element;
export default FileSelector;
