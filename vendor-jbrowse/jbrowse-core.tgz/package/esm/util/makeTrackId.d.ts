export declare function makeTrackId({ name, adminMode, timestamp, index, }: {
    name: string;
    adminMode: boolean;
    timestamp?: number;
    index?: number;
}): string;
