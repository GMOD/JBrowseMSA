export default function FieldName({ description, name, width, prefix, }: {
    description?: React.ReactNode;
    name: string;
    prefix?: string[];
    width?: number;
}): import("react").JSX.Element;
