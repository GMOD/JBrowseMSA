export interface StackFrame {
    name: string;
    uri: string;
    line: number;
    column: number;
}
export declare function parseStackLine(line: string): StackFrame | undefined;
export declare function mapStackTrace(stack: string): Promise<string>;
