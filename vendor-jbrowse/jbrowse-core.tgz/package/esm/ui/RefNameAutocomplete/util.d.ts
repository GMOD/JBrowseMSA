import BaseResult from '../../TextSearch/BaseResults.ts';
export interface Option {
    isLimit?: boolean;
    result: BaseResult;
}
export declare function cap(options: Option[]): Option[];
export declare function getFiltered(options: Option[], inputValue: string): Option[];
export declare function getDeduplicatedResult(results: BaseResult[]): Option[];
export declare function coerceToResult(option: string | Option): BaseResult;
export declare function getOptionLabel(option: string | Option): string;
export declare function getInputWidth(value: string, minWidth: number, maxWidth: number): number;
