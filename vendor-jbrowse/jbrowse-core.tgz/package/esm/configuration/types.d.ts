import type { ConfigurationSchemaOptions, ConfigurationSchemaType } from './configurationSchema.ts';
import type ConfigSlot from './configurationSlot.ts';
import type { ISimpleType, IStateTreeNode, Instance, SnapshotOut } from '@jbrowse/mobx-state-tree';
export type GetOptions<SCHEMA> = SCHEMA extends ConfigurationSchemaType<any, infer OPTIONS> ? OPTIONS : never;
export type GetBase<SCHEMA> = SCHEMA extends undefined ? never : GetOptions<SCHEMA> extends ConfigurationSchemaOptions<undefined, any> ? undefined : GetOptions<SCHEMA> extends ConfigurationSchemaOptions<infer BASE extends AnyConfigurationSchemaType, any> ? BASE : never;
export type GetExplicitIdentifier<SCHEMA> = GetOptions<SCHEMA> extends ConfigurationSchemaOptions<any, infer EXPLICIT_IDENTIFIER extends string> ? EXPLICIT_IDENTIFIER : never;
export type ConfigurationSchemaForModel<MODEL> = MODEL extends IStateTreeNode<infer SCHEMA extends AnyConfigurationSchemaType> ? SCHEMA : never;
export type ConfigurationSlotName<SCHEMA> = SCHEMA extends undefined ? never : SCHEMA extends ConfigurationSchemaType<infer D, any> ? (keyof D & string) | GetExplicitIdentifier<SCHEMA> | (GetBase<SCHEMA> extends ConfigurationSchemaType<any, any> ? ConfigurationSlotName<GetBase<SCHEMA>> : never) : never;
type SlotValueFromDef<DEF> = DEF extends {
    model: ISimpleType<infer T extends string>;
} ? T : DEF extends {
    defaultValue: infer V;
} ? [V] extends [boolean] ? V : [V] extends [string] ? V : [V] extends [number] ? V : any : any;
export type ConfigurationSlotValue<SCHEMA, K extends string> = SCHEMA extends ConfigurationSchemaType<infer D, any> ? K extends keyof D ? SlotValueFromDef<D[K]> : GetBase<SCHEMA> extends ConfigurationSchemaType<any, any> ? ConfigurationSlotValue<GetBase<SCHEMA>, K> : any : any;
export type AnyConfigurationSchemaType = ConfigurationSchemaType<any, any>;
export type AnyConfigurationModel = Instance<AnyConfigurationSchemaType>;
export type AnyConfigurationSlotType = ReturnType<typeof ConfigSlot>;
export type AnyConfigurationSlot = Instance<AnyConfigurationSlotType>;
export type AnyConfiguration = AnyConfigurationModel | SnapshotOut<AnyConfigurationModel>;
export {};
