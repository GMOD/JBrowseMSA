declare const JexlFilterDialog: ({ filters, setFilters, handleClose, }: {
    filters?: string[];
    setFilters: (arg: string[]) => void;
    handleClose: () => void;
}) => import("react").JSX.Element;
export default JexlFilterDialog;
