import type { TrackConfigChange } from '../util/trackConfigDelta.ts';
/**
 * Shared three-column diff table (Setting / Default / Current) used by both the
 * per-track "changes" dialog and the global preferences-reset dialog, so the two
 * read identically. Each row is a `TrackConfigChange` — a dotted `path` and its
 * `from` (default) / `to` (current) values. Passing `onResetRow` adds a trailing
 * per-row revert button, letting the caller reset a single entry (the
 * preferences dialog uses this so a reset need not be all-or-nothing).
 */
declare const SettingsChangesTable: ({ changes, onResetRow, }: {
    changes: TrackConfigChange[];
    onResetRow?: (change: TrackConfigChange) => void;
}) => import("react").JSX.Element;
export default SettingsChangesTable;
