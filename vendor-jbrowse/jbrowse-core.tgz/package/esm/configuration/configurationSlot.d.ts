import type { IAnyType } from '@jbrowse/mobx-state-tree';
export interface ConfigSlotDefinition {
    description?: string;
    model?: IAnyType;
    type: string;
    defaultValue: unknown;
    contextVariable?: string[];
    advanced?: boolean;
}
export default function ConfigSlot({ model, type, defaultValue, }: ConfigSlotDefinition): import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ITypeUnion<any, any, any>, [undefined]>;
