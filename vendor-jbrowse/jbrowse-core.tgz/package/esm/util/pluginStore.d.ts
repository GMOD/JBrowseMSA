import type { PluginDefinition } from '../pluginDefinitions.ts';
import type { JBrowsePlugin } from './types/index.ts';
export interface ResolvedPlugin {
    compatible: boolean;
    pluginVersion?: string;
    supportedRanges: string[];
    definition: PluginDefinition | undefined;
}
export interface PluginUpdate {
    pluginVersion: string;
    name: string;
    definition: PluginDefinition;
}
export declare function resolvePlugin(plugin: JBrowsePlugin, jbrowseVersion: string): ResolvedPlugin;
export declare function installedVersionFromUrl(url: string | undefined, packageName: string | undefined): string | undefined;
/**
 * Whether a store entry is already among `installed`.
 *
 * Matched by packageName rather than by the resolved url wherever the store
 * publishes one: once a newer compatible version appears the resolved url
 * changes, and a url match would report "not installed" and let the user add a
 * second copy of the same plugin (same UMD global name) alongside the one
 * already there, which then fails to load with duplicate pluggable-element
 * registrations. Moving to a newer version is a separate, explicit action.
 */
export declare function isPluginInstalled(plugin: JBrowsePlugin, resolved: ResolvedPlugin, installed: PluginDefinition[]): boolean;
export declare function getPluginUpdate(plugin: JBrowsePlugin, jbrowseVersion: string, installedVersion: string | undefined): PluginUpdate | undefined;
