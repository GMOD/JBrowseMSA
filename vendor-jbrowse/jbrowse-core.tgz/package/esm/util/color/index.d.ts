/**
 * Darken or lighten a color, depending on its luminance.
 * Light colors are darkened, dark colors are lightened.
 * Uses MUI's `emphasize`, but adds support for named colors
 *
 * @param color - CSS color, i.e. one of: #nnn, #nnnnnn, rgb(), rgba(),
 * hsl(), hsla(), or named color
 * @param coefficient - multiplier in the range 0 - 1, defaults to 0.15
 * @returns A CSS color string. Hex input values are returned as rgb
 */
export declare function emphasize(color: string, coefficient?: number): string;
/**
 * Push `foreground` away from `background` until it clears `minContrastRatio`,
 * returning the closest it got when that ratio is unreachable.
 *
 * `minContrastRatio` genuinely cannot be met against a mid-luminance
 * background: lighten/darken clamp their coefficient at 1, so the candidate
 * pins at white/black, and against a `#b0b0b0` paper the best ratio any color
 * reaches is about 2.2. This used to be a `while (ratio < min)` loop with an
 * unbounded coefficient, which froze the render thread outright for 38 of the 40
 * default refName colors.
 */
export declare function makeContrasting(foreground: string, background?: string, minContrastRatio?: number): string;
export { isNamedColor, namedColorToHex } from './cssColorsLevel4.ts';
/**
 * Generate a consistent random color for a given string.
 * The same string will always generate the same color, with no shared palette
 * state — so the same value (e.g. a gene symbol used as an ortholog id) gets the
 * same color across independent tracks/panels.
 *
 * @param str - The string to generate a color from
 * @returns A CSS color string in HSL format
 */
export declare function randomColor(str: string): string;
