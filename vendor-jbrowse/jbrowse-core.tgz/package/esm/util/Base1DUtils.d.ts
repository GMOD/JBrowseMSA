import type { ContentBlock } from './blockTypes.ts';
export interface BpOffset {
    refName?: string;
    index: number;
    offset: number;
    start?: number;
    end?: number;
}
interface RegionSnap {
    start: number;
    end: number;
    refName: string;
    reversed?: boolean;
    assemblyName: string;
}
interface MoveSnap {
    displayedRegions: {
        start: number;
        end: number;
    }[];
    width: number;
}
export interface ViewLayout {
    displayedRegions: RegionSnap[];
    bpPerPx: number;
    offsetPx: number;
    width: number;
    minimumBlockWidth: number;
}
export declare function moveTo(self: MoveSnap & {
    zoomTo: (arg: number) => number;
    scrollTo: (arg: number) => void;
}, start?: BpOffset, end?: BpOffset): void;
export declare function computeMoveToLayout(self: MoveSnap, start: BpOffset, end: BpOffset): {
    bpPerPx: number;
    offsetPx: number;
};
export declare function pxToBp(self: ViewLayout, px: number): {
    coord: number;
    index: number;
    refName: string;
    oob: boolean;
    assemblyName: string;
    offset: number;
    start: number;
    end: number;
    reversed?: boolean;
};
export declare function offsetBpToPx(self: ViewLayout, regionIndex: number, regionOffsetBp: number): number;
export declare function bpToPx({ refName, coord, displayedRegionIndex, self, }: {
    refName: string;
    coord: number;
    displayedRegionIndex?: number;
    self: ViewLayout;
}): {
    index: number;
    offsetPx: number;
} | undefined;
export declare function layoutBpToPx(layout: ViewLayout, args: {
    refName: string;
    coord: number;
    displayedRegionIndex?: number;
}): number | undefined;
export declare function getLayoutHighlightCoords(layout: ViewLayout, region: {
    refName: string;
    start: number;
    end: number;
}, minWidth?: number): {
    width: number;
    left: number;
} | undefined;
export declare function createOverviewLayout({ displayedRegions, width, minimumBlockWidth, }: {
    displayedRegions: RegionSnap[];
    width: number;
    minimumBlockWidth?: number;
}): ViewLayout;
export declare function getContentBlocksPxSpan(layout: ViewLayout, contentBlocks: ContentBlock[]): {
    leftPx: number;
    rightPx: number;
} | undefined;
export {};
