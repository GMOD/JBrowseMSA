import type { BaseLayout, SerializedLayout } from './BaseLayout.ts';
export default class MultiLayout<SUB_LAYOUT_CLASS extends BaseLayout<T>, T> {
    subLayouts: Map<string, SUB_LAYOUT_CLASS>;
    SubLayoutClass: new (...args: any[]) => SUB_LAYOUT_CLASS;
    subLayoutConstructorArgs: Record<string, unknown>;
    /**
     * layout class that just keeps a number of named sub-layouts.
     * basically just a fancier
     * `{ layout1: new GranularRectLayout(), layout2: new GranularRectLayout() ...}`
     */
    constructor(SubLayoutClass: new (...args: any[]) => SUB_LAYOUT_CLASS, subLayoutConstructorArgs?: Record<string, unknown>);
    getDataByID(id: string): T | undefined;
    getSublayout(layoutName: string): SUB_LAYOUT_CLASS;
    addRect(layoutName: string, id: string, left: number, right: number, height: number, data?: Record<string, T>, serializableData?: Record<string, T>): number | null;
    discardRange(layoutName: string, left: number, right: number): void | undefined;
    toJSON(): Record<string, SerializedLayout>;
}
