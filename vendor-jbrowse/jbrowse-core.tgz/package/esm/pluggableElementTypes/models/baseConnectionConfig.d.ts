import type { Instance } from '@jbrowse/mobx-state-tree';
declare const BaseConnectionConfig: import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
    name: {
        type: string;
        defaultValue: string;
        description: string;
    };
    assemblyNames: {
        type: string;
        defaultValue: never[];
        description: string;
    };
}, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, "connectionId">>;
export default BaseConnectionConfig;
export type BaseConnectionConfigSchema = typeof BaseConnectionConfig;
export type BaseConnectionConfigModel = Instance<BaseConnectionConfigSchema>;
