export interface JexlExpression {
    eval(context?: Record<string, unknown>): unknown;
    _exprStr?: string;
}
export interface JexlInstance {
    compile(code: string): JexlExpression;
}
export declare function stringToJexlExpression(str: string, jexl?: JexlInstance): JexlExpression;
