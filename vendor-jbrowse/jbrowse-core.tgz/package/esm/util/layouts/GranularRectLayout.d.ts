import type { BaseLayout, RectTuple, Rectangle, SerializedLayout } from './BaseLayout.ts';
export default class GranularRectLayout<T> implements BaseLayout<T> {
    private pitchX;
    private pitchY;
    private hardRowLimit;
    private bitmap;
    private rectangles;
    maxHeightReached: boolean;
    private maxHeight;
    private displayMode;
    private pTotalHeight;
    private stableSeeding;
    constructor({ pitchX, pitchY, maxHeight, hardRowLimit, displayMode, stableSeeding, }?: {
        pitchX?: number;
        pitchY?: number;
        maxHeight?: number;
        displayMode?: string;
        hardRowLimit?: number;
        stableSeeding?: boolean;
    });
    addRect(id: string, left: number, right: number, height: number, data?: T, serializableData?: T, preferredRow?: number): number | null;
    private isRangeClearAt;
    collides(rect: Rectangle<T>, top: number): boolean;
    private getOrCreateRow;
    addRectToBitmap(rect: Rectangle<T>): void;
    discardRange(left: number, right: number): void;
    hasSeen(id: string): boolean;
    getByCoord(x: number, y: number): string | undefined;
    getByID(id: string): RectTuple | undefined;
    getDataByID(id: string): T | undefined;
    getSerializableDataByID(id: string): T | undefined;
    getTotalHeight(): number;
    get totalHeight(): number;
    getRectangles(): Map<string, RectTuple>;
    serializeRegion(region: {
        start: number;
        end: number;
    }): SerializedLayout;
    toJSON(): SerializedLayout;
}
