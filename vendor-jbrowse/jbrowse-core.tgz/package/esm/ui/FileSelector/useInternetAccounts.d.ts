import type { AbstractRootModel } from '../../util/types/index.ts';
export default function useInternetAccounts(rootModel?: AbstractRootModel): {
    accountMap: {
        [k: string]: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            configuration: import("@jbrowse/mobx-state-tree").ITypeUnion<any, any, any>;
        }> & {
            readonly name: string;
            readonly description: string;
            readonly internetAccountId: string;
            readonly authHeader: string;
            readonly tokenType: string;
            readonly domains: string[];
            readonly toggleContents: React.ReactNode;
            readonly SelectorComponent: import("../../util/index.ts").AnyReactComponentType | undefined;
            readonly selectorLabel: string | undefined;
        } & {
            handlesLocation(location: import("../../util/index.ts").UriLocation): boolean;
            readonly tokenKey: string;
        } & {
            getTokenFromUser(_resolve: (token: string) => void, _reject: (error: Error) => void): void;
            storeToken(token: string): void;
            removeToken(): void;
            retrieveToken(): string | null;
            validateToken(token: string, _loc: import("../../util/index.ts").UriLocation): Promise<string>;
        } & {
            getToken(location?: import("../../util/index.ts").UriLocation): Promise<string>;
        } & {
            addAuthHeaderToInit(init?: RequestInit, token?: string): {
                body?: BodyInit | null;
                cache?: RequestCache;
                credentials?: RequestCredentials;
                integrity?: string;
                keepalive?: boolean;
                method?: string;
                mode?: RequestMode;
                priority?: RequestPriority;
                redirect?: RequestRedirect;
                referrer?: string;
                referrerPolicy?: ReferrerPolicy;
                signal?: AbortSignal | null;
                window?: null;
                headers: Headers;
            };
            getPreAuthorizationInformation(location: import("../../util/index.ts").UriLocation): Promise<{
                internetAccountType: string;
                authInfo: {
                    token: string;
                    configuration: any;
                };
            }>;
        } & {
            getFetcher(loc?: import("../../util/index.ts").UriLocation): (input: RequestInfo, init?: RequestInit) => Promise<Response>;
        } & {
            openLocation(location: import("../../util/index.ts").UriLocation): import("../../util/io/RemoteFileWithRangeCache.ts").RemoteFileWithRangeCache;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            configuration: import("@jbrowse/mobx-state-tree").ITypeUnion<any, any, any>;
        }, {
            readonly name: string;
            readonly description: string;
            readonly internetAccountId: string;
            readonly authHeader: string;
            readonly tokenType: string;
            readonly domains: string[];
            readonly toggleContents: React.ReactNode;
            readonly SelectorComponent: import("../../util/index.ts").AnyReactComponentType | undefined;
            readonly selectorLabel: string | undefined;
        } & {
            handlesLocation(location: import("../../util/index.ts").UriLocation): boolean;
            readonly tokenKey: string;
        } & {
            getTokenFromUser(_resolve: (token: string) => void, _reject: (error: Error) => void): void;
            storeToken(token: string): void;
            removeToken(): void;
            retrieveToken(): string | null;
            validateToken(token: string, _loc: import("../../util/index.ts").UriLocation): Promise<string>;
        } & {
            getToken(location?: import("../../util/index.ts").UriLocation): Promise<string>;
        } & {
            addAuthHeaderToInit(init?: RequestInit, token?: string): {
                body?: BodyInit | null;
                cache?: RequestCache;
                credentials?: RequestCredentials;
                integrity?: string;
                keepalive?: boolean;
                method?: string;
                mode?: RequestMode;
                priority?: RequestPriority;
                redirect?: RequestRedirect;
                referrer?: string;
                referrerPolicy?: ReferrerPolicy;
                signal?: AbortSignal | null;
                window?: null;
                headers: Headers;
            };
            getPreAuthorizationInformation(location: import("../../util/index.ts").UriLocation): Promise<{
                internetAccountType: string;
                authInfo: {
                    token: string;
                    configuration: any;
                };
            }>;
        } & {
            getFetcher(loc?: import("../../util/index.ts").UriLocation): (input: RequestInfo, init?: RequestInit) => Promise<Response>;
        } & {
            openLocation(location: import("../../util/index.ts").UriLocation): import("../../util/io/RemoteFileWithRangeCache.ts").RemoteFileWithRangeCache;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
    };
    shownAccountIds: string[];
    hiddenAccountIds: string[];
    recentlyUsed: string[];
    setRecentlyUsed: (value: string[] | ((val: string[]) => string[])) => void;
};
