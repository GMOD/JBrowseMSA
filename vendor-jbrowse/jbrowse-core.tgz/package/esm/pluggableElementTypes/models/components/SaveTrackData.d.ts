import type { AnyConfigurationModel } from '../../../configuration/index.ts';
import type { FileTypeExporter } from '../saveTrackFileTypes/types.ts';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
declare const SaveTrackDataDialog: ({ model, handleClose, }: {
    model: IAnyStateTreeNode & {
        configuration: AnyConfigurationModel;
        saveTrackFileFormatOptions: () => Record<string, FileTypeExporter>;
    };
    handleClose: () => void;
}) => import("react").JSX.Element;
export default SaveTrackDataDialog;
